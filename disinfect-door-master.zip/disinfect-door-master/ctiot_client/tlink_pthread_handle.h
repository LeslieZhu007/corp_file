#ifndef __TLINK_PTTHREAD_HANDLE_H
#define __TLINK_PTTHREAD_HANDLE_H


#include <stdio.h>
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_msg_handler.h"
#include "ctiot_tlink_client.h"
#include "ctiot_log.h"

void tlink_main(void);




#endif /* __TLINK_PTTHREAD_HANDLE_H */