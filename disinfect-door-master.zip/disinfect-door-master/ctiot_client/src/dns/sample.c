/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "ctiot_dns.h"


//**************************************************
//
//! @brief dns解析,返回解析到的第一个地址，失败返回-1，成功则返回相应地址
//
//**************************************************
unsigned long ctiot_dns(char* hostName)
{

        //存储dns解析的主机的相关信息
        struct hostent* host;
        struct in_addr addr;
        char **pp;

        host = gethostbyname(hostName);
        if (host == NULL)
        {
                printf("gethostbyname %s failed\n", hostName);
                return -1;
        }

        pp = host->h_addr_list;

        if (*pp!=NULL)
        {
                addr.s_addr = *((unsigned int *)*pp);
                printf("%s address is %s\n", hostName, inet_ntoa(addr));
                pp++;
                return addr.s_addr;
        }
        return -1;
}

/**
 * 使用说明
 * 编译后使用 ./ctiot_dns_sample www.baidu.com  运行程序
 * 注url只含域名  不含有 http:// 或 https:// 的前缀和后面的目录和参数
 */
// int main(int argc, char *argv[])
// {       
//         if(argv[1] == NULL){
//                 printf("error: url NULL !\n");
//                 return -1;
//         }
//         unsigned long ip = ctiot_dns(argv[1]);
//         return 0;
// }