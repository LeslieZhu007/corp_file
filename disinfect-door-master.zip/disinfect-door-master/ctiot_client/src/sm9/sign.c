#include "gmibc.h"
#include "pbc/pbc_algid.h"

#include "oldapi.h"
#include "sign.h"
#include <memory.h>
#include <stdio.h>
#include <string.h>
#include "hexUtil.c"
#include "stdlib.h"
/******************************说明*****************************
所有的返回错误码，请见 gmibc.h

****************************************************************/

//SM9签名
/**
        *commonFileName: 参数文件名（含路径）
        *privateFileName: 私钥文件名（含路径）
        *privatePassword: 私钥密码
        *inputData: 需要签名的数据
        *inputDataLength: 需要签名的数据的长度
        *outputData: 签名后的结果
        *outputDataLength: 签名后的结果的长度，入参时为数据分配的长度，出参为实际长度
*/
int iotx_sign_sm9(char *commonFileName, char *privateFileName, unsigned char *privatePassword,
                  unsigned char *inputData, int inputDataLength,
                  unsigned char *outputData, unsigned int *outputDataLength)
{
    int32 ret;
    PrvKeyContext recvPrvKey = NULL;
    IBCParamContext ibcParam = NULL;
    LibContext libCtx = NULL;
    PubKeyContext hPubKey = NULL;

    uint32 alg = 0; //此值为0时，会自动取值

    do
    {
        ret = CreateLibCtx(&libCtx);
        if (ret != GM_SUCCESS)
            break;

        ret = CreateIBCParamObjectFromFile(&ibcParam, (char*)commonFileName);
        if (ret != GM_SUCCESS)
            break;

        ret = AddLibCtxIBCParam(libCtx, ibcParam);

        ret = CreatePrvKeyObjectFromFileEx(libCtx, &recvPrvKey,
                                           privateFileName, privatePassword, strlen(privatePassword), 0);
        if (ret != GM_SUCCESS)
        {
            break;
        }

        ret = GMCryptSignData(recvPrvKey, ALG_HASH_SM3, inputData, inputDataLength, outputData, outputDataLength);
    } while(0);

    if (recvPrvKey)
        DestroyPrvKeyObject(recvPrvKey);

    if (hPubKey)
        DestroyPubKeyObject(hPubKey);

    if (ibcParam)
        DestroyIBCParamObject(ibcParam);

    if (libCtx)
        DestroyLibCtx(libCtx);

    return ret;
}

void data2HexArr(unsigned char *input, int inputLength)
{
    printf("singedData to hex array:{\r\n");
    int i;
    for (i = 0; i < inputLength; i++) {
        printf("0x%02x, ", input[i]);
        if ((i > 0)&&(i % 15 == 0)) {
            printf("\r\n");
        }
    }
    printf("}\r\n");
}
void printHexData(unsigned char *input,  unsigned int inputLength, unsigned char *hexSignedData)
{
    int i = 0;
    int printLength = inputLength * 2 + 3;
    char *printData = (char*)malloc(printLength);

    memset(printData, 0, printLength);
    for(i=0; i<inputLength; i++)
    {
        sprintf(printData + i*2, "%02x", input[i]);
    }
 
    memcpy(hexSignedData, printData, printLength);
    free(printData);
}

static unsigned char hexchars[] = "0123456789ABCDEF";
unsigned char *php_url_encode(unsigned char *s, int len, int *new_length)
{
    register unsigned char c;
    unsigned char *to, *start;
    unsigned char const *from, *end;

    from = (unsigned char *)s;
    end  = (unsigned char *)s + len;
    start = to = (unsigned char *) calloc(1, 3*len+1);

    while (from < end)
    {
        c = *from++;

        if (c == ' ')
        {
            *to++ = '+';
        }
        else if ((c < '0' && c != '-' && c != '.') ||
                 (c < 'A' && c > '9') ||
                 (c > 'Z' && c < 'a' && c != '_') ||
                 (c > 'z'))
        {
            to[0] = '%';
            to[1] = hexchars[c >> 4];
            to[2] = hexchars[c & 15];
            to += 3;
        }
        else
        {
            *to++ = c;
        }
    }
    *to = 0;
    if (new_length)
    {
        *new_length = to - start;
    }
 
    return start; 
}


char * get_str_param(char *src, char * des, int need_long)
{
    int i=0;
    if(strlen(src)<need_long)
    {
        strcpy(des, src);
        printf("src: %s \n",src);
        printf("des: %s \n",des);
        for(i=strlen(src); i<need_long; i++)
            des[i]='0';
    }
    else
    {
        for(i=0; i<need_long; i++)
            des[i] = src[i+strlen(src)-need_long];
    }
    des[need_long] ='\0';
    printf("final des: %s \n",des);
    return des;
}

int signSM9(unsigned char *sUserID, unsigned char *signedData, unsigned int *signedDataLen)
{
    if (sUserID == NULL) {
        return 2;
    }
    
    int ret = 0;
    
    //参数文件名（含路径）
	char sPublicFileName[] = "../../src/sm9/common_mini.se";
	//私钥文件名（含路径）
	char sPrivateFileNameHex[] = "../../src/sm9/private_hex.se";
	char sPrivateFileName[] = "../../src/sm9/private_mini.se";

    const char *pub_key = "1F93DE051D62BF718FF5ED0704487D01D6E1E4086909DC3280E8C4E4817C66DDDD21FE8DDA4F21E607631065125C395BBC1C1C00CBFA6024350C464CD70A3EA6169F78397AD89A10C0C8A2A8D643DA0269B237BDBCA56D4E41B3D12DE22271052B36284B6D55084183F5AAD7D004B1F199B6A72B9EE111A565028578B18F44DB873722755292130B08D2AAB97FD34EC120EE265948D19C17ABF9B7213BAF82D65B85AEF3D078640C98597B6027B441A01FF1DD2C190F5E93C454806C11D8806141A7CF28D519BE3DA65F3170153D278FF247EFBA98A71A08116215BBA5C999A7C717509B092E845C1266BA0D262CBEE6ED0736A96FA347C8BD856DC76B84EBEB966F51229B842390F24EB7D75C652B1262A2F670D1331BAEDBD960484471C84C363B791D54B125FA002ECF9C8397EC494185D57FB8632FD9F7929BCD370B0EE48215B3C8B7B5EFD38D2362DE8BC8ADDB55EF498B6D2AD1D9553F5724261F54FFB564D667C596C90A3350403C662DE40F0DDF1E20413C11C5EF7B765BCADD7862760984F153AB48E114E136D90B1D2C6970BDE34276911743D7A0F8B6D4C0C58E42884E58D0EB6E32BC61BE35832AE58606B78B24E1298AADE56F18A150F9670F31193B7F83A6EDF3CEC238B87C2474E689FDA598E9FA8AC570465AF26F984A823D63E245050333DE717E89B946F7B788D083080DF803CA2D92A8E951236D4259590DC8D74E57E07BBE50B69A61089A90237376A92BB18A91F9CB2F70F3735D629547CB5FD3D6B98A723E13CEACAFFBA25E957B7A40DAD52CE2F32A1714F7DF3BCF1FFD603F9BE241B9B736A567C09124170B551205A0B36F9B4A3BB9087C5BC22E0B547EEEE2C3C580E6F21F83F7A622F2E61DED8DF8CD985D208E65F3B5C83562876F73B8C98F2EE34436737E67955236A46793E3B0FE32762457461946AEDBCB3531574483679D688313F9677D45FF91F3B779BAEBF3544D6856C07B9F2E58ED9159F14FF8B83847E2BF7B12E698B0066D79651594D2AF09869A95DB701CB9DA6D60CCB8203945DD1BDAB6C3345277EB21CF9C9CDC10342C9A4705BFE7E76774";
     
    // 写入公私钥2进制文件失败
    if (hexstr_to_char(pub_key,sPublicFileName) != 0) {
        return 3;
    }
    
    // 读取私钥16进制文件失败
    if (hexToBinFile(sPrivateFileNameHex,sPrivateFileName) != 0) {
        return 4;
    }
    
    unsigned int needEncDataLength = strlen(sUserID);

    //私钥文件加载密码，根据实际密钥的不同，此密可能会不同
    int PrivatePasswdLength= 32;
    char sPrivatePassword[PrivatePasswdLength+1];

    memset(sPrivatePassword, 0, sizeof(char)*PrivatePasswdLength+1);
    get_str_param(sUserID , sPrivatePassword, PrivatePasswdLength); 

    // 签名
    ret = iotx_sign_sm9(sPublicFileName, sPrivateFileName, sPrivatePassword,
                        sUserID, needEncDataLength, signedData, signedDataLen);
    
    switch (ret) {
        case 1:
            // 成功
            ret = 0;
            break;
        case -55:
            // 算法内部错误
            ret = 5;
            break;
        default:
            // 其他异常
            ret = 1;
            break;
    }
    return ret;
}
