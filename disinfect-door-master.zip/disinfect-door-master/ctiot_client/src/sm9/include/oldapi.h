#ifndef __OLD_API_H__
#define __OLD_API_H__

#ifdef __cplusplus
extern "C" {
#endif

LibContext DupLibContextObject(
	LibContext hLibContext
);

int32 SearchLibCtxCert(
	LibContext hLibCtx, 
	DomainAndSerial *dns, 
	uint8 *id,
	uint32 idLen,
	CertificateContext *certCtx
);

int32 SetIDAttribute(
	Identity id, 
	uint32 idAttributeType, 
	void *info, 
	uint32 infoLen
);

int32 SetIDAttributeInteger(
	Identity id, 
	uint32 idAttributeType, 
	int32 info
);

int32 GetIDAttribute(
	Identity id, 
	uint32 idAttributeType, 
	void *info,
	uint32 *infoLen
);

int32 GM_id_encode(
	uint32 schema, 
	OctString *encID, 
	OctString *rawID, 
	uint8 idType,
	uint32 keyType,	
	DomainAndSerial *DNAndSerial,
	OctString *tag, 
	GMTime *decTime, 
	OctString *policy
);

int32 AddP7IBERecipient(
	IdentityList idList, 
	uint8 *recp, 
	uint32 recpLen,
	uint32 algType, 
	DomainAndSerial *DNAndSerial, 
	GMTime *decryptTime, 
	IBCParamContext paraInfo
);

int32 AddP7IBERecipientEx(
	IdentityList idList, 
	uint8 *recp, 
	uint32 recpLen,
	uint32 algType, 
	DomainAndSerial *DNAndSerial, 
	GMTime *decryptTime, 
	uint8 *policy,
	uint32 policyLen,
	uint8 *idTag,
	uint32 idTagLen,
	IBCParamContext paraInfo
);

int32 AddP7PKERecipient(
	IdentityList idList,
	CertificateContext certCtx,
	PubKeyContext pubKey
);

int32 AddP7Signer(
	IdentityList idList, 
	PrvKeyContext prvKey, 
	uint32 algType, 
	CertificateContext certCtx, 
	uint8 *signer, 
	uint32 signerLen,
	DomainAndSerial *DNAndSerial, 
	DeviceContext dev
);

int32 AddP7SignerEx(
	IdentityList idList, 
	PrvKeyContext prvKey, 
	uint32 algType, 
	CertificateContext certCtx, 
	uint8 *signer, 
	uint32 signerLen,
	uint8 *policy,
	uint32 policyLen,
	uint8 *idTag,
	uint32 idTagLen,
	DomainAndSerial *DNAndSerial, 
	DeviceContext dev
);

int32 CreatePKCPubKeyObjectFromMem(
	PubKeyContext *ctx, 
	uint8 *keyBuf,
	uint32 keyLen
);

int32 CreatePKCPubKeyObjectFromCert(
	PubKeyContext *ctx, 
	CertificateContext cert
);

int32 CreatePKCPubKeyObjectFromDev(
	PubKeyContext *keyCtx, 
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	uint32 keyUsage
);

int32 CreatePrvKeyObjectFromDev(
	LibContext libCtx,
	PrvKeyContext *prvCtx, 
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	uint32 keyUsage,
	uint32 algType
);

int32 CreateIBCPrivateKeyFromDevBlob(
	PrvKeyContext *prvKeyCtx,
	uint32 devType,
	LibContext libCtx,
	IBCParamContext ibcParamCtx,
	OctString *keyInfo
);

int32 IBCPrvKeyActiviation(
	PrvKeyContext hPrvKey
);

int32 PrvKeyObjToDevBlob(
	PrvKeyContext prvKeyCtx, 
	uint32 devType,
	OctString *pubInfo, 
	OctString *prvInfo
);

int32 PrvKeyObjToDevBlobEx(
	PrvKeyContext prvKeyCtx, 
	uint32 devType,
	OctString *pubInfo, 
	OctString *prvInfo,
	uint8 *pass,
	int32 passLen
);

int32 CreateCertAndKeyFromP12File(
	LibContext libCtx, 
	PrvKeyContext *ctx, 
	CertificateContext *certCtx,
	int8 *p12File, 
	uint8 *password,
	uint32 pLen
);

int32 CreateCertObject(
	CertificateContext *certCtx,
    int8 *cert, 
	uint32 certlen
);

int32 GetCertAttribute(
	CertificateContext certCtx, 
	uint32 attrType, 
	void *info
);

int32 GMParseCertName(
	int8 *subject, 
	uint32 chtype, 
	int32 multirdn, 
	uint32 attrType, 
	void *info
);

int32 GM_check_cert_type( const char *filename );

int32 GM_load_cert(
	const char *file, 
	CertificateContext *certCtx
);

int32 GM_load_cert_from_str(
	int8 * certData, 
	uint32 certLen, 
	CertificateContext *certCtx
);

int32 GM_export_cert( 
	CertificateContext cert, 
	uint8 *buffer, 
	uint32 *bufLen
);

CertificateContext GM_cert_dup(
	CertificateContext cert
);

void GM_cert_free(
	CertificateContext cert
);

int32 GMExportCert(
	CertificateContext cert, 
	uint8 *buffer, 
	uint32 *bufLen
);

int32 GM_dump_domain_serial( 
	DomainAndSerial * pDNAndSerial, 
	int8 *szDN, 
	uint32 dnLen,
	int8 *szSerial, 
	uint32 serialLen 
);

int32 GMVerifyCert(
	LibContext hLibCtx, 
	CertificateContext hCert
);

int32 CreateIBCParamObjectFromDev(
	IBCParamContext *ibcParamCtx, 
	DeviceContext devCtx,
	DomainAndSerial *dns
);

int32 IBCParamObjToDevBlob(
	IBCParamContext ibcParamCtx,
	uint32 devType,
	OctString *sysInfo
);

int32 GetContainerAttribute(
	DevCntContext cntCtx,
	uint32 attrType,
	void *info,
	uint32 *infoLen
);

int32 DeviceCryptVerifySignature(
	DevKeyContext hPubKey,
	uint32 algID,
	HashContext hHash, 
	uint8 *pbData, 
	uint32 dataLen, 
	int32 *verifyResult
);

int32 DeviceCreatePKIKeySetFromP12File(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	int8 *p12File,
	uint8 *passwd,
	uint32 pLen,
	uint32 keyUsage
);

int32 DeviceCreateKeySetFromPrvKeyObj(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	PrvKeyContext prvKeyObj,
	uint32 keyUsage
);

int32 GMCryptGenMACKey(
	MACContext *phMac, 
	uint32 algId, 
	uint32 flags
);

int32 GMCryptVerify(
	PubKeyContext hPubKey, 
	uint32 digestType,
	uint8 *pbDigest,
	uint32 digestLen,
	uint8 *pbData, 
	uint32 dataLen, 
	int32 *verifyResult
);

int32 GMCryptVerifySignature(	//only verify with appendix of hash value, compatible with RSA, DSA, ECDSA, tweaked IBS' such as Hess, CC, BLMQ
	PubKeyContext hPubKey, 
	HashContext hHash, 
	uint8 *pbData, 
	uint32 dataLen, 
	int32 *verifyResult
);

int32 GM_SSS_split(
	int8* secret, 
	int32 slen, 
	int32 hex, 
	sss_share *share, 
	int32 num, 
	int32 threshold
);

int32 GM_SSS_restore(
	int8 *secret, 
	int32 *slen, 
	int32 hex, 
	sss_share *share, 
	int32 snum					 
);

int32 GMOpenFileStream(
	GMStream *streamObj, 
	int8 *fileName, 
	int32 mode
);

int32 GMOpenMemStream(
	GMStream *streamObj, 
	uint8 *buf,
	int32 bufLen
);

int32 GMCloseStream(
	GMStream streamObj
);

int32 GMSetGStream(
	GMStream *streamObj, 
	void *pGStream
);

int32 GMDisconnectGStream(
	GMStream streamObj
);

int32 GMDeBase64(
	GMStream inStream, 
	GMStream outStream
);

int32 CHAPChapChallengeEncap(
	int8* chapChallengeB64,
	int32 chapChallengeB64Len,
	int32 randomLen
);

int32 IBCCHAPVerifyEncap(
	uint8 *chapRandom,
	int32 chapRandomLen, 
	int8 *chapResponseB64, 
	int32 chapResponseLenB64, 
	int8 *paramData,
	int32 paramLen,
	int8 *idBuf,
	int32 idLen,
	int32 iFlags
);

int32 IBCCHAPVerifyEncapEx(
	int8 *chapChallengeB64,
	int32 chapChapllengB64Len, 
	int8 *chapResponseB64, 
	int32 chapResponseLenB64, 
	int8 *paramData,
	int32 paramLen,
	int8 *idBuf,
	int32 idLen,
	int32 iFlags
);


int32 IBCCHAPVerifyEncapFast(
	LibContext libCtx,
	IBCParamContext ibcParam,
	uint8 *chapRandom,
	int32 chapRandomLen, 
	int8 *chapResponseB64, 
	int32 chapResponseLenB64, 
	int8 *idBuf,
	int32 idLen,
	int32 iFlags
);

int32 IBCCHAPVerifyEncapFastEx(
	LibContext libCtx,
	IBCParamContext ibcParam,
	int8 *chapChallengeB64,
	int32 chapChapllengB64Len, 
	int8 *chapResponseB64, 
	int32 chapResponseLenB64, 
	int8 *idBuf,
	int32 idLen,
	int32 iFlags
);

int32 GMExportIBCPrvKeyInfo(
	uint8 *id_ptr, 
	int32 *idLen, 
	PrvKeyContext hPrvKey, 
	uint16 encoded
);

int32 GetExportedIBCKeyAttribute(
   uint8 *id_ptr,
   uint8 *attrStore,
   int32 infoType
);

int32 GMDecodeIBCIdentifier(
	uint8 *buf, 
	int32 bufLen, 
	int32 *fidLen, 
	int32 align
);

int32 GMDataCompress(
	uint8 *pDataIn, 
	uint32 iDataInLen, 
	uint8 *pDataOut, 
	uint32 *pDataOutLen, 
	uint32 iAlg
);

int32 GMDataCompressEx(
	uint8 *pDataIn, 
	uint32 iDataInLen, 
	uint8 *pDataOut, 
	uint32 *pDataOutLen, 
	uint32 iAlg,
	uint32 iLevel
);

int32 GMDataUnCompress(
	uint8 *pDataIn, 
	uint32 iDataInLen, 
	uint8 *pDataOut, 
	uint32 *pDataOutLen, 
	uint32 iAlg
);

int32 GM_KDF1(
	uint8 *kdf,
	uint32 kdfLen,
	uint8 *msg,
	uint32 mLen,
	uint32 nAlg
);

int32 GMMemStatus(
	int32 *engineAllocNum, 
	int32 *pbcAllocNum, 
	int32 *sslAllocNum
);

int32 CreatePrvKeyObjectFromFile(	//encapsulate the interface to read IBC key files and PKI key files
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	int8 *keyFile,		//string ended with 0
	uint8 *passwd,
	uint32 passwdLen
);

int32 CreatePrvKeyObjectFromMem(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	uint8 *keyBuf, 
	uint32 keyLen,
	uint8 *passwd,
	uint32 passwdLen
);

int32 CreatePrvKeyObjectFromStream(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	GMStream pkStream, 
	uint8 *passwd,
	uint32 passwdLen
);

#ifdef __cplusplus
}
#endif
#endif