#ifndef __SIGN_H__
#define __SIGN_H__

#ifdef LINUX
#include <stdlib.h>
#endif

#ifdef AIX
#include <sys/inttypes.h>
#include <sys/types.h>
#endif

#if defined( WIN32 ) && !defined(_WIN32_WCE) && defined(_DEBUG)
#define NOTIFYERROR(A)		MessageBox(NULL, "ERROR", "ERROR", MB_OK)
#else
#define NOTIFYERROR(A)
#endif

#ifdef EXPORT_BIGINT
#include <pbc/pbc_mpint.h>
#endif


#define ENCDATALENGTH 1024


#endif