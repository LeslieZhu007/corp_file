#ifndef __GM_CONFIG_H__
#define __GM_CONFIG_H__

#ifndef NO_P7
#define SUPPORT_P7
#endif

#ifdef SUPPORT_P7
#define SUPPORT_P7_ZIP
#define SUPPORT_ENVELOPEDDATA
#define SUPPORT_SIGNEDDATA
#define SUPPORT_SIGNENVDATA
#define SUPPORT_AUTHENVDATA
#define SUPPORT_SIGNAUTHENVDATA
#define SUPPORT_DIGESTEDDATA
#define SUPPORT_ENCRYPTEDDATA
#define SUPPORT_HYBRID_ENCRPTION
#endif //END OF SUPPORT_P7

#ifndef COMPACT_EYIBC
#define SUPPORT_CRYPTO_CHAP
#define SUPPORT_CRYPTO_ZIP
#define SUPPORT_FAST_ZIP
#else
#define COMPACT_PBC
#endif

#ifdef SUPPORT_P7_ZIP
#define SUPPORT_ZIP
#endif

#if !defined(COMP_OPENSSL) && !defined(NO_PKI)
#define SUPPORT_PKI
#endif

#ifdef SUPPORT_PKI
#define SUPPORT_RSA

#ifndef _WIN32_WCE
#ifndef ANDROID
#ifndef SYMBIAN
#define SUPPORT_ECDSA
#endif
#endif
#define SUPPORT_DSA
#endif
#endif //END OF SUPPORT_PKI

#ifdef SUPPORT_P7
#define SUPPORT_ZDM
#endif

#define SUPPORT_IBC

#ifdef SUPPORT_IBC

#if !defined(_WIN32_WCE) && !defined(SYMBIAN) && !defined(ANDROID) && !defined(NO_PRECOMPUTATION)
#define SUPPORT_PAIRING_PRECOMPUTING
#endif

//#ifndef XSCALE
//#ifdef LINUX
#if !defined(_WIN32_WCE) && !defined(SYMBIAN) && !defined(ANDROID) && !defined(COMPACT_EYIBC)
#define SUPPORT_IBC_KGC
#endif
//#endif
//#endif

#define SUPPORT_IBCPARAM_PASSWD_PROTECTION

#if !defined(_WIN32_WCE) && !defined(SYMBIAN) && !defined(ANDROID) && !defined(NO_PRECOMPUTATION)
#define SUPPORT_SOK_IDMAP_PRECOMPUTING
#define SUPPORT_SK_IDMAP_PRECOMPUTING
#define SUPPORT_CHN_IDMAP_PRECOMPUTING
#endif

#define SUPPORT_ACTIVIATION

#ifndef STATIC_LIB
#define SUPPORT_IBCPOLICY
#endif

//#define WIN32_SERVER

#if defined(WIN32_SERVER) || defined(_WIN32_WCE) || defined(LINUX)
#define ACTIVATION_SIMULATION
#endif

#define ACTIVATION_SIMULATION

#if defined(SUPPORT_ACTIVIATION) || defined(SUPPORT_IBCPOLICY)
#if !defined(LINUX) && !defined(WIN32_SERVER) && !defined(_WIN32_WCE)
//#define SUPPORT_OTLS
#endif
#endif

//#define SUPPORT_OTLS

#if !defined(LINUX) && !defined(_WIN32_WCE) && !defined(COMPACT_EYIBC)
#if !defined(CPU_64) && _MSC_VER < 1500
#define SUPPORT_TRANSPORTATION
#endif
#endif

#ifdef SUPPORT_TRANSPORTATION
#define SUPPORT_PARAM_CONVERSION
#define SUPPORT_SOK_CONVERSION
#endif //END OF SUPPORT_TRANSPORTATION

#endif //END OF SUPPORT_IBC

#ifndef EYIBC_NO_DEVICE
#define SUPPORT_DEVICE
#endif

#ifdef SUPPORT_DEVICE
//#define SUPPORT_DEV_SJY
//#define SUPPORT_DEV_PKCS11

//#ifndef LINUX
#define SUPPORT_DEV_VIRT
//#endif

#ifdef SUPPORT_DEV_VIRT

#if !defined(_WIN32_WCE) && !defined(LINUX)
#if !defined(CPU_64) && _MSC_VER < 1500
#define SUPPORT_OBS_DEV
#endif
#define SUPPORT_UKEYLIB
#endif

#ifndef ANDROID
#define SUPPORT_SIM_FILE
#endif

#if defined(IOS) || defined(ANDROID) || defined(LINUX)
//#define SUPPORT_UKEYLIB
#endif

#endif
//#define SUPPORT_DEV_XENGINE
#endif //end of SUPPORT_DEVICE

#if !defined(LINUX)
#define SUPPORT_CSP
#endif

#if !defined(_WIN32_WCE) && !defined(COMPACT_PBC)
#define SUPPORT_SSS
#endif

#if defined(LINUX) && !defined(SUPPORT_IBC_KGC)
#undef SUPPORT_SSS
#endif

#define COS_RCD_PADDING_TO_MAX_LEN

#ifdef _WIN32_WCE
#define UNICODE_REQUIRED
#endif

#ifdef _UNICODE
#define UNICODE_REQUIRED
#endif

#define SUPPORT_XCIPHER

#define OLD_CHN_ENCODING

#if defined(WIN32) && !defined(_WIN32_WCE) && !defined(CPU_64) && _MSC_VER < 1500
//#ifdef _DEBUG
#define SUPPORT_XUSB

//#endif
#endif

//#define JSZWT_AOTIAN

#ifndef COMPACT_PBC
#define SUPPORT_CLPKC
#endif

#endif /* __GM_CONFIG_H__ */

