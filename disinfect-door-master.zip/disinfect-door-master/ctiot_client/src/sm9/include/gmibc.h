//+-------------------------------------------------------------------
//
//  EYIBC function claims
//  Copyright (c) NISC. All rights reserved.
//
//  File:        gmibc.h
//
//  Contents:    EYIBC main function claims.
//
//  History:     7-15.0        Created         Michael
//
//--------------------------------------------------------------------
#ifndef __GM_IBC_H__
#define __GM_IBC_H__

#include "config.h"

#define GM_DEV_ZX32		1

#define STRING_ID		0
#define OCTET_ID		1

#define EC_RECP_TAG		"RECP="
#define EC_SIGN_TAG		"SIGN="
#define EC_EXCH_TAG		"EXCH="
#define EC_DECTIME_TAG	"DECTIME="
#define EC_PLCY_TAG		"PLCY="
#define EC_RECP_TAG_LEN	strlen(EC_RECP_TAG)
#define EC_SIGN_TAG_LEN	strlen(EC_SIGN_TAG)
#define EC_PLCY_TAG_LEG strlen(EC_PLCY_TAG)

#define EY_RECP_TAG		"recp="
#define EY_SIGN_TAG		"sign="
#define EY_DECTIME_TAG	"decdate="

#ifndef __PBC_ALG_ID_H__
#define ALG_KGA_SOK		0x02000000
#define ALG_KGA_SK		0x04000000
#define ALG_KGA_BB1		0x06000000
#define ALG_KGA_CHN		0x08000000
#define MASK_ALG_KGA	0x0E000000
#endif

#define EXTRACT_IBC_KGA(kga)	(kga & MASK_ALG_KGA)

#define PROTO_UDP		1
#define PROTO_TCP		2

#ifdef EYIBC_EXPORTS
 #define DLL_API __declspec(dllexport)
#else
 #define DLL_API __declspec(dllimport)
#endif

#define IBCPRVKEY_STATUS_ACTIVIATED		1
#define IBCPRVKEY_STATUS_DEACTIVIATED	2

#define POLICY_WITH_BASIC_KEY			0x02
#define POLICY_NO_BASIC_KEY				0x00
#define POLICY_KEY_MASK					0x02

#define POL_DECRYPTION_GTIME			1
//#define DECRYPTING_IP					2
//#define DECRYPTING_GROUP				3
//#define DECRYPTING_WORKFLOW			4
#define POL_COMBINED_POLICY				5	

#define	MAX_POLICY_SIZE					8192*4
#define MAX_RECPINFO_SIZE				4096
#define MAX_DOMAINNAME_SIZE				512
#define MAX_CERTSERIAL_SIZE				128
#define MAX_CERTINFO_SIZE				2048

#define DEFAULT_ICVLEN					12 //CCMP, GCMP's default ICVLEN

#define FORMAT_PEM						3

#define MAX_SECKEY_LEN					4096
#define MAX_OID_DER_LEN					256
#define MAX_MAC_LEN						64
#define MAX_ENCRYPT_BUF_LEN				81920
#define MAX_DIGEST_LEN					64

#define CHN_HID_SIGN					0x01
#define CHN_HID_ENC						0x02
#define CHN_HID_EXCH					0x02
#define CHN_HID_ENC_STD					0x03
#define CHN_HID_PLCY					0x10

#define COMPRESSION_ALG_ZIP				1
#define COMPRESSION_ALG_FASTZP			2

#ifndef uint8
#define uint8	unsigned char
#endif

#ifndef uint16
#define uint16	unsigned short
#endif

#ifndef uint32
#define uint32	unsigned int
#endif

//#ifndef ulong
//#define ulong	unsigned long
//#endif

#ifdef AIX
#include <sys/inttypes.h>
#else
#ifndef int8
#define int8	char
#endif

#ifndef int16
#define int16	short
#endif

#ifndef int32
#define int32	int
#endif
#endif

#ifndef uint64
#ifdef WIN32
#define uint64 unsigned __int64 
#else
#define uint64 unsigned long long
#endif
#endif

#ifndef sint64
#ifdef WIN32
#define sint64 __int64 
#else
#define sint64 long long
#endif
#endif

typedef void* ObjectPointer;

typedef ObjectPointer LibContext;			//handle to GM_LibContextt
typedef ObjectPointer IBCParamContext;		//handle to IBCParam
typedef ObjectPointer IBCMasterKeyContext;	//handle to IBCMasterKey
typedef ObjectPointer P7Object;				//handle to GM_P7Object

typedef ObjectPointer Identity;				//handle to GM_Identity
typedef ObjectPointer IdentityList;			//handle to GM_IdentityList

typedef ObjectPointer PubKeyContext;		//handle to PublicKey
typedef ObjectPointer PrvKeyContext;		//handle to PrivateKey
typedef ObjectPointer SecKeyContext;		//handle to SecretKey
typedef ObjectPointer FpeKeyContext;		//handle to FpeKey
typedef ObjectPointer HashContext;			//handle to CryptHash
typedef ObjectPointer MACContext;			//handle to CryptMAC
typedef ObjectPointer DEMContext;			//handle to CryptDEM

typedef ObjectPointer DeviceContext;		//handle to CryptDevice
typedef ObjectPointer DevCntContext;		//handle to DevKeyContainer
typedef ObjectPointer DevKeyContext;		//handle to DevKey
typedef ObjectPointer DevAppContext;
typedef ObjectPointer DevDigestContext;

typedef ObjectPointer CertificateContext;	//handle to X509

typedef ObjectPointer IBCPrvKeyContext;
typedef ObjectPointer GMStream;				//handle to STREAM

#define MAX_IV_LEN	32

typedef struct {
	uint32	AlgID;
	uint8	KeyLen;
	uint8	IV[MAX_IV_LEN];
	uint8	IVLen;
	uint8	Padding;
	uint8	Mode;
	uint8	FeedBitLen;
}DEVBLOCKCIPHERPARAM;

#define GM_IBCLIB_VERSION						15

#define GM_SMAIL_BEGIN_FLAG						"\n---------BEGIN SMIME1.4---------\n"
#define GM_SMAIL_END_FLAG						"\n----------END SMIME1.4----------\n"

#define GM_SUCCESS								1
#define GM_ERROR_BASE							0
#define GM_ERROR_MEMORY_FAILURE					GM_ERROR_BASE-1		//�ڴ����
#define GM_ERROR_INVALID_ID_ATTR				GM_ERROR_BASE-2		//��Ч�ı�ʶ����
#define GM_ERROR_IDLIST_COUNT_OVERFLOW			GM_ERROR_BASE-3		//�Ƿ���ʶ����
#define GM_ERROR_INVALID_LIBCTX_ATTR			GM_ERROR_BASE-4		//��Ч��������������
#define GM_ERROR_INVALID_ID						GM_ERROR_BASE-5		//��Ч�ı�ʶ
#define GM_ERROR_INVALID_IDLIST					GM_ERROR_BASE-6		//��Ч�ı�ʶ�б�
#define GM_ERROR_INVALID_LIBCTX					GM_ERROR_BASE-7		//��Ч��������������
#define GM_ERROR_INVALID_PKCS7OBJECT			GM_ERROR_BASE-8		//��Ч��PKCS7����
#define GM_ERROR_INVALID_PKCS7OBJ_ATTR			GM_ERROR_BASE-9		//��Ч��PKCS7��������
#define GM_ERROR_PKCS7OBJ_READ_GENERAL			GM_ERROR_BASE-10	//PKCS7�������
#define GM_ERROR_PKCS7OBJ_READ_CHOOSE_RECIPIENT	GM_ERROR_BASE-11	//��ѡ��PKCS7�Ľ�����
#define GM_ERROR_PKCS7OBJ_READ_VERSION			GM_ERROR_BASE-12	//��֧��PKCS7�İ汾
#define GM_ERROR_IBCPARAMLIST_COUNT_OVERFLOW	GM_ERROR_BASE-13	//��Ч��IBCϵͳ�����������
#define GM_ERROR_GENERAL						GM_ERROR_BASE-14	//δ֪����
//#define GM_ERROR_PUBKEY_FAILURE					GM_ERROR_BASE-15	//
#define GM_ERROR_INVALID_IBCPARAM				GM_ERROR_BASE-16	//��Ч��IBCϵͳ����
#define GM_ERROR_BUFFER_TOO_SMALL				GM_ERROR_BASE-17	//�����С
#define GM_ERROR_PKCS7OBJ_WRITE_ORDER			GM_ERROR_BASE-18	//PKCS7������̲���˳�����
#define GM_ERROR_KEYEXPORT_FAILURE				GM_ERROR_BASE-19	//���ܻỰ��Կ����
#define GM_ERROR_KEYIMPORT_FAILURE				GM_ERROR_BASE-20	//���ܻỰ��Կ����
//#define	GM_ERROR_KEYGEN_FAILURE					GM_ERROR_BASE-21	//
#define GM_ERROR_INVALID_HASH_ALG				GM_ERROR_BASE-22	//��Ч��HASH�㷨

#define GM_ERROR_DEVICE_UNSUPPORTED				GM_ERROR_BASE-23	//��֧��ָ�������豸
#define GM_ERROR_DEVICE_OPERATION				GM_ERROR_BASE-24	//�豸����ʧ��
//#define GM_ERROR_INVALID_SECKEY_ATTR			GM_ERROR_BASE-25
//#define GM_ERROR_INVALID_HASH_ATTR			GM_ERROR_BASE-26
#define GM_ERROR_SIGNING_FAILURE				GM_ERROR_BASE-27	//ǩ��ʧ��
#define GM_ERROR_WRONG_KEYTYPE					GM_ERROR_BASE-28	//�������Կ����
#define GM_ERROR_ALG_UNSUPPORTED				GM_ERROR_BASE-29	//��֧��ָ�����㷨
#define GM_ERROR_MISSING_KEY					GM_ERROR_BASE-30	//δָ����Կ

#define GM_ERROR_SIGNATURE_VERIFICATION			GM_ERROR_BASE-31	//��֤ǩ��ʧ��
#define GM_ERROR_INVALID_CERTIFICATE			GM_ERROR_BASE-32	//��Ч��֤��
#define GM_ERROR_CURVE_UNSUPPORTED				GM_ERROR_BASE-33	//��֧��ָ������������
#define GM_ERROR_PARAM_GENERATION				GM_ERROR_BASE-34	//IBCϵͳ�������ɴ���
#define GM_ERROR_SCHEMA_UNSUPPORTED				GM_ERROR_BASE-35	//��֧��ָ���ı�ʶ���뷽ʽ
#define GM_ERROR_OPEN_FILE						GM_ERROR_BASE-36	//���ļ�����
#define GM_ERROR_CORRUPTED_PARAM				GM_ERROR_BASE-37	//IBC�����ƻ�
#define GM_ERROR_INCOMPLETE_IBCPRVKEY			GM_ERROR_BASE-38	//��������IBC˽Կ
#define GM_ERROR_SYSPARAM_MISSING				GM_ERROR_BASE-39	//ȱ��IBCϵͳ����
#define GM_ERROR_ENCODETYPE_UNSUPPORTED			GM_ERROR_BASE-40	//��֧��ָ���ı�ʶ��������
#define GM_ERROR_MISSING_ID						GM_ERROR_BASE-41	//ȱ�ٱ�ʶ��Ϣ

#define GM_ERROR_DEV_CONTAINTER					GM_ERROR_BASE-42	//�����豸��������
#define GM_ERROR_DEV_KEY						GM_ERROR_BASE-43	//�����豸��Կ����
#define GM_ERROR_DEV_KEYPARAM					GM_ERROR_BASE-44	//�豸��Կ������������
#define GM_ERROR_PARAM_UNSUPPORTED				GM_ERROR_BASE-45	//��֧��ָ���Ķ������
#define GM_ERROR_OPERATION_UNSUPPORTED			GM_ERROR_BASE-46	//��֧��ָ���Ĳ���
#define GM_ERROR_PKCS7OBJ_MISSING_ATTR			GM_ERROR_BASE-47	//δ����PKCS7���������

#define GM_ERROR_BER_ENCODE						GM_ERROR_BASE-48	//�����Ʊ������
#define GM_ERROR_BER_DECODE						GM_ERROR_BASE-49	//�����ƽ������
#define GM_ERROR_INVALID_MAC					GM_ERROR_BASE-50	//��Ч����Ϣ��֤��
#define GM_ERROR_INVALID_IBCPUBKEY				GM_ERROR_BASE-51	//��Ч��IBC��Կ
#define GM_ERROR_PKCS7OBJ_READ_ORDER			GM_ERROR_BASE-52	//PKCS7������̲���˳�����
#define GM_ERROR_PKCS7OBJ_OPT_UNSUPPORTED		GM_ERROR_BASE-53	//PKCS7����֧��ָ��������ѡ��
#define GM_ERROR_CORRUPTED_FILE					GM_ERROR_BASE-54	//���ƻ����ļ�
#define GM_ERROR_ALG_INTERNAL					GM_ERROR_BASE-55	//�㷨�ڲ�����
#define GM_ERROR_INVALID_IDDATA					GM_ERROR_BASE-56	//��Ч�ı�ʶ����
#define GM_ERROR_CORRUPTED_PRVKEY				GM_ERROR_BASE-58	//���ƻ���˽Կ
#define GM_ERROR_INVALID_TIME					GM_ERROR_BASE-59	//��Ч��ʱ������
#define GM_ERROR_DEVICE_PIN						GM_ERROR_BASE-60	//�豸PIN�����
#define GM_ERROR_INVALID_IBCPARAM_ATTR			GM_ERROR_BASE-61	//��Ч��IBC��������
#define GM_ERROR_INVALID_PUBKEY_ATTR			GM_ERROR_BASE-62	//��Ч�Ĺ�Կ����
#define GM_ERROR_INVALID_PRVKEY_ATTR			GM_ERROR_BASE-63	//��Ч��˽Կ����
#define GM_ERROR_ENCODING						GM_ERROR_BASE-64	//�������
#define GM_ERROR_INVALID_PARAM					GM_ERROR_BASE-65	//��Ч�Ĳ���
#define GM_ERROR_WIN_CRYPTO						GM_ERROR_BASE-66	//WINDOWS CSP ����ʧ��
#define GM_ERROR_PRVKEYLIST_COUNT_OVERFLOW		GM_ERROR_BASE-67	//˽Կ�����������
#define	GM_ERROR_LOADING_PRVKEY					GM_ERROR_BASE-68	//����˽Կ����
#define GM_ERROR_ACTIVIATION_FAILED				GM_ERROR_BASE-69	//����ʧ��
#define GM_ERROR_IBCKEYDEACTIVIATED				GM_ERROR_BASE-70	//����ֹ��IBC˽Կ
#define GM_ERROR_LOADING_CERTIFICATE			GM_ERROR_BASE-71	//����֤��ʧ��
#define GM_ERROR_VALUE_NOTSET					GM_ERROR_BASE-72	//ֵδ����
#define GM_ERROR_NETWORK_FAILURE				GM_ERROR_BASE-73	//�������
#define GM_ERROR_ILLFORM_MSG					GM_ERROR_BASE-74	//���Ϸ�����Ϣ
#define GM_ERROR_UNKNOWN_POLICY					GM_ERROR_BASE-75	//δ֪�Ĳ���
#define GM_ERROR_CORRUPTED_POLICY				GM_ERROR_BASE-76	//���ƻ��Ĳ���
#define	GM_ERROR_INVALID_PUBKEYFILE				GM_ERROR_BASE-77	//��Ч�Ĺ�Կ�ļ�
#define GM_ERROR_SSS_WRONGLEN					GM_ERROR_BASE-78	//�������Կ��ɢ����
#define GM_ERROR_SSS_WRONGFORMAT				GM_ERROR_BASE-79	//�������Կ��ɢ���ݸ�ʽ
#define GM_ERROR_SSS_RESTOREFAILED				GM_ERROR_BASE-80	//Shamir���ָܻ�����ʧ��
#define GM_ERROR_MISSING_PARAM					GM_ERROR_BASE-81	//�Գ���Կ����δ����
#define GM_ERROR_VALUE_ALREADY_SET				GM_ERROR_BASE-82	//ֵ�Ѿ�������
#define GM_ERROR_CERT_MISMATCH					GM_ERROR_BASE-83	//֤�鲻ƥ��
#define GM_ERROR_DEV_PARAM						GM_ERROR_BASE-84	//��Ч���豸����
#define GM_ERROR_DEV_NOCONTAINER				GM_ERROR_BASE-85	//�豸���޸�������
#define GM_ERROR_MISSING_DEV					GM_ERROR_BASE-86	//���豸
#define GM_ERROR_DATA_FORMAT					GM_ERROR_BASE-87	//���ݸ�ʽ����
#define GM_ERROR_POLICY_UNSUPPORTED				GM_ERROR_BASE-88	//��֧��ָ���Ĳ���
#define GM_ERROR_AUTH_ATTR_UNSUPPORTED			GM_ERROR_BASE-89	//��֧��ָ������֤����
#define GM_ERROR_MISSING_CERT					GM_ERROR_BASE-90	//ȱ��֤��
#define GM_ERROR_INVALID_VER					GM_ERROR_BASE-91	//��Ч�İ汾
#define GM_ERROR_INVALID_ATTR					GM_ERROR_BASE-92	//��Ч������
#define GM_ERROR_INVALID_PASSWD					GM_ERROR_BASE-93	//��Ч�Ŀ���
#define GM_ERROR_MSG_MODIFIED					GM_ERROR_BASE-94	//��Ϣ���޸�
#define GM_ERROR_DEVICE_LOCKED					GM_ERROR_BASE-95	//�豸������

#define GM_ERROR_STREAM_OPT						GM_ERROR_BASE-96	//������ʧ��
#define GM_ERROR_MAIL_ANALYSE					GM_ERROR_BASE-97	//�ʼ�����ʧ��
#define GM_ERROR_P7_CANCELED					GM_ERROR_BASE-98	//P7ȡ��

#define GM_ERROR_NEED_MORE_DATA					GM_ERROR_BASE-100	//��Ҫ����Ĵ�������
#define GM_ERROR_LACK_DATA_TO_VERIFY			GM_ERROR_BASE-101	//�����ݽ�����֤ǩ��
#define GM_ERROR_ALREADY_FINISHED				GM_ERROR_BASE-102	//�����Ѿ����

#define GM_ERROR_VERIFYING_FAILURE				GM_ERROR_BASE-103	//��֤ǩ��ʧ��
#define GM_ERROR_SECRETOP_FAILURE				GM_ERROR_BASE-104	//�ԳƲ���ʧ��
#define GM_ERROR_CREATE_TMPFILE_FAILURE			GM_ERROR_BASE-105	//������ʱ�ļ�ʧ��
#define GM_ERROR_LOCK_FAILURE					GM_ERROR_BASE-106	//������ʧ��
#define GM_ERROR_PRVKEY_REVOKED					GM_ERROR_BASE-107	//˽Կ�Ѿ�����

#define GM_ERROR_KEYREQT_INTERNAL				GM_ERROR_BASE-200	//����˽Կ�����ڲ�����
#define GM_ERROR_KEYREQT_UNQUALIFIED			GM_ERROR_BASE-201	//����δ����
#define GM_ERROR_KEYREQT_ILLFORMQUERY			GM_ERROR_BASE-202	//��Ч�Ĳ���

#define GM_ERROR_VERIFY_BUFFERLEN				GM_ERROR_BASE -221	//��֤BUFFER����ʧ�ܡ�
#define GM_ERROR_NET_READERROR					GM_ERROR_BASE -222  //���������
#define GM_ERROR_NET_LENGTHERROR				GM_ERROR_BASE -223  //�����ֽڳ��ȴ���
#define GM_ERROR_CANNOTCONNECT_ACTIVESERV		GM_ERROR_BASE -224	//�޷����Ӽ��������
#define GM_ERROR_SIZE_TOO_LARGE					GM_ERROR_BASE -224	//���ݹ���
#define GM_ERROR_ZIP_OPERATION					GM_ERROR_BASE -225

#define GM_ERROR_VERIFICATION_FAILED				GM_ERROR_BASE-300	//��֤ʧ��
// unable to get issuer certificate
#define GM_ERROR_UNABLE_TO_GET_ISSUER_CERT			GM_ERROR_BASE-301
// unable to get certificate CRL
#define GM_ERROR_UNABLE_TO_GET_CRL					GM_ERROR_BASE-302
// unable to decrypt certificate's signature
#define GM_ERROR_UNABLE_TO_DECRYPT_CERT_SIGNATURE	GM_ERROR_BASE-303
// unable to decrypt CRL's signature
#define GM_ERROR_UNABLE_TO_DECRYPT_CRL_SIGNATURE	GM_ERROR_BASE-304
// unable to decode issuer public key
#define GM_ERROR_UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY	GM_ERROR_BASE-305
// certificate signature failure
#define GM_ERROR_CERT_SIGNATURE_FAILURE				GM_ERROR_BASE-306
// CRL signature failure
#define GM_ERROR_CRL_SIGNATURE_FAILURE				GM_ERROR_BASE-307
// certificate is not yet valid
#define GM_ERROR_CERT_NOT_YET_VALID					GM_ERROR_BASE-308
// CRL is not yet valid
#define GM_ERROR_CRL_NOT_YET_VALID					GM_ERROR_BASE-309
// certificate has expired
#define GM_ERROR_CERT_HAS_EXPIRED					GM_ERROR_BASE-310
// CRL has expired
#define GM_ERROR_CRL_HAS_EXPIRED					GM_ERROR_BASE-311
// format error in certificate's notBefore field
#define GM_ERROR_IN_CERT_NOT_BEFORE_FIELD			GM_ERROR_BASE-312
// format error in certificate's notAfter field
#define GM_ERROR_IN_CERT_NOT_AFTER_FIELD			GM_ERROR_BASE-313
// format error in CRL's lastUpdate field
#define GM_ERROR_IN_CRL_LAST_UPDATE_FIELD			GM_ERROR_BASE-314
// format error in CRL's nextUpdate field
#define GM_ERROR_IN_CRL_NEXT_UPDATE_FIELD			GM_ERROR_BASE-315
// out of memory
#define GM_ERROR_OUT_OF_MEM							GM_ERROR_BASE-316
// self signed certificate
#define GM_ERROR_DEPTH_ZERO_SELF_SIGNED_CERT		GM_ERROR_BASE-317
// self signed certificate in certificate chain
#define GM_ERROR_SELF_SIGNED_CERT_IN_CHAIN			GM_ERROR_BASE-318
// unable to get local issuer certificate
#define GM_ERROR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY	GM_ERROR_BASE-319
// unable to verify the first certificate
#define GM_ERROR_UNABLE_TO_VERIFY_LEAF_SIGNATURE	GM_ERROR_BASE-320
// certificate chain too long
#define GM_ERROR_CERT_CHAIN_TOO_LONG				GM_ERROR_BASE-321
// certificate revoked
#define GM_ERROR_CERT_REVOKED						GM_ERROR_BASE-322
// invalid CA certificate
#define GM_ERROR_INVALID_CA							GM_ERROR_BASE-323
// invalid non-CA certificate (has CA markings)
#define GM_ERROR_INVALID_NON_CA						GM_ERROR_BASE-324
// path length constraint exceeded
#define GM_ERROR_PATH_LENGTH_EXCEEDED				GM_ERROR_BASE-325
// proxy path length constraint exceeded
#define GM_ERROR_PROXY_PATH_LENGTH_EXCEEDED			GM_ERROR_BASE-326
// proxy cerificates not allowed, please set the appropriate flag
#define GM_ERROR_PROXY_CERTIFICATES_NOT_ALLOWED		GM_ERROR_BASE-327
// unsupported certificate purpose
#define GM_ERROR_INVALID_PURPOSE					GM_ERROR_BASE-328
// certificate not trusted
#define GM_ERROR_CERT_UNTRUSTED						GM_ERROR_BASE-329
// certificate rejected
#define GM_ERROR_CERT_REJECTED						GM_ERROR_BASE-330
// application verification failure
#define GM_ERROR_APPLICATION_VERIFICATION			GM_ERROR_BASE-331
// subject issuer mismatch
#define GM_ERROR_SUBJECT_ISSUER_MISMATCH			GM_ERROR_BASE-332
// authority and subject key identifier mismatch
#define GM_ERROR_AKID_SKID_MISMATCH					GM_ERROR_BASE-333
// authority and issuer serial number mismatch
#define GM_ERROR_AKID_ISSUER_SERIAL_MISMATCH		GM_ERROR_BASE-334
// key usage does not include certificate signing
#define GM_ERROR_KEYUSAGE_NO_CERTSIGN				GM_ERROR_BASE-335
// unable to get CRL issuer certificate
#define GM_ERROR_UNABLE_TO_GET_CRL_ISSUER			GM_ERROR_BASE-336
// unhandled critical extension
#define GM_ERROR_UNHANDLED_CRITICAL_EXTENSION		GM_ERROR_BASE-337
// key usage does not include CRL signing
#define GM_ERROR_KEYUSAGE_NO_CRL_SIGN				GM_ERROR_BASE-338
// key usage does not include digital signature
#define GM_ERROR_KEYUSAGE_NO_DIGITAL_SIGNATURE		GM_ERROR_BASE-339
// unhandled critical CRL extension
#define GM_ERROR_UNHANDLED_CRITICAL_CRL_EXTENSION	GM_ERROR_BASE-340
// invalid or inconsistent certificate extension
#define GM_ERROR_INVALID_EXTENSION					GM_ERROR_BASE-341
// invalid or inconsistent certificate policy extension
#define GM_ERROR_INVALID_POLICY_EXTENSION			GM_ERROR_BASE-342
// no explicit policy
#define GM_ERROR_NO_EXPLICIT_POLICY					GM_ERROR_BASE-343
// RFC 3779 resource not subset of parent's resources
#define GM_ERROR_UNNESTED_RESOURCE					GM_ERROR_BASE-344
#define GM_ERROR_INVALID_PUBKEY						GM_ERROR_BASE-345
#define GM_ERROR_INVALID_PRVKEY						GM_ERROR_BASE-346
#define GM_ERROR_UNMATCHED_OTP						GM_ERROR_BASE-347

#define GM_ERROR_CONTAINER_EXIST				GM_ERROR_BASE-500	//�����Ѿ�����
#define GM_ERROR_DEVICE_FULL					GM_ERROR_BASE-501	//�豸����
#define GM_ERROR_UNKNOWN						GM_ERROR_BASE-502	//δ֪�豸����
#define GM_ERROR_DEVICE_NOTEXIST				GM_ERROR_BASE-503	//�豸������
#define GM_ERROR_DEVICE_COMM					GM_ERROR_BASE-504	//���豸ͨѶ����
#define GM_ERROR_DEVICE_OPEN					GM_ERROR_BASE-505	//���豸�豸
#define GM_ERROR_DEVICE_AUTH					GM_ERROR_BASE-506	//�豸������֤ʧ��
#define GM_ERROR_SMSGATE_UNAVL					GM_ERROR_BASE-507	//SMS Gate ������
#define GM_ERROR_LICENSE_NONE					GM_ERROR_BASE-508	//δ����LICENSE������ЧLICENSE
#define GM_ERROR_INVALID_LICENSE				GM_ERROR_BASE-509	//��Ч��LICENSE
#define GM_ERROR_LICENSE_EXIST					GM_ERROR_BASE-510	//LICENSE�Ѿ�����
#define GM_ERROR_IP_DISALLOWED					GM_ERROR_BASE-511	//IP����ֹ
#define GM_ERROR_DEVICE_UNINITED				GM_ERROR_BASE-512	//�豸��ʼ��
#define GM_ERROR_IP_TMPRBLKED					GM_ERROR_BASE-513	//IP��ʱ��ֹ
#define GM_ERROR_VERSION_MISMATCH				GM_ERROR_BASE-514	//�汾��ƥ��
#define GM_ERROR_DEVICE_CIPHER_ENC				GM_ERROR_BASE-515
#define GM_ERROR_DEVICE_CIPHER_DEC				GM_ERROR_BASE-516
#define GM_ERROR_DEVICE_DIGEST					GM_ERROR_BASE-517
#define GM_ERROR_DEVICE_KEY_INUSE				GM_ERROR_BASE-518
#define GM_ERROR_DEVICE_NOEXIST					GM_ERROR_BASE-519

#define  PKCS7_DATA					1 
//  A flag indicating the contents of a PKCS #7 message is "Data". 
#define  PKCS7_SIGNED_DATA			2 
//  A flag indicating the contents of a PKCS #7 message is "SignedData". 
#define  PKCS7_ENVELOPED_DATA		3 
//  A flag indicating the contents of a PKCS #7 message is "EnvelopedData". 
#define  PKCS7_SIGN_ENV_DATA		4 
//  A flag indicating the contents of a PKCS #7 message is "SignedAndEnvelopedData". 
#define  PKCS7_DIGESTED_DATA		5 
//  A flag indicating the contents of a PKCS #7 message is "DigestedData". 
#define  PKCS7_ENCRYPTED_DATA		6 
//	A flag indicating the contents of a PKCS #7 message is "EncryptedData". 
#define  PKCS7_AUTH_ENV_DATA		7 
//  As the new AUTHENVELOPED_DATA in CMS
#define  PKCS7_SIGN_AUTH_ENV_DATA	8
//  A flag indicating the contents of a message is "SignedAndAuthEnvelopedData" data. 
#define	 PKCS7_COMPRESSED_DATA		9
//  A flag indicating the data to be compressed

#define MASK_P7_FORMAT				0x0000FFFF
#define GM_SMAIL_ZDM				0x10000000
#define GM_SMAIL_B64				0x20000000
#define GM_SMAIL_F64				0x40000000
#define GM_SMAIL_COMP				0x80000000
#define GM_SMAIL_IBC				0x01000000

/******************Library Context Parameter****************/
#define LIBCTX_ATTR_BASE			0
#define LIBCTX_ATTR_VERSION			LIBCTX_ATTR_BASE+1
#define LIBCTX_ATTR_IBCSYSATTR		LIBCTX_ATTR_BASE+2
#define LIBCTX_ATTR_IBCPARAMNUM		LIBCTX_ATTR_BASE+3
#define LIBCTX_ATTR_PRVKEYNUM		LIBCTX_ATTR_BASE+4
#define LIBCTX_ATTR_IBCPARAM		LIBCTX_ATTR_BASE+5
#define LIBCTX_ATTR_PRVKEY			LIBCTX_ATTR_BASE+6
#define LIBCTX_ATTR_AUTHSERVER		LIBCTX_ATTR_BASE+7
#define LIBCTX_ATTR_CAFILE			LIBCTX_ATTR_BASE+8
#define LIBCTX_ATTR_CRLFILE			LIBCTX_ATTR_BASE+9
#define LIBCTX_ATTR_DELPRVKEY		LIBCTX_ATTR_BASE+10
#define LIBCTX_ATTR_DEVREMOVED		LIBCTX_ATTR_BASE+11
#define LIBCTX_ATTR_ZDMTEMPL		LIBCTX_ATTR_BASE+12
#define LIBCTX_ATTR_DELIBCPARAM		LIBCTX_ATTR_BASE+13
#define LIBCTX_ATTR_DELCRLFILE		LIBCTX_ATTR_BASE+14


/**********************Identity Parameter*******************/
#define ID_ATTR_BASE				0
#define ID_ATTR_ID					ID_ATTR_BASE+1
#define ID_ATTR_DNANDSERIAL			ID_ATTR_BASE+2
//#define ID_ATTR_DISTRICT			ID_ATTR_BASE+3
#define ID_ATTR_SCHEMA				ID_ATTR_BASE+4

#define ID_ATTR_PRVKEY				ID_ATTR_BASE+5
#define ID_ATTR_PRVKEYEXT			ID_ATTR_BASE+6
#define ID_ATTR_PUBKEY				ID_ATTR_BASE+7
#define ID_ATTR_DEVICE				ID_ATTR_BASE+8
#define ID_ATTR_STATUS				ID_ATTR_BASE+9
#define ID_ATTR_ENCODEID_IMP		ID_ATTR_BASE+10
#define ID_ATTR_IBCPARAM			ID_ATTR_BASE+11
#define ID_ATTR_VERIFYSTATUS		ID_ATTR_BASE+12
#define ID_ATTR_DECRYPTTIME			ID_ATTR_BASE+13
#define ID_ATTR_ALG					ID_ATTR_BASE+14
#define ID_ATTR_CERT				ID_ATTR_BASE+15
#define ID_ATTR_ENCODEDID			ID_ATTR_BASE+16
#define ID_ATTR_AUTH_ATTR			ID_ATTR_BASE+17
#define ID_ATTR_IDTAG				ID_ATTR_BASE+18
#define ID_ATTR_POLICY				ID_ATTR_BASE+19
#define ID_ATTR_CL_PUBKEY			ID_ATTR_BASE+20
//#define	ID_ATTR_CL_PRVKEY			ID_ATTR_BASE+21
#define ID_ATTR_GROUP				ID_ATTR_BASE+22

#define IBCPARAM_ATTR_BASE			0
#define IBCPARAM_ATTR_DNSERIAL		IBCPARAM_ATTR_BASE+1
#define	IBCPARAM_ATTR_SCHEMA		IBCPARAM_ATTR_BASE+2
#define IBCPARAM_ATTR_KGA			IBCPARAM_ATTR_BASE+3
#define IBCPARAM_ATTR_PAIRING		IBCPARAM_ATTR_BASE+4

#define PRVKEY_ATTR_BASE				0
#define IBCPRVKEY_ATTR_BASICID			PRVKEY_ATTR_BASE+1
#define IBCPRVKEY_ATTR_IDTAG			PRVKEY_ATTR_BASE+2
#define IBCPRVKEY_ATTR_ENCODEDID		PRVKEY_ATTR_BASE+3
#define IBCPRVKEY_ATTR_DNANDSERIAL		PRVKEY_ATTR_BASE+4
#define PRVKEY_ATTR_DNANDSERIAL			IBCPRVKEY_ATTR_DNANDSERIAL
#define IBCPRVKEY_ATTR_SCHEMA			PRVKEY_ATTR_BASE+5
#define IBCPRVKEY_ATTR_VALIDTIME		PRVKEY_ATTR_BASE+6
#define PRVKEY_ATTR_VALIDTIME			IBCPRVKEY_ATTR_VALIDTIME
#define IBCPRVKEY_ATTR_KGA				PRVKEY_ATTR_BASE+7
#define IBCPRVKEY_ATTR_ALG				PRVKEY_ATTR_BASE+8
#define IBCPRVKEY_ATTR_STATUS			PRVKEY_ATTR_BASE+9
#define IBCPRVKEY_ATTR_USAGE			PRVKEY_ATTR_BASE+10	
#define PRVKEY_ATTR_USAGE				IBCPRVKEY_ATTR_USAGE
#define IBCPRVKEY_ATTR_ACTVPOLICY		PRVKEY_ATTR_BASE+11
#define IBCPRVKEY_ATTR_ACTVKEY			PRVKEY_ATTR_BASE+12
#define IBCPRVKEY_ATTR_ACTIVIATIONID	PRVKEY_ATTR_BASE+13
#define IBCPRVKEY_ATTR_PRVKEY			PRVKEY_ATTR_BASE+14
#define IBCPRVKEY_ATTR_SYSPARAM			PRVKEY_ATTR_BASE+15
#define PKCKEY_ATTR_CERT				PRVKEY_ATTR_BASE+16
#define PRVKEY_ATTR_DEVHANDLE			PRVKEY_ATTR_BASE+17
#define PRVKEY_ATTR_PRDKEY				PRVKEY_ATTR_BASE+18
#define PRVKEY_ATTR_BIND_ID				PRVKEY_ATTR_BASE+19
#define PRVKEY_ATTR_ALG_CATEGORY		PRVKEY_ATTR_BASE+20
#define IBCPRVKEY_ATTR_KEYVALUE			PRVKEY_ATTR_BASE+21
#define IBCPRVKEY_ATTR_CLPRVKEY			PRVKEY_ATTR_BASE+22
#define IBCPRVKEY_ATTR_GROUP			PRVKEY_ATTR_BASE+23
#define IBCPRVKEY_ATTR_KEYELEMENT		PRVKEY_ATTR_BASE+24
#define IBCPRVKEY_ATTR_PAIRING			PRVKEY_ATTR_BASE+25	
#define IBCPRVKEY_ATTR_KEYINDEX			PRVKEY_ATTR_BASE+26
#define IBCPRVKEY_ATTR_ECS_KEY			PRVKEY_ATTR_BASE+27
#define IBCPRVKEY_ATTR_PRVKEYDATA		PRVKEY_ATTR_BASE+28
#define IBCPRVKEY_ATTR_PUBKEYDATA		PRVKEY_ATTR_BASE+29

#define PUBKEY_ATTR_BASE			0
#define IBCPUBKEY_ATTR_BASICID		PUBKEY_ATTR_BASE+1
#define IBCPUBKEY_ATTR_IDTAG		PUBKEY_ATTR_BASE+2
#define IBCPUBKEY_ATTR_ENCODEDID	PUBKEY_ATTR_BASE+3
#define IBCPUBKEY_ATTR_DNANDSERIAL	PUBKEY_ATTR_BASE+4
#define IBCPUBKEY_ATTR_SCHEMA		PUBKEY_ATTR_BASE+5	
#define PUBKEY_ATTR_USAGE			PUBKEY_ATTR_BASE+6
#define PUBKEY_ATTR_BIND_ID			PUBKEY_ATTR_BASE+7
#define PUBKEY_ATTR_ALG				PUBKEY_ATTR_BASE+8
#define IBCPUBKEY_ATTR_PAIRING		PUBKEY_ATTR_BASE+8
#define PUBKEY_ATTR_MASK			PUBKEY_ATTR_BASE+9
#define IBCPUBKEY_ATTR_KEYINDEX		PUBKEY_ATTR_BASE+10
#define CLEPUBKEY_ATTR_PUBKEYDATA	PUBKEY_ATTR_BASE+11

#define	GM_ENCODEID_ENCRYPTION		0x1
#define GM_ENCODEID_SIGNATURE		0x2
#define GM_ENCODEID_EXCHANGE		0x4

#define GM_ID_STATUS_ACTIVE			1
#define GM_ID_STATUS_INACTIVE		0

#define GM_ID_SCHEMA_ENYOUNG		0	//forward compatable
#define GM_ID_SCHEMA_ECSCHEMA		1
#define GM_ID_SCHEMA_CHNSCHEMA		2
#define GM_ID_SCHEMA_RFC822			3
#define GM_ID_SCHEMA_PHONE			4
#define GM_ID_SCHEMA_QQ				5
#define GM_ID_SCHEMA_SKYPE			6
#define GM_ID_SCHEMA_PLAIN			7

#define GM_ID_SCHEMA_MIN			GM_ID_SCHEMA_ENYOUNG
#define GM_ID_SCHEMA_MAX			GM_ID_SCHEMA_SKYPE
#define GM_ID_SCHEMA_UNKNOWN		0xFFFFFFFF

/********************PKCS7 Parameter************************/
#define PKCS7_ATTR_BASE				0
#define PKCS7_ATTR_CONTENT_FORMAT	PKCS7_ATTR_BASE+1
#define PKCS7_ATTR_CRYPT_ALG		PKCS7_ATTR_BASE+2
#define PKCS7_ATTR_SIGNATURE		PKCS7_ATTR_BASE+4
#define PKCS7_ATTR_KEYEXCHANGE		PKCS7_ATTR_BASE+5
#define PKCS7_ATTR_RECIPIENT_LIST	PKCS7_ATTR_BASE+6
#define PKCS7_ATTR_SIGNER_LIST		PKCS7_ATTR_BASE+7
#define PKCS7_ATTR_RECIPIENT_INDEX	PKCS7_ATTR_BASE+8
#define PKCS7_ATTR_DATA_SIZE		PKCS7_ATTR_BASE+9
#define PKCS7_ATTR_SENDER			PKCS7_ATTR_BASE+10
#define PKCS7_ATTR_SESSIONKEY		PKCS7_ATTR_BASE+11	
#define PKCS7_ATTR_KDF_ALG			PKCS7_ATTR_BASE+12
#define PKCS7_ATTR_FLAGS			PKCS7_ATTR_BASE+13
#define PKCS7_ATTR_CONTENT_TYPE		PKCS7_ATTR_BASE+14
#define PKCS7_ATTR_CERT_NUM			PKCS7_ATTR_BASE+15
#define PKCS7_ATTR_CERT_VAL			PKCS7_ATTR_BASE+16
#define PKCS7_ATTR_DEVICE			PKCS7_ATTR_BASE+17
#define PKCS7_ATTR_NOLIBPRVKEY		PKCS7_ATTR_BASE+18

#define PKCS7_ATTR_FILE_EXTENSION	PKCS7_ATTR_BASE+30
#define PKCS7_ATTR_TIME_STAMP		PKCS7_ATTR_BASE+31
	
#define SECKEY_ATTR_BASE			0
#define SECKEY_ATTR_ALGID			SECKEY_ATTR_BASE+1
#define SECKEY_ATTR_BLKLEN			SECKEY_ATTR_BASE+2
#define SECKEY_ATTR_KEYLEN			SECKEY_ATTR_BASE+3
#define SECKEY_ATTR_SALT			SECKEY_ATTR_BASE+4
#define SECkEY_ATTR_PERMISSIONS		SECKEY_ATTR_BASE+5
#define SECKEY_ATTR_IV				SECKEY_ATTR_BASE+6
#define SECKEY_ATTR_PADDING			SECKEY_ATTR_BASE+7
#define SECKEY_ATTR_MODE			SECKEY_ATTR_BASE+8
#define SECKEY_ATTR_MODE_BITS		SECKEY_ATTR_BASE+9
#define SECKEY_ATTR_WORKINGIV		SECKEY_ATTR_BASE+10
#define SECKEY_ATTR_NEWKEYINFO		SECKEY_ATTR_BASE+11
#define SECKEY_ATTR_SECRET			SECKEY_ATTR_BASE+65
#define SECKEY_ATTR_PASSWD			SECKEY_ATTR_BASE+66
#define SECKEY_ATTR_ITER			SECKEY_ATTR_BASE+67
#define SECKEY_ATTR_DEVICE			SECKEY_ATTR_BASE+68
#define SECKEY_ATTR_COUNTER			SECKEY_ATTR_BASE+69

#define HASH_ATTR_BASE				0
#define HASH_ATTR_MDLEN				HASH_ATTR_BASE+1
#define HASH_ATTR_DEVICE			HASH_ATTR_BASE+2

#define MAC_ATTR_BASE				0
#define MAC_ATTR_SECRET				MAC_ATTR_BASE+1
#define MAC_ATTR_KEYLEN				MAC_ATTR_BASE+2
#define MAC_ATTR_MACLEN				MAC_ATTR_BASE+3
#define MAC_ATTR_DEVICE				MAC_ATTR_BASE+4
#define MAC_ATTR_PADDING			MAC_ATTR_BASE+5
#define MAC_ATTR_IV					MAC_ATTR_BASE+6

#define DEM_ATTR_BASE				0
#define DEM_MAC_ATTR_SECRET			DEM_ATTR_BASE+1
#define DEM_SECKEY_ATTR_SECRET		DEM_ATTR_BASE+2
#define DEM_SECKEY_ATTR_IV			DEM_ATTR_BASE+3
#define DEM_SECKEY_ATTR_DEVICE		DEM_ATTR_BASE+4
#define DEM_MAC_ATTR_DEVICE			DEM_ATTR_BASE+5


#define CONTAINER_ATTR_BASE			0
#define CONTAINER_ATTR_NAME			CONTAINER_ATTR_BASE+1
#define CONTAINER_ATTR_ALGTYPE		CONTAINER_ATTR_BASE+2
#define CONTAINER_ATTR_SUBJECT		CONTAINER_ATTR_BASE+3
#define CONTAINER_ATTR_DNSERIAL		CONTAINER_ATTR_BASE+4
#define CONTAINER_ATTR_BASICID		CONTAINER_ATTR_BASE+5

/******************Crypt Device**********************/
#define GM_DEVICE_CNSTD				1
#define GM_DEVICE_PKCS11			2
#define GM_DEVICE_CRYPTOAPI			3
#define GM_DEVICE_SJY				4
#define GM_DEVICE_VIRT				5
#define GM_DEVICE_XENGINE			6

#define GM_KEY_USAGE_KEXECHANGE		1
#define GM_KEY_USAGE_SIGNATURE		2

/******Compatbile with X509*****************/
#define KEYUSAGE_SIGN				0x01	//bit 0
#define KEYUSAGE_KEX				0x10	//bit 4
#define KEYUSAGE_DEC				0x100	//bit 8

#define KEYUSAGE_FREEEMAIL			0x4000	//bit 14 extended by OLYM for free email //��Ѱ�ȫ�ʼ�

#define KEYUSAGE_EMAIL_ENC			0x80000000
#define KEYUSAGE_EMAIL_DEC_SIGN		0x40000000

#define KEYUSAGE_GTFE_ENC			0x20000000
#define KEYUSAGE_GTFE_DEC_SIGN		0x10000000

#define KEYUSAGE_GTFS_ENC			0x08000000
#define KEYUSAGE_GTFS_DEC_SIN		0x04000000
#define KEYUSAGE_SSLVPN				0x02000000
#define KEYSUAGE_ESMS				0x01000000
#define KEYUSAGE_OA_ENC				0x00010000
#define KEYUSAGE_OA_DEC_SIGN		0x00008000	//bit 15 extended by 

#define IBC_APP_USAGE_EMAIL			(KEYUSAGE_EMAIL_ENC | KEYUSAGE_EMAIL_DEC_SIGN) //��ȫ�ʼ�
#define IBC_APP_USAGE_GTFE			(KEYUSAGE_GTFE_ENC | KEYUSAGE_GTFE_DEC_SIGN) //�ļ�����
#define IBC_APP_USAGE_GTFS			(KEYUSAGE_GTFS_ENC | KEYUSAGE_GTFS_DEC_SIN)	 //���̼���
#define IBC_APP_USAGE_SSLVPN		(KEYUSAGE_SSLVPN)	//Զ�̰�ȫ����
#define IBC_APP_USAGE_LOGIN			(KEYUSAGE_OA_DEC_SIGN)	//��ȫ��¼

#define IBC_APPID_EMAIL				0x01
#define IBC_APPID_GTFE				0x02
#define	IBC_APPID_GTFS				0x04
#define IBC_APPID_SSL				0x08
#define IBC_APPID_OA				0x10
#define IBC_APPID_ESMS				0x20

#define GM_KEY_TYPE_PUBLIC			1
#define GM_KEY_TYPE_PRIVATE			2
#define GM_KEY_TYPE_SECRET			3

#define GM_SIGNATURE_VERIFY_FAILURE_MISSING_KEY		-1
#define GM_SIGNATURE_VERIFY_FAILURE					0
#define GM_SIGNATURE_VERIFY_SUCCESS					1

#define P7_TEXT						0x1
#define P7_NOCERTS					0x2
#define P7_NOSIGS					0x4
#define P7_NOCHAIN					0x8
#define P7_NOINTERN					0x10
#define P7_NOVERIFY					0x20
#define P7_DETACHED					0x40
#define P7_BINARY					0x80
#define P7_NOATTR					0x100
#define	P7_NOSMIMECAP				0x200
#define P7_NOOLDMIMETYPE			0x400
#define P7_CRLFEOL					0x800
#define P7_STREAM					0x1000
#define P7_NOCRL					0x2000
#define P7_DEFLEN					0x80000000 //output with definit-length structure

#ifndef MBSTRING_FLAG
#define MBSTRING_FLAG				0x1000
#define MBSTRING_UTF8				(MBSTRING_FLAG)
#define MBSTRING_ASC				(MBSTRING_FLAG|1)
#define MBSTRING_BMP				(MBSTRING_FLAG|2)
#define MBSTRING_UNIV				(MBSTRING_FLAG|4)
#endif

// For application retrieve attribute from certificate
#define CERT_ATTR_NAME_BYTES		1
#define CERT_ATTR_COMMONNAME		2
#define CERT_ATTR_ISSUERNAME		3
#define CERT_ATTR_SERIAL			4
#define CERT_ATTR_VALIDSTART		5
#define CERT_ATTR_VALIDEND			6
#define CERT_ATTR_SUBJECTNAME		7
#define CERT_ATTR_EMAIL				8

typedef struct {
	int32 year;
	int32 month;
	int32 day;
	int32 hour;
	int32 minute;
	int32 second;
}GMTime;

typedef struct{
	uint32 octLen;
	uint8 *oct;
}OctString;

#define GMOctStrFree(oStr)				do{if((oStr)->oct) GM_free((oStr)->oct);}while(0)
#define GMOctStrCmp(src, dst)			((src)->octLen==(dst)->octLen && !memcmp((src)->oct, (dst)->oct, (src)->octLen))

typedef struct {
	OctString domain;
	OctString strSerial;
	uint32 serial;
}DomainAndSerial;

#define GMDomainAndSerialFree(dns)		do{if((dns)->domain.oct) GM_free((dns)->domain.oct); if((dns)->strSerial.oct) GM_free((dns)->strSerial.oct);}while(0)
#define GMDomainAndSerialCmp(src, dst)	(GMOctStrCmp(&((src)->domain), &((dst)->domain)) && ((src)->serial == (dst)->serial))

typedef struct{
	GMTime nBTime;
	GMTime nATime;
}Validity;

typedef struct{
	int8 Container[128];
	int8 Provider[128];
}CertKeyInfo;

typedef struct{
	uint8	groupID;
	OctString point;
}ECPoint;

typedef struct{
	DomainAndSerial DNAndSerial;
	OctString serverAddress;
	uint8 transProto;
	uint16 port;
	uint32 authProto;
	uint32 cipherAlg;
	OctString authServerName;
}AuthServerInf;

typedef enum {
	DEVICE_INITIALISE,				/* Initialise device for use */
	DEVICE_AUTHENT_USER,			/* Authenticate user to device */
	DEVICE_AUTHENT_SUPERVISOR,		/* Authenticate supervisor to dev.*/
	DEVICE_SET_AUTHENT_USER,		/* Set user authent.value */
	DEVICE_SET_AUTHENT_SUPERVISOR,	/* Set supervisor auth.val.*/
	DEVICE_ZEROISE,					/* Zeroise device */
	DEVICE_LOGGEDIN,				/* Whether user is logged in */
	DEVICE_LABEL,					/* Device/token label */
	DEVICE_SERIAL,
	DEVICE_CLEARGCACHE,
	DEVICE_LTYPE,
	DEVICE_LHANDLE,
	DEVICE_PASSPHRASE,
	DEVICE_KEYIDLIST,
}DEVICE_ATTRIBUTE_TYPE;

#if !defined(EYIBC_EXPORTS) && !defined(__APPLE__)
	#include "helper.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif
extern int32 use_chn_oid;
extern int32 use_chn_code_method;

typedef int (*IBCParamSearchFunc)(uint8 *id, int32 idLen, int32 idType, IBCParamContext *param);
typedef int (*IBCParamSearchFuncEx)(uint8 *id, int32 idLen, int32 idType, IBCParamContext *param, OctString *rid);
typedef int (*IBCParamSearchByDomainSerialFunc)(DomainAndSerial *dns, IBCParamContext *param);
typedef int (*IBCPrvKeyGenerateFunc)(uint8 *id, int32 idLen, int32 idType, DomainAndSerial *dns, PrvKeyContext *prvKey);
typedef int (*IBCCheckIdStatusFunc)(uint8 *id, int32 idLen, int32 idType, DomainAndSerial *dns, Validity *validity);

#ifdef LINUX
extern IBCParamSearchFunc SearchRecipientParamFunc;
extern IBCParamSearchFuncEx SearchRecipientParamFuncEx;
extern IBCPrvKeyGenerateFunc GenerateRecipientPrvKeyFunc;
extern IBCParamSearchByDomainSerialFunc SearchSignerParamFunc;
extern IBCCheckIdStatusFunc CheckIdStatusFunc;
#endif

/******************Library Context Operation****************/
int32 CreateLibCtx(
	LibContext *libCtx
);

void DestroyLibCtx(
	LibContext libCtx
);

LibContext DupLibCtx(
	LibContext libCtx
);

int32 SetLibCtxAttribute(
	LibContext libCtx, 
	uint32 ctxAttributeType, 
	void *ctxAttributeValue, 
	uint32 infoLen
);
#define AddLibCtxIBCParam(libCtx, ibcParamCtx)	SetLibCtxAttribute(libCtx, LIBCTX_ATTR_IBCPARAM, ibcParamCtx, 0)
#define AddLibCtxPrivateKey(libCtx, prvKeyCtx)	SetLibCtxAttribute(libCtx, LIBCTX_ATTR_PRVKEY, prvKeyCtx, 0)
#define AddLibCtxAuthServerInf(libCtx, authSvrInf)  SetLibCtxAttribute(libCtx, LIBCTX_ATTR_AUTHSERVER, authSvrInf, 0)
#define AddLibCtxCACert(libCtx, CAFile)	SetLibCtxAttribute(libCtx, LIBCTX_ATTR_CAFILE, CAFile, 0)
#define AddLibCtxCRL(libCtx, CRL) SetLibCtxAttribute(libCtx, LIBCTX_ATTR_CRLFILE, CRL, 0)
#define DelLibCtxPrivateKey(libCtx, prvKeyCtx)	SetLibCtxAttribute(libCtx, LIBCTX_ATTR_DELPRVKEY, prvKeyCtx, 0)
#define DeleteDevKeyFromLibCtx(libCtx, devCtx)	SetLibCtxAttribute(libCtx, LIBCTX_ATTR_DEVREMOVED, devCtx, 0)
#define DeleteIBCParamFromLibCtx(libCtx, ibcParamCtx)	SetLibCtxAttribute(libCtx, LIBCTX_ATTR_DELIBCPARAM, ibcParamCtx, 0)
#define DeleteLibCtxCRL(libCtx, CRL) SetLibCtxAttribute(libCtx, LIBCTX_ATTR_DELCRLFILE, CRL, 0)

int32 GetLibCtxAttribute(
	LibContext libCtx, 
	uint32 ctxAttributeType, 
	void *ctxAttributeValue,
	uint32 *vLen
);

int32 SearchLibCtxIBCParam(
	LibContext libCtx, 
	DomainAndSerial *DNAndSerial, 
	IBCParamContext *ibcParamCtx
);

int32 SearchLibCtxPrvKey(
	LibContext hLibCtx, 
	DomainAndSerial *dns, 
	uint8 *id,
	uint32 idLen,
	PrvKeyContext *prvKeyCtx
);

int32 SearchLibCtxCertificate(
	LibContext hLibCtx, 
	DomainAndSerial *dns, 
	uint8 *id,
	uint32 idLen,
	CertificateContext *certCtx
);

/**********************Identity Operation*******************/

int32 CreateIdentity(
	Identity *id
);

void DestroyIdentity(
	Identity id
);

int32 SetIdentityAttribute(
	Identity id, 
	uint32 idAttributeType, 
	void *idAttributeValue, 
	uint32 vLen
);

int32 SetIdentityAttributeInteger(
	Identity id, 
	uint32 idAttributeType, 
	int32 idAttributeValue
);

int32 GetIdentityAttribute(
	Identity id, 
	uint32 idAttributeType, 
	void *idAttributeValue,
	uint32 *vLen
);

int32 EncodeIBCIdentityEx(
	uint32 schema, 
	OctString *encID, 
	OctString *rawID, 
	uint8 idType,
	uint32 keyType,	
	DomainAndSerial *DNAndSerial,
	OctString *tag, 
	GMTime *decTime, 
	OctString *policy,
	IBCParamContext ibcParamCtx
);

int32 GetBasicIDFromEncodedID(
	OctString *basicID,
	OctString *encodedID,
	uint32 schema
);


/*******************Identity List Operation*****************/

int32 CreateIdentityList(
	IdentityList *idList
);

void DestroyIdentityList(
	IdentityList idList
);

IdentityList DupIdentityList(
	IdentityList srcList
);

int32 AddIdentityToList(
	IdentityList idList, 
	Identity id
);

int32 GetIdentityFromList(
	IdentityList idList, 
	int32 index, 
	Identity *id
);

int32 DeleteIdentityFromList(
	IdentityList idList, 
	int32 index
);

int32 GetIdentityListCount(
	IdentityList idList, 
	uint32 *idCount
);

int32 AddP7IBERecipientToList(
	IdentityList idList, 
	uint8 *recp, 
	uint32 recpLen,
	uint32 algType, 
	DomainAndSerial *DNAndSerial, 
	GMTime *decryptTime, 
	IBCParamContext ibcParamCtx
);

int32 AddP7IBERecipientToListEx(
	IdentityList idList, 
	uint8 *recp, 
	uint32 recpLen,
	uint32 algType, 
	DomainAndSerial *DNAndSerial, 
	GMTime *decryptTime, 
	uint8 *policy,
	uint32 policyLen,
	uint8 *idTag,
	uint32 idTagLen,
	IBCParamContext ibcParamCtx
);

int32 AddP7PKERecipientToList(
	IdentityList idList,
	CertificateContext certCtx,
	PubKeyContext pubKeyCtx
);

int32 AddP7CLPKERecipientToList(
	IdentityList idList, 
	uint8 *recp, 
	uint32 recpLen,
	uint8 *clPubKey,
	uint32 clKeyLen,
	uint32 algType, 
	DomainAndSerial *DNAndSerial, 
	GMTime *decryptTime, 
	IBCParamContext paraInfo
);

int32 AddP7SignerToList(
	IdentityList idList, 
	PrvKeyContext prvKeyCtx, 
	uint32 algType, 
	CertificateContext certCtx, 
	uint8 *signer, 
	uint32 signerLen,
	DomainAndSerial *DNAndSerial, 
	DeviceContext devCtx
);

int32 AddP7SignerToListEx(
	IdentityList idList, 
	PrvKeyContext prvKeyCtx, 
	uint32 algType, 
	CertificateContext certCtx, 
	uint8 *signer, 
	uint32 signerLen,
	uint8 *policy,
	uint32 policyLen,
	uint8 *idTag,
	uint32 idTagLen,
	DomainAndSerial *DNAndSerial, 
	DeviceContext devCtx
);

/************************Public Key Operation************************/
uint32 GetDefaultEnvAlg(uint32 nKga);
uint32 GetDefaultSignAlg(uint32 nKga);

int32 CreatePKCPubKeyObjectFromFile(	//should encapsulate the interface to process public key files
	PubKeyContext *pubKeyCtx, 
	int8 *keyFile
);

int32 CreatePKCPubKeyObjectFromData(
	PubKeyContext *pubKeyCtx, 
	uint8 *keyData,
	uint32 keyLen
);

int32 CreatePKCPubKeyObjectFromStore(
	PubKeyContext *pubKeyCtx, 
	uint8 *containerName,
	uint32 nameLen,
	int8 *provName
);

int32 CreatePKCPubKeyObjectFromCertificate(
	PubKeyContext *pubKeyCtx, 
	CertificateContext cert
);


/*
 * Func: Given a container handle and the key usage, 
 *		 locate the public key of the key usage in the container and
 *		 create a key handle.
 * Ret: GM_SUCCESS or error values
 */
int32 CreatePKCPubKeyObjectFromContainer(
	PubKeyContext *pubKeyCtx, 
	DevCntContext cntCtx,
	uint32 keyUsage
);

int32 CreatePKCPubKeyObjectFromDevice(
	PubKeyContext *pubKeyCtx, 
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	uint32 keyUsage
);

#define PRE_COMPUTE_G	0x1
#define POINT_XY		0x2

int32 CreateSM2PubKeyObjectFromMem(
	PubKeyContext *pubKeyCtx, 
	uint8 *keyBuf,
	uint32 keyLen,
	uint32 flags
);

int32 CreateIBCPubKeyObject(
	PubKeyContext *pubKeyCtx, 
	uint32 algType, 
	IBCParamContext ibcParamCtx, 
	uint8 *encID,
	uint32 eidLen
);

int32 CreateIBCPubKeyObjectFromEid(
	PubKeyContext *ctx, 
	uint32 algType, 
	IBCParamContext hParam, 
	uint8 *eid,
	uint32 eidLen,
	uint32 groudID
);

int32 GenerateSM2KeyPair(
	uint8 *pubKey, 
	uint32 *pubLen,
	uint8 *prvKey,
	uint32 *prvLen,
	uint8 *passwd,
	uint32 passwdLen,
	uint32 nPsize,
	uint32 nFormat
);

int32 CreateIBCPubKeyObjectEx(
	PubKeyContext *pubKeyCtx, 
	uint32 algType, 
	IBCParamContext ibcParamCtx, 
	uint8 *rawID,
	uint32 ridLen,
	uint8 idType,
	uint32 keyType,	
	uint8 *tag,
	uint32 tagLen
);

int32 CreateIBCPubKeyObjectEx2(
	PubKeyContext *pubKeyCtx, 
	uint32 algType, 
	IBCParamContext hParam, 
	uint8 *rawID,
	uint32 ridLen,
	uint8 idType,
	uint32 keyType,	
	uint8 *tag,
	uint32 tagLen,
	int32 groupID
);

void DestroyPubKeyObject(
	PubKeyContext pubKeyCtx
);

int32 SetPubKeyAttribute(
	PubKeyContext pubKeyCtx,
	uint32 keyAttributeType, 
	void *info,
	uint32 infoLen
);

int32 GetPubKeyAttribute(
	PubKeyContext pubKeyCtx,
	uint32 keyAttributeType, 
	void *info,
	uint32 *infoLen
);

#define GetCommonNameFromPubKey(ret, pubKeyCtx, cname)\
	do{\
		CertificateContext certCtx;\
		ret = GetPubKeyAttribute(pubKeyCtx, PKCKEY_ATTR_CERT, &certCtx, NULL);\
		if( ret == GM_SUCCESS)\
		{\
			ret = GetCertificateAttribute(certCtx, CERT_ATTR_COMMONNAME, cname);\
		}\
	}while(0)

#define GetEmailFromPubKey(ret, pubKeyCtx, email)\
	do{\
		CertificateContext certCtx;\
		ret = GetPubKeyAttribute(pubKeyCtx, PKCKEY_ATTR_CERT, &certCtx, NULL);\
		if( ret == GM_SUCCESS)\
		{\
			ret = GetCertificateAttribute(certCtx, CERT_ATTR_EMAIL, email);\
		}\
	}while(0)

#define GetSubjectNameFromPubKey(ret, pubKeyCtx, sname)\
	do{\
		CertificateContext certCtx;\
		ret = GetPubKeyAttribute(pubKeyCtx, PKCKEY_ATTR_CERT, &certCtx, NULL);\
		if( ret == GM_SUCCESS)\
		{\
			ret = GetCertificateAttribute(certCtx, CERT_ATTR_SUBJECTNAME, sname);\
		}\
	}while(0)

#define GetDomainAndSerialFromPubKey(pubKeyCtx, DNAndSerial) GetPubKeyAttribute(pubKeyCtx, IBCPUBKEY_ATTR_DNANDSERIAL, DNAndSerial, NULL)
#define GetKGAFromPubKey(pubKeyCtx, kga) GetPubKeyAttribute(pubKeyCtx, IBCPUBKEY_ATTR_KGA, kga, NULL)
#define GetIDSchemaFromPubKey(pubKeyCtx, schema) GetPubKeyAttribute(pubKeyCtx, IBCPUBKEY_ATTR_SCHEMA, schema, NULL)
#define GetIDTagFromPubKey(pubKeyCtx, idTag) GetPubKeyAttribute(pubKeyCtx, IBCPUBKEY_ATTR_IDTAG, idTag, NULL)
#define GetBasicIDFromPubKey(pubKeyCtx, basicID) GetPubKeyAttribute(pubKeyCtx, IBCPUBKEY_ATTR_BASICID, basicID, NULL)
#define GetEncodedIDFromPubKey(pubKeyCtx, encID) GetPubKeyAttribute(pubKeyCtx, IBCPUBKEY_ATTR_ENCODEDID, encID, NULL)
#define GetUsageFromPubKey(pubKeyCtx, usage)	GetPubKeyAttribute(pubKeyCtx, PUBKEY_ATTR_USAGE, usage, NULL)
#define GetKeyIndexFromPubKey(pubKeyCtx, index)	GetPubKeyAttribute(pubKeyCtx, IBCPUBKEY_ATTR_KEYINDEX, index, NULL)

/************************Private Key Operation***********************/
#define PRECOMPUTE_PAIRING		0x01
#define PRECOMPUTE_ID			0x02
#define PRECOMPUTE_PRVKEY		0x04
#define PRECOMPUTE_NOKEYDATA	0x08
#define PRECOMPUTE_PUBPOINT		0x10
#define PRECOMPUTE_RECOMPUTE	0x20
#define LOAD_SKIP_CURVE			0x40
#define EARLY_FREE_MEM			0x80
#define CLEAN_RAW_KEY			0x100

#define PRVKEY_THRESHOLD_PROTECT	0x40000000
#define PRVKEY_RANDOM_MASK			0x20000000
#define PRVKEY_INVERT_INPUT_MASK	0x00800000
#define PRVKEY_INLCUDE_INPUT_MASK	0x00200000

#define PRECOMPUTE_ALL			(PRECOMPUTE_PAIRING|PRECOMPUTE_ID|PRECOMPUTE_PRVKEY|PRECOMPUTE_PUBPOINT)
#define PRECOMPUTE_ALL_SAFE		(PRECOMPUTE_ALL|PRECOMPUTE_NOKEYDATA)

int32 CreatePrvKeyObjectFromFileEx(	//encapsulate the interface to read IBC key files and PKI key files
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	int8 *keyFile,		//string ended with 0
	uint8 *id,
	uint32 idLen,
	uint32 preCompute
);

int32 CreatePrvKeyObjectFromMemEx(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	uint8 *keyBuf, 
	uint32 keyLen,
	uint8 *id,
	uint32 idLen,
	uint32 preCompute
);

int32 CreatePrvKeyObjectFromStreamEx(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	GMStream keyStream, 
	uint8 *passwd,
	uint32 passwdLen,
	uint32 preCompute
);

/*
 * Func: Given a device handle and a container name and the key usage,
 *		 locate the private key of the key usage in the container and 
 *		 create a key handle.
 * Ret: GM_SUCCESS or error values
 */
int32 CreatePrvKeyObjectFromDevice(
	LibContext libCtx,
	PrvKeyContext *prvKeyCtx, 
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	uint32 keyUsage,
	uint32 algType
);

int32 CreatePrvKeyObjectFromContainer(
	LibContext libCtx,
	PrvKeyContext *prvKeyCtx, 
	DevCntContext cntCtx,
	uint32 keyUsage
);

int32 CreatePKCPrvKeyObjectFromStore(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	uint8 *containerName,
	uint32 nameLen,
	int8 *provName
);

int32 CreateSM2PrvKeyObjectFromMem(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	uint8 *keyBuf, 
	uint32 keyLen,
	uint8 *passwd,
	uint32 passwdLen,
	int32 preCompute
);

int32 CreateSM2PrvKeyObjectFromStream(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	GMStream keyStream, 
	uint8 *passwd,
	uint32 passwdLen,
	int32 preCompute
);

int32 CreateIBCPrvKeyObjectFromDevBlob(
	PrvKeyContext *prvKeyCtx,
	uint32 devType,
	LibContext libCtx,
	IBCParamContext ibcParamCtx,
	OctString *keyInfo
);

void DestroyPrvKeyObject(
	PrvKeyContext prvKeyCtx
);

int32 ExportPrvKeyObject(
	PrvKeyContext prvKeyCtx,
	uint8 *nkeyData,
	uint32 *nkeyLen,
	uint8 *passwd,
	uint32 passwdLen,
	uint32 nFormat
);

int32 RandomMaskPrvKeyObject(
	PrvKeyContext prvKeyCtx,
	uint8 *mask,
	uint32 mlen,
	uint32 iFlag
);

PrvKeyContext DupPrvKeyObject(
	PrvKeyContext prvKeyCtx
);

int32 SetPrvKeyAttribute(
	PrvKeyContext prvKeyCtx,
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 vLen
);
#define SetPrvKeyIBCAlg(prvKeyCtx, alg)		SetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_ALG, alg, 0)
#define SetPrvKeyCerticate(prvKeyCtx, cert)	SetPrvKeyAttribute(prvKeyCtx, PKCKEY_ATTR_CERT, cert, 0)

int32 SetIBCPrvKeyAttribute(
	IBCPrvKeyContext ibcPrvKeyCtx,
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 vLen
);

int32 GetPrvKeyAttribute(
	PrvKeyContext prvKeyCtx,
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 *vLen
);

#define GetCommonNameFromPrvKey(ret, prvKeyCtx, cname)\
	do{\
		CertificateContext certCtx;\
		ret = GetPrvKeyAttribute(prvKeyCtx, PKCKEY_ATTR_CERT, &certCtx, NULL);\
		if( ret == GM_SUCCESS)\
		{\
			ret = GetCertificateAttribute(certCtx, CERT_ATTR_COMMONNAME, cname);\
		}\
	}while(0)

#define GetSubjectNameFromPrvKey(ret, prvKeyCtx, sname)\
	do{\
		CertificateContext certCtx;\
		ret = GetPrvKeyAttribute(prvKeyCtx, PKCKEY_ATTR_CERT, &certCtx, NULL);\
		if( ret == GM_SUCCESS)\
		{\
			ret = GetCertificateAttribute(certCtx, CERT_ATTR_SUBJECTNAME, sname);\
		}\
	}while(0)

#define GetDomainAndSerialFromPrvKey(prvKeyCtx, DNAndSerial)  GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_DNANDSERIAL, DNAndSerial, NULL)
#define GetKGAFromPrvKey(prvKeyCtx, kga) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_KGA, kga, NULL)
#define GetIDSchemaFromPrvKey(prvKeyCtx, schema) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_SCHEMA, schema, NULL)
#define GetIDTagFromPrvKey(prvKeyCtx, idTag) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_IDTAG, idTag, NULL)
#define GetBasicIDFromPrvKey(prvKeyCtx, basicID) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_BASICID, basicID, NULL)
#define GetEncodedIDFromPrvKey(prvKeyCtx, encID) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_ENCODEDID, encID, NULL)
#define GetValidityFromPrvKey(prvKeyCtx, validity) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_VALIDTIME, validity, NULL)
#define GetActiveStatusFromPrvKey(prvKeyCtx, status) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_STATUS, status, NULL)
#define GetUsageFromPrvKey(prvKeyCtx, usage) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_USAGE, usage, NULL)
#define GetActiviationPolicyFromPrvKey(prvKeyCtx, atvPolicy) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_ACTVPOLICY, atvPolicy, NULL)
#define GetActiviationIDFromPrvKey(prvKeyCtx, atvID) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_ACTIVIATIONID, atvID, NULL)
#define GetIBCSysParamFromPrvKey(prvKeyCtx, sysParam) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_SYSPARAM, sysParam, NULL)
#define GetIBCPrvKeyFromPrvKey(prvKeyCtx, ibcPrvKey) GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_PRVKEY, ibcPrvKey, NULL)
#define GetDeviceHandleFromPrvKey(prvKeyCtx, devCtx) GetPrvKeyAttribute(prvKeyCtx, PRVKEY_ATTR_DEVHANDLE, devCtx, NULL) 
#define GetAlgCategoryFromPrvKey(prvKeyCtx, ktc) GetPrvKeyAttribute(prvKeyCtx, PRVKEY_ATTR_ALG_CATEGORY, ktc, NULL)
#define GetECSIBSKeyFromPrvKey(prvKeyCtx, pKey)	GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_ECS_KEY, pKey, NULL)
#define GetECLPubKeyDataFromPrvKey(prvKeyCtx, pKeyData)	GetPrvKeyAttribute(prvKeyCtx, IBCPRVKEY_ATTR_PUBKEYDATA, pKeyData, NULL)
int32 GetIBCPrvKeyAttribute(
	IBCPrvKeyContext ibcPrvKeyCtx,
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 *vLen
);
#define GetEncodedIDFromIBCPrvKey(ibcPrvKeyCtx, encID)  GetIBCPrvKeyAttribute(ibcPrvKeyCtx, IBCPRVKEY_ATTR_ENCODEDID, encID, NULL)

int32 GetIBCPrvKeyAttributeFromFile(
	int8 *prvKeyFile,		
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 *vLen
);

int32 GetIBCPrvKeyAttributeFromMem(
	uint8 *keyData,
	uint32 keyLen,
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 *vLen
);
#define GetDomainAndSerialFromIBCPrvKeyFile(prvKeyFile, DNAndSerial)  GetIBCPrvKeyAttributeFromFile(prvKeyFile, IBCPRVKEY_ATTR_DNANDSERIAL, DNAndSerial, NULL)
#define GetKGAFromIBCPrvKeyFile(prvKeyFile, kga)  GetIBCPrvKeyAttributeFromFile(prvKeyFile, IBCPRVKEY_ATTR_KGA, kga, NULL)
#define GetBasicIDFromIBCPrvKeyFile(prvKeyFile, basicID) GetIBCPrvKeyAttributeFromFile(prvKeyFile, IBCPRVKEY_ATTR_BASICID, basicID, NULL)
#define GetIDSchemaFromIBCPrvKeyFile(prvKeyFile, schema) GetIBCPrvKeyAttributeFromFile(prvKeyFile, IBCPRVKEY_ATTR_SCHEMA, schema, NULL)
#define GetIDTagFromIBCPrvKeyFile(prvKeyFile, idTag) GetIBCPrvKeyAttributeFromFile(prvKeyFile, IBCPRVKEY_ATTR_IDTAG, idTag, NULL)
#define GetValidityFromIBCPrvKeyFile(prvKeyFile, validity) GetIBCPrvKeyAttributeFromFile(prvKeyFile, IBCPRVKEY_ATTR_VALIDTIME, validity, NULL)
#define GetUsageFromIBCPrvKeyFile(prvKeyFile, usage) GetIBCPrvKeyAttributeFromFile(prvKeyFile, IBCPRVKEY_ATTR_USAGE, usage, NULL)

int32 ActiviateIBCPrvKey(
	PrvKeyContext prvKeyCtx
);

//Now only working for IBC private key files
int32 ChangePrvKeyFilePassword(
	int8 *keyFile,
	uint8 *oldPasswd,
	uint32 oldPasswdLen,
	uint8 *newPasswd,
	uint32 newPasswdLen
);

#define PRVKEY_FORMAT_DEFAULT	0
#define PRVKEY_FORMAT_ENCODE	1
#define PRVKEY_FORMAT_RAW		2
int32 ChangePrvKeyMemPassword(
	int8 *keyData,
	int32 keyLen,
	int8 *nkeyData,
	uint32 *nkeyLen,
	uint8 *oldPasswd,
	uint32 oldPasswdLen,
	uint8 *newPasswd,
	uint32 newPasswdLen,
	uint32 nFormat
);

int32 CreateDevBlobFromPrvKey(
	PrvKeyContext prvKeyCtx, 
	uint32 devType,
	OctString *pubInfo, 
	OctString *prvInfo
);

int32 CreateDevBlobFromPrvKeyEx(
	PrvKeyContext prvKeyCtx, 
	uint32 devType,
	OctString *pubInfo, 
	OctString *prvInfo,
	uint8 *pass,
	int32 passLen
);

/************************Certificate Operation************************/
int32 CreateCertAndPrvKeyFromP12File(
	LibContext libCtx, 
	PrvKeyContext *prvKeyCtx, 
	CertificateContext *certCtx,
	int8 *p12File, 
	uint8 *password,
	uint32 pLen
);

int32 CreateCertObjectFromStore(
	CertificateContext *certCtx,
	uint8 *containerName,
	uint32 nameLen,
	int8 *provName
);

int32 CreateCertObjectFromData(
	CertificateContext *certCtx,
    int8 *certData, 
	uint32 certlen
);

void DestroyCertObject(
	CertificateContext certCtx
);

CertificateContext DupCertObject(
	CertificateContext certCtx
);

int32 ParseCertificateName(
	int8 *subject, 
	uint32 chtype, 
	int32 multirdn, 
	uint32 attrType, 
	void *info
);

int32 GetCertificateAttribute(
	CertificateContext certCtx, 
	uint32 certAttributeType, 
	void *certAttributeValue
);

int32 GetCertificateTypeFromFile(
	const char *fileName
);

int32 ExportCertificate( 
	CertificateContext certCtx, 
	uint8 *buffer, 
	uint32 *bufLen
);

int32 ParseCertificateNameAndSerial( 
	DomainAndSerial * pDNAndSerial, 
	int8 *szDN, 
	uint32 dnLen,
	int8 *szSerial, 
	uint32 serialLen 
);

int32 VerifyCertificate(
	LibContext libCtx,
	CertificateContext certCtx
);

int32 VerifyCertificateEx(
	LibContext hLibCtx, 
	CertificateContext hCert,
	uint32 iFlag
);

/************************IBC Param Operation*********************/

int32 CreateIBCParamObjectFromFile(
	IBCParamContext *ibcParamCtx, 
	int8 *paramFile		//string ended with 0
);

int32 CreateIBCParamObjectFromMem(
	IBCParamContext *ibcParamCtx, 
	uint8 *paramBuf,
	uint32 paramLen
);

int32 CreateIBCParamObjectFromMemEx(
	IBCParamContext *ctx, 
	uint8 *paraBuf,
	uint32 bufLen,
	uint32 preCompute
);

int32 CreateIBCParamObjectFromMemEx2(
	IBCParamContext *ctx, 
	uint8 *paraBuf,
	uint32 bufLen,
	uint32 preCompute,
	IBCParamContext refCtx
);

int32 CreateIBCParamObjectFromStream(
	IBCParamContext *ibcParamCtx, 
	GMStream paramStream
);

int32 CreateIBCParamObjectFromStreamEx2(
	 IBCParamContext *ctx, 
	 GMStream parameterStream,
	 uint32 preCompute,
	 IBCParamContext refCtx
);

int32 CreateIBCParamObjectFromStreamEx(
	IBCParamContext *ibcParamCtx, 
	GMStream parameterStream,
	uint32 preCompute
);

int32 CreateIBCParamObjectFromDevice(
	IBCParamContext *ibcParamCtx, 
	DeviceContext devCtx,
	DomainAndSerial *dns
);

void DestroyIBCParamObject(
	IBCParamContext ibcParamCtx
);

int32 ExportIBCParamObject(
	IBCParamContext paramCtx,
	uint8 *nkeyData,
	uint32 *nkeyLen,
	uint32 nFormat
);

IBCParamContext DupIBCParamObject(
	IBCParamContext ibcParamCtx
);

int32 GetIBCParamAttribute(
	IBCParamContext ibcParamCtx,
	uint32 paramAttributeType, 
	void *paramAttributeValue,
	uint32 *vLen
);
#define GetDomainAndSerialFromIBCParam(ctx, DNAndSerial) GetIBCParamAttribute(ctx, IBCPARAM_ATTR_DNSERIAL, DNAndSerial, NULL)
#define GetKGAFromIBCParam(ctx, kga) GetIBCParamAttribute(ctx, IBCPARAM_ATTR_KGA, kga, NULL)
#define GetIDSchemaFromIBCParam(ctx, schema) GetIBCParamAttribute(ctx, IBCPARAM_ATTR_SCHEMA, schema, NULL)

int32 GetIBCParamAttributeFromFile(
	int8 *paraFile,
	uint32 paramAttributeType,
	void *paramAttributeValue,
	uint32 *vLen
);
#define GetDomainAndSerialFromIBCParamFile(paraFile, DNAndSerial) GetIBCParamAttributeFromFile(paraFile, IBCPARAM_ATTR_DNSERIAL, DNAndSerial, NULL)
#define GetIDSchemaFromIBCParamFile(paraFile, schema) GetIBCParamAttributeFromFile(paraFile, IBCPARAM_ATTR_SCHEMA, schema, NULL)
#define GetKGAFromIBCParamFile(paraFile, kga) GetIBCParamAttributeFromFile(paraFile, IBCPARAM_ATTR_KGA, kga, NULL)


int32 CreateDevBlobFromIBCParam(
	IBCParamContext ibcParamCtx,
	uint32 devType,
	OctString *sysInfo
);

int32 CreateDevBlobFromIBCParamEx(
	IBCParamContext ibcParamCtx,
	uint32 devType,
	OctString *sysInfo,
	uint32 keyGroup,
	uint32 *curveType
);
	
int32 IBCIdToPoint(
	IBCParamContext ibcParamCtx,
	uint8 *id,
	uint32 idLen,
	uint32 keyType,
	uint32 mapGroup,
	uint8 *mPoint,
	int32 *ptLen,
	uint32 ptComp
);

/***************Device Operation*********************/
int32 DupDevice(
	DeviceContext devCtx
);

int32 DeviceLock(
	DeviceContext devCtx
);

int32 DeviceUnlock(
	DeviceContext devCtx
);

int32 DeviceEnum(
	uint32 intfType,
	uint32 devType,
	uint8 *nameList,
	uint32 *nameLen
);

typedef struct{
	int info_type;
#define DEVICE_INIT_PIN	1
	int info_len;
	void *info_data;
}DeviceInitInfo;

int32 DeviceInit(
	DeviceContext *devCtx,
	uint32 intfType,
	int8 *devName, //string ended with 0
	uint32 devType,
	void *initInfo
);

#define OLYM_DEV_ZX32_HID		1
#define OLYM_DEV_ZFCCORE_USB	2
#define OLYM_DEV_ZX32_USB		3
#define OLYM_DEV_ZX32_SD		4
#define OLYM_DEV_ZX32_OBS		5
#define OLYM_DEV_ZX32_HIHID		6
#define OLYM_DEV_ZX32_VENDRV	7
#define OLYM_DEV_ZX32_COMPOSITE	8
#define OLYM_ZX32_UDISK			9
#define OLYM_ZX32_MASHID		10

#define OLYM_ZX32_UDISK_MUL_OLYM	11	//֧��UDISK��HID���豸����ʹ�ò���UDISK��ʱ�򣬽��Զ��л�ΪHID
#define OLYM_ZX32_UDISK_OLYM		12	//֧��UDISK�豸
#define OLYM_ZX32_MASHID_OLYM		13

#define OLYM_DEV_AT90			14
#define OLYM_DEV_Z8HM2_UDISK	15
#define OLYM_CCORE_UDISK		16
#define NISC_DEV_XB				17
#define OLYM_HX_TCARD			18
#define NISC_ZX32_HID			19
#define OLYM_ZX32_PCSC			20
#define OLYM_DEV_ANGUO			21
#define OLYM_CCORE_HID			25

#define OLYM_DEV_SIM_FILE		64
#define OLYM_DEV_SIM_COS		65

#define OLYM_DEV_KB				108
#define OLYM_DEV_RAW			109
#define OLYM_DEV_RAW_COMP		110

/*
 * Func: Given a device type and a device name, 
 *		 open the device to get a device handle
 * Ret: GM_SUCCESS, or error values
 */
int32 DeviceOpen(
	DeviceContext *devCtx,
	uint32 intfType,
	int8 *devName, //string ended with 0
	uint32 devType
);

int32 DeviceOpenSlot(
	DeviceContext *devCtx,
	uint32 intfType,
	uint32 slot,
	uint32 devType
);

/*
 * Func: Close a device. This function may not completely close a device, 
 *		 instead just decrease device reference.
 */
void DeviceClose(
	DeviceContext devCtx
);

int32 DeviceSetAttribute(
	DeviceContext devCtx,
	DEVICE_ATTRIBUTE_TYPE type, 
	uint8 *pbData, 
	uint32 pulDataLen
);

int32 DeviceGetAttribute(
	DeviceContext devCtx,
	DEVICE_ATTRIBUTE_TYPE type, 
	uint8 *pbData, 
	uint32 *pulDataLen
);

int32 DeviceEnumerateContainer(
	DeviceContext devCtx,
	uint32 index,
	DevCntContext *cntCtx
);

/*
 * Func: Given a key identity (for PKI) and domain_name and serial number (for IBC),
 *		 find the container containing the identified key.
 * Ret:	GM_SUCCESS or error values
 */
int32 DeviceSearchContainer(
	DeviceContext devCtx,
	uint8 *basicId,
	uint32 idLen,
	uint8 idType,
	DomainAndSerial *DNAndSerial,
	uint32 algType,
	DevCntContext *cntCtx
);

int32 DeviceSearchContainerName(
	DeviceContext devCtx,
	uint8 *basicId,
	uint32 idLen,
	uint8 idType,
	DomainAndSerial *DNAndSerial,
	uint32 algType,
	OctString *cntName
);

int32 DeviceGetContainerAttribute(
	DevCntContext cntCtx,
	uint32 devAttributeType,
	void *devAttributeValue,
	uint32 *vLen
);
#define GetNameFromContainer(cntCtx, cName)				DeviceGetContainerAttribute(cntCtx, CONTAINER_ATTR_NAME, cName, NULL)
#define GetAlgTypeFromContainer(cntCtx, algType)		DeviceGetContainerAttribute(cntCtx, CONTAINER_ATTR_ALGTYPE, algType, NULL)
#define GetDomainAndSerialFromContainer(cntCtx, dns)	DeviceGetContainerAttribute(cntCtx, CONTAINER_ATTR_DNSERIAL, dns, NULL)
#define GetSubjectFromContainer(cntCtx, subject)		DeviceGetContainerAttribute(cntCtx, CONTAINER_ATTR_SUBJECT, subject, NULL)
#define GetBasicIDFromContainer(cntCtx, basicID)		DeviceGetContainerAttribute(cntCtx, CONTAINER_ATTR_BASICID, basicID, NULL)


/*
 * Func: Given a device handle and a key container name, 
 *		 to create a container handle 
 * Ret: GM_SUCCESS, or other error values
 */
int32 DeviceCreateContainer(
	DeviceContext devCtx,
	DevCntContext *cntCtx,
	uint8 *container,			//string ended with 0
	uint32 cLen,
	uint32 algType
);

/*
 * Func: Release the container handle.
 */
void DeviceDestroyContainer(
	DevCntContext cntCtx
);

/*
 * Func: Given a container handle, a key usage and a key type, get a key handle
 * Input:
 *		 keyUsage: GM_KEY_USAGE_KEXECHANGE, GM_KEY_USAGE_SIGNATURE
 *		 keyType: GM_KEY_TYPE_PRIVATE, GM_KEY_TYPE_PUBLIC
 * Ret: GM_SUCCESS, or error values
 */
int32 DeviceGetKey(
	DevCntContext devCntCtx,
	uint32 keyUsage,
	uint32 keyType,
	DevKeyContext *devKeyCtx
);

/*
 * Func: Release key handle
 */
void DeviceReleaseKey(
	DevKeyContext devKeyCtx
);


int32 DeviceCryptExportKey(
	DevKeyContext devKeyCtx, 
	DevKeyContext devWrapKeyCtx, 
	uint8 *pbData, 
	uint32 *dataLen,
	uint32 algType,		//the algorithm such RSA-OAEP, ALG_IBE_SOK_EY_KEM1_AES128_SHA1
	void *extraKey,		//peer party's key
	uint32 extraKeyLen,
	void *xparam
);

int32 DeviceCryptImportKey(
	DevKeyContext *devKeyCtx, 
	DevKeyContext devPrvKeyCtx, 
	uint32 ulAlgID,
	uint8* pbData, 
	uint32 dataLen,
	void *peerKey,
	uint32 peerKeyLen,
	void *extraKey,
	uint32 exKeyLen,
	void *xparam
);

int32 DeviceCryptSignData(
	DevKeyContext devPrvKeyCtx,
	uint32 algID,
	uint32 digestType,
	uint8 *pbDigest,
	uint32 digestLen,
	uint8 *pbData, 
	uint32 *dataLen,
	uint32 flags
);

/*
 * Func: Given a private key handle and a hash handle, sign the hash value to 
 *		 generate the signature.
 * Ret: GM_SUCCESS or error values
 */
int32 DeviceCryptSignHash(
	DevKeyContext devPrvKeyCtx, 
	uint32 algID,
	HashContext hashCtx, 
	uint8 *pbData, 
	uint32 *dataLen
);

/*
 * Func: Given a public key handle, a hash handle and the signature, verify whether
 *		 the signature is authenticatic. The result is passed from verifyResult
 * Ret: GM_SUCCESS or error values
 */
int32 DeviceCryptVerifySignHash(
	DevKeyContext devPubKeyCtx,
	uint32 algID,
	HashContext hashCtx, 
	uint8 *pbData, 
	uint32 dataLen, 
	int32 *verifyResult
);

int32 DeviceGenSymmetricKey (
	DeviceContext devCtx,
	uint32 ulAlgID, 
	uint32 ulGenKeyFlags, 
	DevKeyContext *devSecKeyCtx
);

int32 DeviceEncryptInit(
	DevKeyContext devSecKeyCtx,
	DEVBLOCKCIPHERPARAM *pEncryptParam
);

int32 DeviceEncryptUpdate(
	DevKeyContext devSecKeyCtx,
	uint8 *outBuf,
	uint32 *outLen,
	uint8 *inBuf,
	uint32 inLen
);

int32 DeviceEncryptFinal(
	DevKeyContext devSecKeyCtx,
	uint8 *outBuf,
	uint32 *outLen
);

int32 DeviceDecryptInit(
	DevKeyContext devSecKeyCtx,
	DEVBLOCKCIPHERPARAM *pDecryptParam
);

int32 DeviceDecryptUpdate(
	DevKeyContext devSecKeyCtx,
	uint8 *outBuf,
	uint32 *outLen,
	uint8 *inBuf,
	uint32 inLen
);

int32 DeviceDecryptFinal(
	DevKeyContext devSecKeyCtx,
	uint8 *outBuf,
	uint32 *outLen
);

/*
 * Func: Given a key handle and a key attribute, retrieve the value corresponding to
 *		 the attribute
 * Ret: GM_SUCCESS or error values
 */
int32 DeviceGetKeyParam(
	DevKeyContext devKeyCtx,
	uint32  keyParamType, 
	void *keyParamVale, 
	uint32 *vLen
);

/*
 * Func: Set the attribute of a key referred to by a key handle
 * Ret: GM_SUCCESS or error values
 */
int32 DeviceSetKeyParam(
	DevKeyContext devKeyCtx,
	uint32  keyParamType, 
	void *keyParamVale, 
	uint32 vLen
);


#define KEYSET_PKI_KEYEXCHANGE_CERT				1
#define KEYSET_PKI_SIGNATURE_CERT				2
#define KEYSET_PKI_KEYEXCHANGE_PRVKEY			3
#define KEYSET_PKI_SIGNATURE_PRVKEY				4
#define KEYSET_PKI_KEYEXCHANGE_PUBKEY			5
#define KEYSET_PKI_SIGNATURE_PUBKEY				6

#define KEYSET_IBC_SYSDATA						9
#define KEYSET_IBC_SYSFILE						10
#define KEYSET_IBC_KEYEXCHANGE_PRVKEY			11
#define KEYSET_IBC_KEYEXCHANGE_PUBKEY_INFO		12	
#define KEYSET_IBC_SIGNATURE_PRVKEY				13
#define KEYSET_IBC_SIGNATURE_PUBKEY_INFO		14	

int32 DeviceNewKeySet(
	DeviceContext devCtx,
	DevCntContext *cntCtx,
	uint8 *container,
	uint32 cLen,
	uint32 kType
);

int32 DeviceDelKeySet(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	uint32 kType
);

int32 DeviceImportKeySetData(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	uint8 *data,
	uint32 dLen,
	uint32 dataType
);


int32 DeviceExportKeySetData(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	uint8 *data,
	uint32 *dLen,
	uint32 dataType
);

int32 DeviceCreatePKCKeySetFromP12File(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	int8 *p12File,
	uint8 *passwd,
	uint32 pLen,
	uint32 keyUsage
);

int32 DeviceCreateIBCKeySetFromFile(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	int8 *sysFile,
	int8 *pvkFile,
	int8 *passwd,
	uint32 pLen
);

int32 DeviceCreateKeySetFromPrvKey(
	DeviceContext devCtx,
	uint8 *container,
	uint32 cLen,
	PrvKeyContext prvKey,
	uint32 keyUsage
);

int32 DeviceGenerateKeyPair(
	DeviceContext devCtx,
	DevCntContext cntCtx,
	uint32  ulAlg,
	uint32  ulKeyUsage, 
	uint32  ulBitLen
);

#define DEVFILE_ACCESS(T, U, W, R)	(((((int)T)&0xFF)<<24) | ((((int)U)&0xFF)<<16) | ((((int)W)&0xFF)<<8) | (((int)R)&0xFF))
int32 DeviceCreateFile(
	DeviceContext devCtx,
	DevAppContext hApplication,
	uint8 *szFileName,
	uint32 ulFileSize,
	uint32 ulAccessCondition
);

int32 DeviceDeleteFile(
	DeviceContext devCtx,
	DevAppContext hApplication,
	uint8 *szFileName
);

int32 DeviceWriteFile(
	DeviceContext devCtx,
	DevAppContext hApplication,
	uint8 *szFileName,
	int32 ulOffset,
	uint8 *pbData,
	uint32 ulSize,
	uint32 *pulLen
);

int32 DeviceReadFile(
	DeviceContext devCtx,
	DevAppContext hApplication,
	uint8 *szFileName,
	int32 ulOffset,
	uint32 ulSize,
	uint8 *pbOutData,
	uint32 *pulOutLen				   
);

#define DEV_USER_PIN			1
#define DEV_ADMIN_PIN			2

int32 DeviceSetPin(
	DeviceContext devCtx,
	uint32 pinType,
	uint8 *oldPin,
	uint32 oldPinLen,
	uint8 *newPin,
	uint32 newPinLen,
	uint32 *retryNum
);

int32 DeviceVerifyPin(
	DeviceContext devCtx,
	uint32 pinType,
	uint8 *pin,
	uint32 pinLen,
	uint32 *retryNum
);

int32 DeviceGenRandom(
	DeviceContext devCtx,
	uint8 *rand,
	uint32 rLen
);

int32 DeviceCreateKeyBlob(
	uint32 devType,
	int8 *sysData,
	int32 sysLen,
	int8 *pvkData,
	int32 pvkLen,
	int8 *passwd,
	uint32 pLen,
	uint8 *sysBlob,
	uint32 *sysBlobLen,
	uint8 *pvkBlob,
	uint32 *pvkBlobLen
);

int32 DeviceCreateKeyBlobEx(
	uint32 devType,
	int8 *sysData,
	int32 sysLen,
	int8 *pvkData,
	int32 pvkLen,
	int32 rawPoint,
	int8 *id,
	int32 idLen,
	uint32 keyUsage,
	int8 *passwd,
	uint32 pLen,
	uint8 *sysBlob,
	uint32 *sysBlobLen,
	uint8 *pvkBlob,
	uint32 *pvkBlobLen
);

int32 DeviceDigestInit(
	DeviceContext devCtx,
	uint32 nAlg,
	DevDigestContext *hDigCtx
);

int32 DeviceDigestUpdate(
	DeviceContext devCtx,
	DevDigestContext hDigCtx,
	uint8 *pData,
	uint32 nDataLen
);

int32 DeviceDigestFinal(
	DeviceContext devCtx,
	DevDigestContext hDigCtx,
	uint8 *pData,
	uint32 *nDataLen
);

/***************Secret Key Crypt Operation*************/

int32 GMCryptGenSecKey(		//just for session key
	SecKeyContext *secKeyCtx, 
	uint32 algId, 
	uint32 flags
);

void GMCryptDestroySecKey(
	SecKeyContext secKeyCtx
);

SecKeyContext DupSecKeyObject(
	SecKeyContext secKeyCtx
);

int32 SetSecKeyAttribute(
	SecKeyContext secKeyCtx, 
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 vLen
);
#define SetCipherSecKey(secKeyCtx, key, keyLen)		SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_SECRET, key, keyLen)
#define SetCipherIV(secKeyCtx, iv, ivLen)			SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_IV, iv, ivLen)
#define SetCipherPassword(secKeyCtx, pass, passLen)	SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_PASSWD, pass, passLen)
#define SetCipherSalt(secKeyCtx, salt, saltLen)		SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_SALT, salt, saltLen)
#define SetCipherKDFIteration(secKeyCtx, iter)		SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_ITER, iter, 0)
#define SetCipherKeyLen(secKeyCtx, keyLen)			SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_KEYLEN, keyLen, 0)
#define SetCipherAlgId(secKeyCtx, algId)			SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_ALGID, algId, 0)
#define	SetCipherDevice(secKeyCtx, devCtx)			SetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_DEVICE, devCtx, 0);

int32 GetSecKeyAttribute(
	SecKeyContext secKeyCtx, 
	uint32 keyAttributeType, 
	void *keyAttributeValue,
	uint32 *vLen
);
#define GetCipherBlockLen(secKeyCtx, blockLen)		GetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_BLKLEN, blockLen, NULL)
#define GetCipherSecKey(secKeyCtx, key, keyLen)		GetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_SECRET, key, keyLen)
#define GetCipherIV(secKeyCtx, iv, ivLen)			GetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_IV, iv, ivLen)
#define GetCipherAlgId(secKeyCtx, algId)			GetSecKeyAttribute(secKeyCtx, SECKEY_ATTR_ALGID, algId, NULL)

int32 GMCryptEncInit(
	SecKeyContext secKeyCtx
);

int32 GMCryptEncUpdate(
	SecKeyContext secKeyCtx,
	uint8 *outBuf,
	uint32 *outLen,
	uint8 *inBuf,
	uint32 inLen
);

int32 GMCryptEncFinal(
	SecKeyContext secKeyCtx,
	uint8 *outBuf,
	uint32 *outLen
);

int32 GMCryptDecInit(
	SecKeyContext secKeyCtx
);

int32 GMCryptDecUpdate(
	SecKeyContext secKeyCtx,
	uint8 *outBuf,
	uint32 *outLen,
	uint8 *inBuf,
	uint32 inLen
);

int32 GMCryptDecFinal(
	SecKeyContext secKeyCtx,
	uint8 *outBuf,
	uint32 *outLen
);

int32 GMCryptEncrypt(
	uint32 algType,
	uint8 *key,
	uint32 keyLen,
	uint8 *iv,
	uint32 ivLen,
	uint8 *outBuf,
	uint32 *outLen,
	uint8 *inBuf,
	uint32 inLen,
	uint32 flags
);

int32 GMCryptDecrypt(
	uint32 algType,
	uint8 *key,
	uint32 keyLen,
	uint8 *iv,
	uint32 ivLen,
	uint8 *outBuf,
	uint32 *outLen,
	uint8 *inBuf,
	uint32 inLen,
	uint32 flags
);

/******************FPE Operation**********************/
#define FPE_FIXED_TWEAK			0x01
#define FPE_FIXED_INLEN			0x02

int32 GMCryptGenFpeKey(		//now just for session key
	FpeKeyContext *phKey, 
	uint32 algType, 
	uint32 flags
);

void GMCryptDestroyFpeKey(
	FpeKeyContext hKey
);

#define FPEKEY_ATTR_SECRET			1
#define FPEKEY_ATTR_TWEAK			2
#define FPEKEY_ATTR_INPUT_TYPE		3
#define FPEKEY_ATTR_INPUT_LENGTH	4

#define FPE_INPUT_NUMBER		1
#define FPE_INPUT_STRING		2
#define FPE_INPUT_IPV4			3
#define FPE_INPUT_IPV6			4
#define FPE_INPUT_TIMESTAMP		5
#define FPE_INPUT_STR_BASE10	6
#define FPE_INPUT_STR_BASE52	7
#define FPE_INPUT_STR_BASE62	8
#define FPE_INPUT_STR_BASE95	9
#define FPE_INPUT_ENCODED		10
#define FPE_INPUT_STR_GBK		11
#define FPE_INPUT_STR_UNICODE	12
#define FPE_INPUT_STR_UTF8		13

int32 SetFpeKeyAttribute(
	FpeKeyContext hKey,
	uint32 keyAttributeType, 
	void *info, 
	uint32 infoLen
);

int32 GMCryptFpeInit(
	FpeKeyContext hKey
);

int32 GMCryptFpeDoEncrypt(
	FpeKeyContext hKey, 
	uint8 *auxInfo, 
	uint32 auxLen,  
	uint8 *outBuf, 
	uint32 *outLen, 
	uint8 *inBuf, 
	uint32 inLen
);

int32 GMCryptFpeDoDecrypt(
	FpeKeyContext hKey, 
	uint8 *auxInfo, 
	uint32 auxLen,  
	uint8 *outBuf, 
	uint32 *outLen, 
	uint8 *inBuf, 
	uint32 inLen
);


int32 GMCryptFpeEncrypt(
	uint8 *key,
	uint32 keyLen,
	uint8 *auxInfo, 
	uint32 auxLen,  
	uint8 *outBuf, 
	uint32 *outLen, 
	uint8 *inBuf, 
	uint32 inLen,
	uint32 inputType,
	uint32 algType
);

int32 GMCryptFpeDecrypt(
	uint8 *key,
	uint32 keyLen,
	uint8 *auxInfo, 
	uint32 auxLen,  
	uint8 *outBuf, 
	uint32 *outLen, 
	uint8 *inBuf, 
	uint32 inLen,
	uint32 inputType,
	uint32 algType
);

int32 GMCryptFpeOperationEx(
	uint8 *key,
	uint32 keyLen,
	uint8 *auxInfo, 
	uint32 auxLen,  
	uint8 *outBuf, 
	uint32 *outLen, 
	uint8 *inBuf, 
	uint32 inLen,
	uint32 inputType,
	uint32 radix,
	uint32 algType,
	uint32 mode
);

/******************Hash Operation ********************/
int32 GMCryptGenHash(		//HMAC is supported
	HashContext *hashCtx, 
	uint32 algId, 
	uint32 flags
);

void GMCryptDestroyHash(
	HashContext hashCtx
);

#define	SetHashDevice(secKeyCtx, devCtx)			SetHashAttribute(secKeyCtx, HASH_ATTR_DEVICE, devCtx, 0);
int32 SetHashAttribute(
	HashContext hHash, 
	uint32 hashAttributeType, 
	void *info, 
	uint32 len
);

int32 GetHashAttribute(
	HashContext hHash, 
	uint32 hashAttributeType, 
	void *info,
	uint32 *len
);

int32 GMCryptHashInit(
	HashContext hashCtx
);

int32 GMCryptHashSM2PrvPrepare(
	HashContext hHash,
	PrvKeyContext hPrvKey
);

int32 GMCryptHashSM2PubPrepare(
	HashContext hHash,
	PubKeyContext hPubKey
);

int32 GMCryptHashUpdate(
	HashContext hashCtx,
	uint8 *data,
	uint32 dataLen
);

int32 GMCryptHashFinal(
	HashContext hashCtx,
	uint8 *md,
	uint32 *mdLen
);

int32 GMCryptHash(
	uint32 algType,
	uint8 *data,
	uint32 dLen,
	uint8 *md,
	uint32 *mdLen
);

int32 GMCryptHashArray(
	uint32 algType,
	uint8 **data,
	uint32 *dLen,
	uint32 num,
	uint8 *md,
	uint32 *mdLen
);

/******************Secret Key Mac Operation***************/

int32 GMCryptGenMAC(
	MACContext *macCtx, 
	uint32 algId, 
	uint32 flags
);

#define	MAC_NO_EXTRA_PROTECTION			1
#define MAC_WITHOUT_PADDING				4

void GMCryptDestroyMAC(
	MACContext macCtx
);

int32 SetMACAttribute(
	MACContext macCtx, 
	uint32 macAttributeType, 
	void *macAttributeValue, 
	uint32 vLen
);
#define SetMACSecKey(macCtx, key, keyLen)		SetMACAttribute(macCtx, MAC_ATTR_SECRET, key, keyLen)

int32 GetMACAttribute(
	MACContext macCtx, 
	uint32 macAttributeType, 
	void *macAttributeValue,
	uint32 *vLen
);

int32 GMCryptMACInit(
	MACContext macCtx
);

int32 GMCryptMACUpdate(
	MACContext macCtx,
	uint8 *data,
	uint32 dataLen
);

int32 GMCryptMACFinal(
	MACContext macCtx,
	uint8 *mac,
	uint32 *macLen
);

int32 GMCryptMAC(
	uint32 algType,
	uint8 *key,
	uint32 keyLen,
	uint8 *data,
	uint32 dataLen,
	uint8 *mac,
	uint32 *macLen
);

int32 GMCryptMACEx(
	uint32 algType,
	uint8 *key,
	uint32 keyLen,
	uint8 *data,
	uint32 dataLen,
	uint8 *mac,
	uint32 *macLen,
	uint32 flags
);

int32 GMCryptMACEx2(
	uint32 algType,
	uint8 *key,
	uint32 keyLen,
	uint8 *iv,
	uint32 ivLen,
	uint8 *data,
	uint32 dataLen,
	uint8 *mac,
	uint32 *macLen,
	uint32 padding,
	uint32 flags
);

int32 GMCryptMACArray(
	uint32 algType,
	uint8 *key,
	uint32 keyLen,
	uint8 *iv,
	uint32 ivLen,
	uint8 **dv,
	uint32 *dl,
	uint32 dn,
	uint8 *mac,
	uint32 *macLen,
	uint32 padding,
	uint32 flags
);

/********************Password Based Cipher Operation ************/
int32 GMCryptPBEncrypt(
	uint8 *passwd,
	uint32 passwdLen,
	uint8 *salt, 
	uint32 saltLen, 
	uint32 iter,
	uint32 algType,
	uint8 *iv,
	uint32 ivLen,
	uint8 *outData,
	uint32 *outLen,
	uint8 *inData,
	uint32 inLen
);

int32 GMCryptPBDecrypt(
	uint8 *pass,
	uint32 passLen,
	uint8 *salt, 
	uint32 saltLen, 
	uint32 iter,
	uint32 algType,
	uint8 *iv,
	uint32 ivLen,
	uint8 *outData,
	uint32 *outLen,
	uint8 *inData,
	uint32 inLen
);

int32 GMCryptPBMAC(
	uint8 *passwd,
	uint32 passwdLen,
	uint8 *salt, 
	uint32 saltLen, 
	uint32 iter,
	uint32 algType,
	uint8 *data,
	uint32 dataLen,
	uint8 *mac,
	uint32 *macLen
);

/********************KDF Operations *************/
int32 GMKDF(
	uint8 *kdf,
	uint32 kdfLen,
	uint8 *msg,
	uint32 mLen,
	uint32 nAlg
);

int32 GMKDFEx(
	uint8 *kdf,
	uint32 kdfLen,
	uint8 **msg,
	uint32 *mLen,
	uint32 mnum,
	uint32 nAlg,
	uint32 nCounter
);

#define GMKDF1(kdf, kdfLen, msg, mLen, halg)	GMKDF(kdf, kdfLen, msg, mLen, ((halg)|ALG_KDF1))

int32 GMPBKDF2(
	uint8 *pass,
	int32 passLen,
	uint8 *salt, 
	int32 saltLen, 
	int32 iter,
	uint32 prfType, //only support hmac
	uint8 *dkData,
	uint32 dkLen
);

/********************DEM Operation****************/
int32 GMDEMEncrypt(
	uint8 *cipherText, 
	int32 *clen, 
	uint8 *data, 
	int32 dLen, 
	uint8 *secret, 
	int32 secLen, 
	uint32 alg
);

int32 GMDEMEncryptEx(
	uint8 *emsg, 
	int32 *emsglen, 
	uint8 *data, 
	int32 dLen, 
	uint8 *secret, 
	int32 secLen, 
	uint32 alg,
	uint32 emLen
);

int32 GMDEMDecrypt(
	uint8 *xdata, 
	int32 *xLen, 
	uint8 *cipherText, 
	int32 cLen, 
	uint8 *secret, 
	int32 secLen, 
	uint32 alg
);

int32 GMDEMDecryptEx(
	uint8 *xdata, 
	int32 *xLen, 
	uint8 *msg, 
	int32 tLen, 
	int32 macLen,
	uint8 *secret, 
	int32 secLen, 
	uint32 alg
);

int32 GMCryptGenDEM(
	DEMContext *phDEMCtx, 
	uint32 algType, 
	uint32 flags	
);

void GMCryptDestroyDEM(
	DEMContext hDEMCtx
);

int32 SetDEMAttribute(
	DEMContext hDEMCtx,
	uint32 demAttributeType,
	void *info,
	uint32 infoLen
);

int32 GMCryptDEMEncInit(
	DEMContext hDEMCtx
);

int32 GMCryptDEMEncUpdate(
	DEMContext hDEMCtx, 
	uint8 *cipher, 
	uint32 *clen, 
	uint8 *plain, 
	uint32 plen
);

int32 GMCryptDEMEncFinal(
	DEMContext hDEMCtx, 
	uint8 *cipher, 
	uint32 *clen, 
	uint8 *label, 
	uint32 llen
);

int32 GMCryptDEMEncrypt(
	DEMContext hDEMCtx, 
	uint8 *cipher, 
	uint32 *clen, 
	uint8 *plain, 
	uint32 plen, 
	uint8 *label, 
	uint32 llen, 
	uint8 *iv, 
	int32 ivlen 
);

int32 GMCryptDEMDecInit(
	DEMContext hDEMCtx
);

int32 GMCryptDEMDecUpdate(
	DEMContext hDEMCtx, 
	uint8 *plain, 
	uint32 *plen,
	uint8 *cipher,
	uint32 clen 
);

int32 GMCryptDEMDecFinal(
	DEMContext hDEMCtx, 
	uint8 *plain, 
	uint32 *plen, 
	uint8 *label, 
	uint32 llen
);

int32 GMCryptDEMDecrypt(
	DEMContext hDEMCtx, 
	uint8 *plain, 
	uint32 *plen, 
	uint8 *cipher, 
	uint32 clen, 
	uint8 *label, 
	uint32 llen
);

int32 CMCryptDEMEncryptEncap(
	uint8 *cipher, 
	uint32 *clen, 
	uint8 *plain, 
	uint32 plen, 
	uint8 *label, 
	uint32 llen, 
	uint8 *ekey, 
	int32 eklen, 
	uint8 *mkey, 
	int32 mklen, 
	uint8 *iv, 
	int32 ivlen, 
	uint32 alg,
	DeviceContext hDev
);

int32 CMCryptDEMDecryptEncap(
	uint8 *plain, 
	uint32 *plen, 
	uint8 *cipher, 
	uint32 clen, 
	uint8 *label, 
	uint32 llen, 
	uint8 *ekey, 
	int32 eklen, 
	uint8 *mkey, 
	int32 mklen, 
	uint32 alg,
	DeviceContext hDev
);

int32 GMDEMEncAux(
	uint32 cAlg,
	uint32 mAlg,
	uint8 *cipher,
	uint32 *cipherLen,
	uint8 *key,
	uint32 keyLen,
	uint8 *plain,
	uint32 plainLen,
	uint8 *aux,
	uint32 auxLen
);

int32 GMDEMDecAux(
	uint32 cAlg,
	uint32 mAlg,
	uint8 *plain,
	uint32 *plainLen,
	uint8 *key,
	uint32 keyLen,
	uint8 *cipher,
	uint32 cipherLen,
	uint8 *aux,
	uint32 auxLen
);

/*************************************************/
int32 DAESivEncrypt(
	uint8 *cipher, 
	uint32 *clen, 
	uint8 *plain, 
	uint32 plen, 
	const uint8 *aux, 
	uint32 auxlen, 
	uint8 *key, 
	uint32 klen,	//32bytes for enc and mac key
	uint32 alg
);

int32 DAESivDecrypt(
	uint8 *plain, 
	uint32 *plen, 
	uint8 *cipher, 
	uint32 clen,
	const uint8 *aux, 
	uint32 auxlen,
	uint8 *key, 
	uint32 klen,	//32bytes for enc and mac key
	uint32 alg
);

/************Asymmetric Cipher Operation*********/
int32 GMCryptExportData(
	PubKeyContext pubKeyCtx, 
	uint8 *pbInData,
	uint32 inDataLen,
	uint8 *pbOutData, 
	uint32 *outDataLen,
	PrvKeyContext prvKeyCtx,
	void *xparam
);

int32 GMCryptExportKey(			//encrypt session keys
	SecKeyContext hKey, 
	PubKeyContext pubKeyCtx, 
	uint8 *pbData, 
	uint32 *dataLen,
	PrvKeyContext prvKeyCtx,
	void *xparam
);

int32 GMCryptImportData(
	PrvKeyContext prvKeyCtx, 
	uint8* pbCipherData, 
	uint32 cipherLen,
	uint8* pbPlainData,
	uint32 *plainLen,
	PubKeyContext pubKeyCtx,
	PrvKeyContext hPrvKeyExt,
	void *xparam
);

int32 GMCryptImportKey(			//decryt session keys
	SecKeyContext *hKey, 
	PrvKeyContext prvKeyCtx, 
	uint8* pbData, 
	uint32 dataLen,
	PubKeyContext pubKeyCtx,
	PrvKeyContext hPrvKeyExt,
	void *xparam
);

int32 GMCryptSignData(
	PrvKeyContext prvKeyCtx, 
	uint32 digestType,
	uint8 *pbDigest,
	uint32 digestLen,
	uint8 *pbData, 
	uint32 *dataLen
);

int32 GMCryptSignHash(			//only sign hash value, compatible with RSA, DSA, ECDSA, tweaked IBS' such as Hess, CC, BLMQ
	PrvKeyContext prvKeyCtx, 
	HashContext hashCtx, 
	uint8 *pbData, 
	uint32 *dataLen
);

int32 GMCryptVerifySignData(
	PubKeyContext pubKeyCtx, 
	uint32 digestType,
	uint8 *pbDigest,
	uint32 digestLen,
	uint8 *pbData, 
	uint32 dataLen, 
	int32 *verifyResult
);

#define THRESHOLD_SIGNATURE_UPDATE		0x01
#define THRESHOLD_SIGNATURE_NOVERIFY	0x02

int32 GMCryptVerifySignDataEx(
	PubKeyContext pubKeyCtx, 
	uint32 digestType,
	uint8 *pbDigest,
	uint32 digestLen,
	uint8 *pbData, 
	uint32 dataLen, 
	uint32 iFlag,
	int32 *verifyResult
);

int32 GMCryptVerifySignHash(	//only verify with appendix of hash value, compatible with RSA, DSA, ECDSA, tweaked IBS' such as Hess, CC, BLMQ
	PubKeyContext pubKeyCtx, 
	HashContext hashCtx, 
	uint8 *pbData, 
	uint32 dataLen, 
	int32 *verifyResult
);

/**********************SSS Operation*************/

#ifndef __SSSS_ST__
#define __SSSS_ST__

#define MAXDEGREE			1024 //The maximum bit length of the secret to be shared
#define MAXOCTSECRETLEN		(MAXDEGREE/8)
#define MAXHEXSECRETLEN		(MAXDEGREE/4)

//A 1024-bit secret is shared and converted several 1024-bit random numbers
typedef struct{
	int index;
	char sshare[MAXDEGREE/4+4];	//large enough to hold the representation of the shared secret with the hex format
}sss_share;

#endif
int32 GMSSS_Split(
	int8* secret, 
	int32 slen, 
	int32 hex, 
	sss_share *share, 
	int32 num, 
	int32 threshold
);

int32 GMSSS_Restore(
	int8 *secret, 
	int32 *slen, 
	int32 hex, 
	sss_share *share, 
	int32 snum					 
);

/*******************PKCS7 Object Operation*****************/

int32 CreateP7Object(
	LibContext libCtx, 
	P7Object *p7Obj
);

void DestroyP7Object(
	P7Object p7Obj
);

int32 SetP7Attribute(
	P7Object p7Obj, 
	uint32 p7AttributeType, 
	void *p7AttributeValue, 
	uint32 vLen
);

int32 SetP7AttributeInteger(
	P7Object p7Obj, 
	uint32 p7AttributeType, 
	uint32 p7AttributeValue
);
 
int32 GetP7Attribute(
	P7Object p7Obj, 
	uint32 p7AttributeType, 
	void *p7AttributeValue,
	uint32 *vLen
);

int32 P7WriterInit(
	P7Object p7Obj
);

int32 P7WriteUpdate(
	P7Object p7Obj, 
	uint8 *inputData, 
	uint32 inputLen, 
	uint8 *message, 
	uint32 bufLen, 
	uint32 *messageLen
);

int32 P7WriteUpdateEx(
	P7Object p7Obj, 
	uint8 *inputData, 
	uint32 inputLen, 
	uint32 *writeLen,
	uint8 *message, 
	uint32 bufLen, 
	uint32 *messageLen
);

int32 P7WriteFinal(
	P7Object p7Obj, 
	uint8 *message, 
	uint32 bufLen, 
	uint32 *messageLen
);

int32 P7ReaderInit(
	P7Object p7Obj
);

int32 P7ReaderUpdate(
	P7Object p7Obj, 
	uint8 *message, 
	uint32 messageLen, 
	uint32 *messageRead, 
	uint8 *outputData, 
	uint32 bufLen, 
	uint32 *outputDataLen
);

int32 P7ReaderFinal(
	P7Object p7Obj, 
	uint8 *outputData, 
	uint32 bufLen, 
	uint32 *outputDataLen
);

int32 P7VerifySign(
	P7Object p7Obj
);

#define P7_CALLBACK_CMD_END			0
#define P7_CALLBACK_CMD_PROGRESS	1
#define P7_CALLBACK_CMD_CANCEL		2

typedef struct{
	int32 currentLen;
	int32 totalLen;
}GM_P7Status;

typedef int32 (*P7CallBack)(int32* cmd, void *to_caller, void **from_caller);

int32 P7Write(
	LibContext libCtx,
	GMStream inStream, 
	GMStream outStream,
	uint32 nDataType,
	uint32 nFormat,
	uint32 nAlg,
	IdentityList recpList,
	IdentityList signerList,
	Identity sender,
	P7CallBack callback
);

int32 P7WriteEx(
	LibContext libCtx,
	GMStream inStream, 
	GMStream outStream,
	uint32 nDataType,
	uint32 nFormat,
	uint32 nAlg,
	IdentityList recpList,
	IdentityList signerList,
	Identity sender,
	SecKeyContext hKeyCtx,
	P7CallBack callback
);

int32 P7WriteEx2(
	 LibContext libCtx,
	 GMStream inStream, 
	 GMStream outStream,
	 uint32 nDataType,
	 uint32 nFormat,
	 uint32 nAlg,
	 IdentityList recpList,
	 IdentityList signerList,
	 Identity sender,
	 SecKeyContext hKeyCtx,
	 P7CallBack callback,
	 uint32 nP7flags
);

int32 P7Read(
	LibContext libCtx,
	GMStream inStream, 
	GMStream outStream, 
	IdentityList *recpList,
	IdentityList *signerList,
	uint32 *nContentType,
	P7CallBack callback
);

int32 P7ReadEx(
	LibContext libCtx,
	GMStream inStream, 
	GMStream outStream, 
	IdentityList *recpList,
	IdentityList *signerList,
	uint32 *nContentType,
	SecKeyContext hKeyCtx,
	P7CallBack callback
);

int32 P7ReadEx2(
	LibContext libCtx,
	GMStream inStream, 
	GMStream outStream, 
	IdentityList *recpList,
	IdentityList *signerList,
	uint32 *nContentType,
	SecKeyContext secKeyCtx,
	P7CallBack callback,
	GMStream inAuxStream
);

int32 P7ReadEx3(
	LibContext libCtx,
	GMStream inStream, 
	GMStream outStream, 
	IdentityList *recpList,
	IdentityList *signerList,
	uint32 *nContentType,
	SecKeyContext hKeyCtx,
	P7CallBack callback,
	GMStream inAuxStream,
	uint8 *decipherId,
	int32 decipherIdLen
);

int32 P7CheckFile( int8 *fileName );

/***********************POLIBY BASED ENCRYPTION*************/
int32 GMQueryPolicyKey(
	PrvKeyContext prvKeyCtx, 
	uint16 policyNum,
	OctString *policy,
	uint16 *keyResult,
	OctString *keyData,
	uint16 flags
);

int32 GMGeneratePolicyKey(
	PrvKeyContext prvKeyCtx, 
	uint16 policyNum,
	OctString *policy,
	uint16 *keyResult,
	uint16 flags,
	PrvKeyContext *hPolicyKey
);

int32 GMComposePolicyKey(
	PrvKeyContext prvKeyCtx, 
	OctString *policy,
	OctString *keyData,
	uint16 flags,
	PrvKeyContext *hPolicyKey
);

int32 GMComposePolicy(
	OctString *composedPolicy,
	uint32 policyType,
	void *policyValue,
	uint32 valueLen
);

int32 GMParsePolicy(
	OctString *composedPolicy,
	uint32 *policyType,
	void *policyValue,
	uint32 *valueLen
);


/****************************/
int32 IBCInitPrivateKeyEx(
	IBCParamContext ibcParamCtx,
	OctString *basicID,
	uint8 idType,
	OctString *idTag,
	GMTime *decTime,
	uint32 keyUsage,
	Validity *validity,
	IBCPrvKeyContext *ibcPrvKeyCtx,
	uint32 atvPolicy,
	OctString *atvID,
	OctString *policy
);

int32 IBCInitPrivateKey(
	IBCParamContext ibcParamCtx,
	OctString *basicID,
	uint8 idType,
	OctString *idTag,
	GMTime *decTime,
	uint32 keyUsage,
	Validity *validity,
	IBCPrvKeyContext *ibcPrvKeyCtx,
	uint32 atvPolicy,
	OctString *atvID
);

int32 IBCSetPrivateKeyStr(
	IBCPrvKeyContext ibcPrvKeyCtx,
	uint8 groupId,
	uint8 *keyStr,
	uint32 keyLen
);

/*****************Chap Operation***************/
int32 GMChapExportIBCPrvKeyAttribute(
	uint8 *id_ptr, 
	int32 *idLen, 
	PrvKeyContext prvKeyCtx, 
	uint16 encoded
);

int32 GMChapGetExportedIBCPrvKeyAttribute(
   uint8 *id_ptr,
   uint8 *attrStore,
   int32 infoType
);

/******************Short Signature**************/
#ifdef AIX
int32 GMIBC_SSG(
	char *user_name,
	uint32 serial,
	uint32 ctype, 
	uint32 psize, 
	uint32 rsize, 
	uint32 kga,
	uint32 schema,
	char *paramFile,
	char *mkFile,
	uint8 *m_passwd,
	uint32 pwdLen
);
#else
int32 GMIBC_SSG(
	int8 *user_name,
	uint32 serial,
	uint32 ctype, 
	uint32 psize, 
	uint32 rsize, 
	uint32 kga,
	uint32 schema,
	int8 *paramFile,
	int8 *mkFile,
	uint8 *m_passwd,
	uint32 pwdLen
);
#endif

int32 GMIBC_SSV(
	IBCParamContext	ibcParam,
	uint8 *msg,
	uint32 mlen,
	uint8 *sign,
	uint32 slen,
	int32 gid
);

int32 GMIBC_SSS(
	IBCMasterKeyContext ibcMKeyCtx,
	IBCParamContext	ibcParam,
	uint8 *msg,
	uint32 mlen,
	uint8 *sign,
	uint32 *slen,
	uint32 gid
);

#define MAX_CPU32_INT_SIZE	0x7FFFFFFF

int32 InitEYIBC();
int32 InitEYIBCEx(int iFlag);
#define INIT_EYIBC_HARDRND					1
#define INIT_EYIBC_HEALTH_CHECK				2
#define INIT_EYIBC_HEALTH_CHECK_QUIT		4
#define INIT_EYIBC_HARDWARE_MISSING_QUIT	8

#define EYIBC_CONFIG_APP_PATH				1
#define	EYIBC_CONFIG_CHN_OID				2
#define EYIBC_CONFIG_CHN_CODE_METHOD		3
#define EYIBC_CONFIG_CHN_RAW_INF_STD_FORM	4
#define EYIBC_CONFIG_XC						5

int32 SetEYIBCConfig(int32 config, void *conf, int len);
int32 DestroyEYIBC();

int32 GMGetLastError();
void GMSetAlgDeviceHandle(void * pHandle);

int32 GMECS_Generate_EKeys(
	IBCParamContext	ibcParamCtx,
	uint8 *sKey,
	uint32 *sKeyLen,
	uint8 *pKey,
	uint32 *pKeyLen
);

int32 GMECS_Combine_PrvKey(
	PrvKeyContext hPrvKey,
	uint8 *eKey,
	uint32 eKeyLen
);

#ifdef __cplusplus
}
#endif

#endif
