﻿#include "gmibc.h"
#include "pbc/pbc_algid.h"

#include "oldapi.h"
#include "sign.h"
#include <memory.h>
#include <stdio.h>
#include <string.h>

// int main(int argc, char* argv[])
// {
// 	int sret=0;
	
//     unsigned char * sUserID = "8899";
// //   unsigned char * sUserID = "1095430210";
//     if(argc>1){
//     sUserID=argv[1];
//     }
	
// 	//演示代码：错误标识
// 	//unsigned char * sUserID = "abc000";
	
// 	//加密后的数据
// 	//存放的数据区长度必须要比需要加密的数据大，建议大256字节
// 	unsigned char signedData[sizeof(sUserID) + 256];
// 	unsigned int signedDataLen = sizeof(signedData);
// 	memset(signedData, 0, signedDataLen);
	
// 	sret = signSM9(sUserID, signedData, &signedDataLen);
	
// 	if (sret == 0)
// 	{
// 		printf("SM9_Sign successed\n");
// 		printf("signedDataLen %d \n", signedDataLen);
// 	}
// 	else
// 	{
// 		printf("SM9_SIGN error %d\n", sret);
// 	}

	
// 	return 0;
// }
