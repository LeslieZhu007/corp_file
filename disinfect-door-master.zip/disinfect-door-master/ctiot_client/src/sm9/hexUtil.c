/**
 * C program to convert Hexadecimal to binary number system
 */
#include <stdio.h>
#include <string.h>
#include "stdlib.h"

int hexstr_to_char(const char* hexstr, const char* file)
{
    size_t len = strlen(hexstr);
    printf("len: %i \n",len);
    if(len % 2 != 0) {
        return -1;
    }

    size_t final_len = len / 2;

    unsigned char* chrs = (unsigned char*)malloc((final_len + 1) * sizeof(*chrs));
  
    printf("chrs len : %i \n",strlen(chrs));
    memset(chrs, 0, final_len+1);

    int i = 0,j = 0,n = 0;

    unsigned char one;


    if( chrs == NULL )
       return -1;

    // clean file

    FILE *fp0;
    fp0 = fopen(file, "w");
    fclose(fp0);

    // write fstream

    FILE* fp1;
    fp1 = fopen(file, "r+");
    if(fp1 == NULL)
    {
        printf("%s: Opent file %s failed.\n", __FILE__, file);
        free(chrs);

        return -1;
    }

    for (i = 0, j = 0; j < final_len; i += 2, ++j) { 

        chrs[j - n] = (hexstr[i] % 32 + 9) % 25 * 16 + (hexstr[i+1] % 32 + 9) % 25;
        one = (hexstr[i] % 32 + 9) % 25 * 16 + (hexstr[i + 1] % 32 + 9) % 25;    

        if(0 == one){

            int pos1, pos2, pos3;

            // find first '\0'
            if (0 == n) {
                pos1 = fputs(chrs, fp1);
            } else { 

            // find another '\0'
                pos2 = fseek(fp1, 1, SEEK_END);
                pos3 = fputs("\0", fp1);
                pos1 = fputs(chrs, fp1);

            }
            memset(chrs, 0, final_len); //clear chrs
            n = j + 1;

        }

    }

     // add last chrs
    if (n != 0 && strlen(chrs) != 0)
    {
        int pos1, pos2, pos3;
        pos2 = fseek(fp1, 1, SEEK_END);
        pos3 = fputs("\0", fp1);
        pos1 = fputs(chrs, fp1);
    } else {
        int pos4;
        pos4 = fputs(chrs, fp1);
    }
    
    fclose(fp1);
    free(chrs);

    return 0;

}

int hexToBinFile(char* read,char* write)
{
    char* bin;
    char hex[3860];
    FILE *fp;

    fp = fopen(read, "r");
    if(fp == NULL)
    {
        printf("%s: Opent file %s failed.\n", __FILE__, read);
        return -1;
    }
    memset(hex,0,sizeof(hex));
    fscanf(fp, "%s", hex);
    fclose(fp);

    hexstr_to_char(hex, write);
    return 0;
}
 


