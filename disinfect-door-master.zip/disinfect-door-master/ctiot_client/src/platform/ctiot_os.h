/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/

#ifndef __CTIOT_OS_H
#define __CTIOT_OS_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef WIN32
#include <memory.h>
#include <process.h>  
#include <windows.h>
#else
#if defined(OS_FREERTOS_CT)
#include "FreeRTOS.h"
#include "task.h"
#include "rtosqueue.h"
#include "rtostimers.h"
#include "FreeRTOSConfig.h"
#include "wm_osal.h"
#include <wm_mem.h>
#include "semphr.h"
#else
#include <semaphore.h> 
#include <pthread.h> 
#endif //defined(OS_FREERTOS_CT)
#endif

#ifdef WIN32
typedef HANDLE T_THREAD_ID;
typedef HANDLE T_MUTEX_ID;
typedef HANDLE T_SEM_ID;
#else
#if defined(OS_FREERTOS_CT)
typedef void * T_MUTEX_ID;
typedef void * T_SEM_ID;
#else
typedef pthread_mutex_t T_MUTEX_ID;
typedef sem_t           T_SEM_ID;
#endif

#define INVALID_SOCKET -1
#endif


#ifdef WIN32
#define OS_CREATE_THREAD(ATTR,STACK_SIZE,ENTRY, ARG,FLAGS,ID) CreateThread(ATTR,STACK_SIZE, ENTRY, ARG,FLAGS,ID)
#define OS_CREATE_EXIT(ID,ATTR,ENTRY, ARG) pthread_create(ID,ATTR,ENTRY, ARG)
#else
#if defined(OS_FREERTOS_CT)
#define OS_CREATE_THREAD(ENTRY,NAME,STACK_TYPE,TASK_STACKSZ,TASK_PRIO) xTaskCreateExt(ENTRY, NAME, STACK_TYPE, TASK_STACKSZ, NULL, TASK_PRIO, NULL)
#else
#define OS_CREATE_THREAD(ID,ATTR,ENTRY, ARG) pthread_create(ID,ATTR,ENTRY, ARG)
#define OS_CREATE_EXIT(ARG) pthread_exit( ARG)
#endif//defined(OS_FREERTOS_CT)
#endif

#ifdef __x86_64__
#ifdef MEM_TEST
#define OS_GET_MEM(PTR,TYPE,SIZE) {(PTR) = (TYPE*)malloc(SIZE); PRINT_STRING("OS_GET_MEM %p,size:%u,%s,line:%u, count: %d\n",PTR,SIZE,__FILE__,__LINE__,ctiot_mem_get(SIZE,PTR));}
#define OS_PUT_MEM(PTR) {if(PTR != NULL) free(PTR); PRINT_STRING("OS_PUT_MEM %p,%s,line:%u, count:%d\n",PTR,__FILE__,__LINE__,ctiot_mem_put(PTR)); PTR = NULL;}
#else
#define OS_GET_MEM(PTR,TYPE,SIZE) {(PTR) = (TYPE*)malloc(SIZE); }
#define OS_PUT_MEM(PTR) {if(PTR != NULL) free(PTR);}
#endif
#else
#if defined(OS_FREERTOS_CT)
#ifdef MEM_TEST
#define OS_GET_MEM(PTR,TYPE,SIZE) {(PTR) = (TYPE *)tls_mem_alloc(SIZE); PRINT_STRING("OS_GET_MEM %p,size:%u,%s,line:%u, count: %d\n",PTR,SIZE,__FILE__,__LINE__,ctiot_mem_get(SIZE,PTR));}
#define OS_PUT_MEM(PTR) {if(PTR != NULL) tls_mem_free(PTR); PRINT_STRING("OS_PUT_MEM %p,%s,line:%u, count:%d\n",PTR,__FILE__,__LINE__,ctiot_mem_put(PTR)); PTR = NULL;}
#else
#define OS_GET_MEM(PTR,TYPE,SIZE) {(PTR) = (TYPE *)tls_mem_alloc(SIZE);}
#define OS_PUT_MEM(PTR) {if(PTR != NULL) tls_mem_free(PTR);}
#endif
#else
#ifdef MEM_TEST
#define OS_GET_MEM(PTR,TYPE,SIZE) {(PTR) = (TYPE*)malloc(SIZE); PRINT_STRING("OS_GET_MEM %p,size:%u,%s,line:%u, count: %d\n",PTR,SIZE,__FILE__,__LINE__,ctiot_mem_get(SIZE,PTR));}
#define OS_PUT_MEM(PTR) {if(PTR != NULL) free(PTR); PRINT_STRING("OS_PUT_MEM %p,%s,line:%u, count:%d\n",PTR,__FILE__,__LINE__,ctiot_mem_put(PTR)); PTR = NULL;}
#else
#define OS_GET_MEM(PTR,TYPE,SIZE) {(PTR) = (TYPE*)malloc(SIZE); }
#define OS_PUT_MEM(PTR) {if(PTR != NULL) free(PTR);}
#endif
#endif
#endif
#ifdef WIN32
#define OS_CREATE_MUTEX(ATT,OWNER,NAME)  CreateMutex(ATT,OWNER,NAME)
#define OS_GET_MUTEX(MUTEX)              WaitForSingleObject(MUTEX,INFINITE)
#define OS_PUT_MUTEX(MUTEX)              ReleaseMutex(MUTEX)
#define OS_CLOSE_MUTEX(MUTEX)            CloseHandle(MUTEX)
#else
#if defined(OS_FREERTOS_CT)
#define OS_CREATE_MUTEX(MUTEX)           MUTEX = xSemaphoreCreateMutex()
#define OS_GET_MUTEX(MUTEX)              xSemaphoreTake(MUTEX, portMAX_DELAY)
#define OS_PUT_MUTEX(MUTEX)              xSemaphoreGive(MUTEX)
#define OS_CLOSE_MUTEX(MUTEX)            vSemaphoreDelete(MUTEX)

#else

#define OS_CREATE_MUTEX(MUTEX)  pthread_mutex_init(MUTEX,NULL)
#define OS_GET_MUTEX(MUTEX)              pthread_mutex_lock(MUTEX)
#define OS_PUT_MUTEX(MUTEX)              pthread_mutex_unlock(MUTEX)
#define OS_CLOSE_MUTEX(MUTEX)            pthread_mutex_destroy(MUTEX)
#endif
#endif


#ifdef WIN32
#define OS_CREATE_SEMOPHORE(ATT,MIN_VAL,MAX_VAL,NAME) CreateSemaphore(ATT,MIN_VAL,MAX_VAL,NAME)
#define OS_OPEN_SEMOPHORE(SEM) OpenSemaphore(SEM)
#define OS_PUT_SEMOPHORE(SEM) ReleaseSemaphore(SEM,1,NULL)
#define OS_GET_SEMOPHORE(SEM) WaitForSingleObject(SEM,INFINITE)
#define OS_CLOSE_SEMOPHORE(SEM) CloseHandle(SEM)
#else
#if defined(OS_FREERTOS_CT)
#define OS_CREATE_SEMOPHORE(SEM, ARG,VAL) vSemaphoreCreateBinary(SEM)
#define OS_PUT_SEMOPHORE(SEM)             xSemaphoreGive(SEM)
#define OS_GET_SEMOPHORE(SEM)             xSemaphoreTake(SEM, portMAX_DELAY)
#define OS_CLOSE_SEMOPHORE(SEM)           vSemaphoreDelete(SEM)

#else

#define OS_CREATE_SEMOPHORE(SEM, ARG,VAL) sem_init(SEM,ARG,VAL)
#define OS_PUT_SEMOPHORE(SEM) sem_post(SEM)
#define OS_GET_SEMOPHORE(SEM) sem_wait(SEM)
#define OS_CLOSE_SEMOPHORE(SEM) sem_destroy(SEM)
#endif
#endif
/*
#ifdef WIN32
#define OS_CREATE_TIMER(TMR_HDL)
#define OS_START_TIMER(TMR_HDL,TMR_LEN,RESOLUTION,API_CALLBACK,ARGS,TYPE) TMR_HDL = timeSetEvent(TMR_LEN,RESOLUTION,API_CALLBACK,ARGS,TYPE)
#define OS_STOP_TIMER(TMR_HDL) {timeKillEvent(TMR_HDL);TMR_HDL = 0;}

#else
#define OS_CREATE_TIMER(TMR_HDL) signal(SIGALRM, TMR_HDL);
#define OS_START_TIMER(ARGS) alarm(ARGS)
#define OS_STOP_TIMER(ARGS) alarm(ARGS)

#endif*/

/*unit:ms*/
#if defined(OS_FREERTOS_CT)
#define OS_SLEEP(MS) vTaskDelay(MS/2)
#else
#define OS_SLEEP(MS) usleep(MS*1000)
#endif

#if defined(MEM_TEST)
int ctiot_mem_get();
int ctiot_mem_put();
#endif

#endif
