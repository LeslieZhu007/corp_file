/*******************************************************************************
 * Copyright (c) 2014, 2017 IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * and Eclipse Distribution License v1.0 which accompany this distribution.
 *
 * The Eclipse Public License is available at
 *    http://www.eclipse.org/legal/epl-v10.html
 * and the Eclipse Distribution License is available at
 *   http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * Contributors:
 *    Allan Stockdill-Mander - initial API and implementation and/or initial documentation
 *    Ian Craggs - return codes from linux_read
 *******************************************************************************/

#include "MQTTLinux.h"
#include "ctiot_tlink.h"
#include "ctiot_log.h"
#include "ctiot_if_status.h"
#include "ctiot_tlink_config.h"
#include "ctiot_basetype.h"
#define mbedtls_printf printf


#ifdef USE_SSL
#define CA_CERT_FILE "ca.crt"
#define CLIENT_CERT_FILE "client.crt"
#define CLIENT_KEY_FILE "client.key"
#endif

void TimerInit(Timer* timer)
{
	timer->end_time = (struct timeval){0, 0};
}

char TimerIsExpired(Timer* timer)
{
	struct timeval now, res;
	gettimeofday(&now, NULL);
	timersub(&timer->end_time, &now, &res);
	return res.tv_sec < 0 || (res.tv_sec == 0 && res.tv_usec <= 0);
}


void TimerCountdownMS(Timer* timer, unsigned int timeout)
{
	struct timeval now;
	gettimeofday(&now, NULL);
	struct timeval interval = {timeout / 1000, (timeout % 1000) * 1000};
	timeradd(&now, &interval, &timer->end_time);
}


void TimerCountdown(Timer* timer, unsigned int timeout)
{
	struct timeval now;
	gettimeofday(&now, NULL);
	struct timeval interval = {timeout, 0};
	timeradd(&now, &interval, &timer->end_time);
}


int TimerLeftMS(Timer* timer)
{
	struct timeval now, res;
	gettimeofday(&now, NULL);
	timersub(&timer->end_time, &now, &res);
	//printf("left %d ms\n", (res.tv_sec < 0) ? 0 : res.tv_sec * 1000 + res.tv_usec / 1000);
	return (res.tv_sec < 0) ? 0 : res.tv_sec * 1000 + res.tv_usec / 1000;
}


int linux_read(Network* n, unsigned char* buffer, int len, int timeout_ms,char* file,unsigned long line)
{
	struct timeval interval = {timeout_ms / 1000, (timeout_ms % 1000) * 1000};
	if (interval.tv_sec < 0 || (interval.tv_sec == 0 && interval.tv_usec <= 0))
	{
		interval.tv_sec = 0;
		interval.tv_usec = 100;
	}

	setsockopt(n->my_socket, SOL_SOCKET, SO_RCVTIMEO, (char *)&interval, sizeof(struct timeval));
	if(socket_connected(n->my_socket)==0)
	{
	    return -1;
	}
	int bytes = 0;
	while (bytes < len)
	{		
	    #if defined(USE_MBEDTLS)
		int rc = 0;
		if(n->connect_mode == 2||n->connect_mode == 3)
		{
			rc = mbedtls_ssl_read(&(n->ssl), &buffer[bytes], (size_t)(len - bytes));
		}
		else if(n->connect_mode == 1)
		{
			rc = recv(n->my_socket, &buffer[bytes], (size_t)(len - bytes), 0);
		}
	    #elif defined(USE_SSL)
		int rc = SSL_read(n->ssl,  &buffer[bytes], (size_t)(len - bytes));
        #else
		int rc = recv(n->my_socket, &buffer[bytes], (size_t)(len - bytes), 0);
        #endif
		if (rc < 0)
		{
			if (errno != EAGAIN && errno != EWOULDBLOCK)
			{
			    #ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("Read socket: rc<0, %u\n",errno);
				#endif
                bytes = -1;
			}
			#if defined(USE_MBEDTLS)
				if(n->connect_mode == 2||n->connect_mode == 3)
				{
					switch( rc )
					{
						case MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY:
							log_print_plain_text( " connection was closed gracefully\n" );
							log_print_plain_text( "  . Closing the connection..." );
							log_print_plain_text( " done\n" );
							break;
						case 0:
						case MBEDTLS_ERR_NET_CONN_RESET:
							log_print_plain_text( " connection was reset by peer\n" );
							break;
						default:
							break;
					}
				}
			#endif
			break;
		}
		else if (rc == 0)
		{
            //printf("Read socket: rc=0\n");
			bytes = 0;
			break;
		}
		else
		{
            bytes += rc;
		}
	}    
	return bytes;
}


int linux_write(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	struct timeval tv;

	tv.tv_sec = 0;  /* 30 Secs Timeout */
	tv.tv_usec = timeout_ms * 1000;  // Not init'ing this can cause strange errors
	//#ifdef ID_LEVEL_LOG_COMPILE
    //log_print_plain_text("linux_write:1\n");
	//#endif
	setsockopt(n->my_socket, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv,sizeof(struct timeval));
    //#ifdef ID_LEVEL_LOG_COMPILE
    //log_print_plain_text("linux_write:2\n");
	//#endif
	int rc=0;
	if(socket_connected(n->my_socket)!=0)
	{   
	    #if defined(USE_MBEDTLS)
		if(n->connect_mode == 2||n->connect_mode == 3)
		{
			rc = mbedtls_ssl_write(&(n->ssl), buffer, len);
		}
		else if(n->connect_mode == 1)
		{
			rc = write(n->my_socket, buffer, len);
		}
	    #elif defined(USE_SSL)
	    rc = SSL_write(n->ssl, buffer, len);
        #else
	    rc = write(n->my_socket, buffer, len);
		#endif
	}
	//#ifdef ID_LEVEL_LOG_COMPILE
    //log_print_plain_text("linux_write:rc=%d\n",rc);
	//#endif
	return rc;
}


void NetworkInit(Network* n)
{
	n->my_socket = 0;
	n->mqttread = linux_read;
	n->mqttwrite = linux_write;

	#if defined(USE_MBEDTLS)
	if(n->connect_mode == 2 || n->connect_mode == 3)
	{
		mbedtls_net_init(&(n->fd));
    	mbedtls_ssl_init(&(n->ssl));
    	mbedtls_ssl_config_init(&(n->conf));
    	mbedtls_x509_crt_init(&(n->cacertc));
    	mbedtls_ctr_drbg_init(&(n->ctr_drbg));
		mbedtls_entropy_init(&(n->entropy));
	}
	#elif defined(USE_SSL)
    n->ctx = NULL;
    n->ssl = NULL;
    #endif
}

static void my_debug(void *ctx, int level,
	const char *file, int line, const char *str)
{
	((void)level);
	fprintf((FILE *)ctx, "%s:%04d: %s", file, line, str);
	fflush((FILE *)ctx);
}

int NetworkConnect(Network* n, char* addr, int port)
{
	int type = SOCK_STREAM;
	struct sockaddr_in address;
	int rc = -1;
	sa_family_t family = AF_INET;
	struct addrinfo *result = NULL;
	struct addrinfo hints = {0, AF_UNSPEC, SOCK_STREAM, IPPROTO_TCP, 0, NULL, NULL, NULL};
	#if defined(USE_MBEDTLS)
	if(n->connect_mode == 2 || n->connect_mode == 3)
	{
		int len;
		const char *pers = "emq_ssl_client";
		mbedtls_printf("\n  . Seeding the random number generator...\n");
		if((rc = mbedtls_ctr_drbg_seed(&(n->ctr_drbg), mbedtls_entropy_func, &(n->entropy),
								(const unsigned char *) pers,
								strlen(pers))) != 0)
		{
			mbedtls_printf("\n failed	! mbedtls_ctr_drbg_seed returned %d\n", rc);
			goto exit;
		}

		mbedtls_printf(" mbedtls_ctr_drbg_seed ok\n");	
		#if defined(SSL_CERTIFICATE_MONO) || defined(SSL_CERTIFICATE_DUAL)			
		if(n->connect_mode == 2 || n->connect_mode == 3)
		{	   
			mbedtls_printf("  . Loading the CA root certificate ...\n");

			if(ca_crt != NULL)
			{
				#if defined(MBEDTLS_FS_IO)
					if( strlen( ca_crt ) )
						if( strcmp( ca_crt, "none" ) == 0 )
							rc = 0;
						else
							rc = mbedtls_x509_crt_parse_file( &(n->cacertc), ca_crt );
				#endif
				#if defined(MBEDTLS_CERTS_C)
				rc = mbedtls_x509_crt_parse(&(n->cacertc), (const unsigned char *) ca_crt, strlen(ca_crt) + 1);
				#endif
				if (rc != 0)
				{
					mbedtls_printf(" failed\n  !  mbedtls_x509_crt_parse returned -0x%x\n\n", -rc);
					rc = CTIOT_TLS_ROOT_CERTIFICATE_ERROR;
					goto exit;
				}
			}
			mbedtls_printf(" mbedtls_x509_crt_parse ok (%d skipped)\n", rc);
		}
		#endif
		#if defined(SSL_CERTIFICATE_DUAL)
		if(n->connect_mode == 3)
		{	
			if (client_crt != NULL && client_key != NULL) 
			{
				mbedtls_printf(" start prepare client cert .\n");
			#if defined(MBEDTLS_FS_IO)
				if( strlen( client_crt ) )
						if( strcmp( client_crt, "none" ) == 0 )
							rc = 0;
						else
							rc = mbedtls_x509_crt_parse_file(&(n->clicert), client_crt );
			#endif
			#if defined(MBEDTLS_CERTS_C)
				rc = mbedtls_x509_crt_parse(&(n->clicert), (const unsigned char *) client_crt, strlen(client_crt) + 1);
			#endif
				if (rc != 0) {
					mbedtls_printf(" failed!  mbedtls_x509_crt_parse returned -0x%x\n\n", -rc);
					rc = CTIOT_TLS_CLIENT_CERTIFICATE_ERROR;
					goto exit;
				}
				mbedtls_printf("prepare client cert ok.\n");
				mbedtls_printf("start mbedtls_pk_parse_key .\n");
			#if defined(MBEDTLS_FS_IO)
				if( strlen( client_key ) )
					if( strcmp( client_key, "none" ) == 0 )
						rc = 0;
					else
						rc = mbedtls_pk_parse_keyfile( &(n->pkey), client_key, NULL );
			#endif
			#if defined(MBEDTLS_CERTS_C)
				rc = mbedtls_pk_parse_key(&(n->pkey),
												(const unsigned char *) client_key, strlen(client_key) + 1,
												NULL, 0	);
			#endif
				if (rc != 0) {
					mbedtls_printf(" failed\n  !  mbedtls_pk_parse_key returned -0x%x\n\n", -rc);
					rc = CTIOT_TLS_CLIENT_KEY_ERROR;
					goto exit;
				}
				mbedtls_printf("prepare mbedtls_pk_parse_key ok.\n");
			}
		}
		#endif
	}
	#endif

	#if defined(USE_SSL)
	SSL_library_init();
	OpenSSL_add_all_algorithms(); 
	SSL_load_error_strings(); 

	n->ctx = SSL_CTX_new(SSLv23_client_method()); 
	if (n->ctx == NULL) {  
        printf("SSL_CTX_new fail!\n");
		return -1;
	}
	// 要求校验对方证书，表示需要验证服务器端，若不需要验证则使用  SSL_VERIFY_NONE
	
	#if !(defined(SSL_CERTIFICATE_MONO) || defined(SSL_CERTIFICATE_DUAL))
	SSL_CTX_set_verify(n->ctx, SSL_VERIFY_NONE, NULL);
	#else
	
    SSL_CTX_set_verify(n->ctx, SSL_VERIFY_PEER, NULL);
	// 加载CA的证书
	//printf("SSL_CTX_load_verify_locations start!\n");
    if(!SSL_CTX_load_verify_locations(n->ctx, CA_CERT_FILE, NULL))
    {
        //printf("SSL_CTX_load_verify_locations error!\n");
        return -1;
    }
	#endif
    //SSL_CTX_set_verify(n->ctx, SSL_VERIFY_NONE, NULL);

	#if  defined(SSL_CERTIFICATE_DUAL)
    // 加载自己的证书
    //printf("SSL_CTX_use_certificate_file start!\n");
    if(SSL_CTX_use_certificate_file(n->ctx, CLIENT_CERT_FILE, SSL_FILETYPE_PEM) <= 0)
    {
        //printf("SSL_CTX_use_certificate_file error!\n");
        return -1;
    }
	//// 加载自己的私钥 加载私钥需要密码，意思是每次链接服务器都需要密码
    //若服务器需要验证客户端的身份，则需要客户端加载私钥，由于此处我们只需要验证服务器身份，故无需加载自己的私钥
    //printf("SSL_CTX_use_PrivateKey_file start!\n");
	if(SSL_CTX_use_PrivateKey_file(n->ctx, CLIENT_KEY_FILE, SSL_FILETYPE_PEM) <= 0)
    {
        //printf("SSL_CTX_use_PrivateKey_file error!\n");
        return -1;
    }
    
    //// 判定私钥是否正确
    //printf("SSL_CTX_check_private_key start!\n");
    if(!SSL_CTX_check_private_key(n->ctx))
    {
        //printf("SSL_CTX_check_private_key error!\n");
        return -1;
    }

    #endif
#endif
	if ((rc = getaddrinfo(addr, NULL, &hints, &result)) == 0)
	{
		struct addrinfo* res = result;

		/* prefer ip4 addresses */
		while (res)
		{
			if (res->ai_family == AF_INET)
			{
				result = res;
				break;
			}
			res = res->ai_next;
		}

		if (result->ai_family == AF_INET)
		{
			address.sin_port = htons(port);
			address.sin_family = family = AF_INET;
			address.sin_addr = ((struct sockaddr_in*)(result->ai_addr))->sin_addr;
		}
		else
			rc = -1;

		freeaddrinfo(result);
	}

	if (rc == 0)
	{
		n->my_socket = socket(family, type, 0);
		if (n->my_socket != -1)
			rc = connect(n->my_socket, (struct sockaddr*)&address, sizeof(address));
		#if defined(USE_MBEDTLS)
		if(n->connect_mode == 2 || n->connect_mode == 3)
		{
			mbedtls_printf(" Setting up the SSL/TLS structure...\n");
			fflush(stdout);
			n->fd.fd = n->my_socket;
			if((rc = mbedtls_ssl_config_defaults(&(n->conf),
						MBEDTLS_SSL_IS_CLIENT,
						MBEDTLS_SSL_TRANSPORT_STREAM,
						MBEDTLS_SSL_PRESET_DEFAULT))!= 0)
			{
				mbedtls_printf(" failed\n  ! mbedtls_ssl_config_defaults returned %d\n\n", rc);
				goto exit;
			}

			mbedtls_printf("Setting up the SSL/TLS structure ok\n");
			#if defined(SSL_CERTIFICATE_DUAL) || defined(SSL_CERTIFICATE_MONO)
			mbedtls_ssl_conf_authmode(&(n->conf), MBEDTLS_SSL_VERIFY_OPTIONAL);
			#else
			mbedtls_ssl_conf_authmode(&(n->conf), MBEDTLS_SSL_VERIFY_NONE);
			#endif
			mbedtls_ssl_conf_rng(&(n->conf), mbedtls_ctr_drbg_random, &(n->ctr_drbg));
			mbedtls_ssl_conf_dbg(&(n->conf), my_debug, stdout);

			#if defined(MBEDTLS_X509_CRT_PARSE_C)
			mbedtls_ssl_conf_ca_chain(&(n->conf), &(n->cacertc), NULL);
			if ((rc = mbedtls_ssl_conf_own_cert(&(n->conf), &(n->clicert), &(n->pkey))) != 0) {
				mbedtls_printf(" failed\n  ! mbedtls_ssl_conf_own_cert returned %d\n\n", rc);
				return rc;
			}
			#endif

			if((rc = mbedtls_ssl_setup(&(n->ssl), &(n->conf))) != 0)
			{
				mbedtls_printf(" failed\n  ! mbedtls_ssl_setup returned %d\n\n", rc);
				goto exit;
			}

			if((rc = mbedtls_ssl_set_hostname(&(n->ssl), NULL)) != 0)
			{
				mbedtls_printf(" failed\n  ! mbedtls_ssl_set_hostname returned %d\n\n", rc);
				goto exit;
			}

			mbedtls_ssl_set_bio(&(n->ssl), &(n->fd), mbedtls_net_send, mbedtls_net_recv, NULL);

			mbedtls_printf("  . Performing the SSL/TLS handshake...\n");
			fflush(stdout);

			while((rc = mbedtls_ssl_handshake(&(n->ssl))) != 0)
			{
				if(rc != MBEDTLS_ERR_SSL_WANT_READ && rc != MBEDTLS_ERR_SSL_WANT_WRITE)
				{
					mbedtls_printf(" failed\n  ! mbedtls_ssl_handshake returned -0x%x\n\n", -rc);
					rc = CTIOT_TLS_HANDSHAKE_ERROR;
					goto exit;
				}
			}

			mbedtls_printf("Performing the SSL/TLS handshake ok\n");
			n->my_socket = (int)((n->fd).fd);

			if (rc != 0) {
				printf("connect fail\n");
			}
		}
		#endif
        if(rc == 0)
    	{
    	#ifdef USE_SSL
            n->ssl = SSL_new(n->ctx);  
        	SSL_set_fd(n->ssl, n->my_socket);  
          	if (SSL_connect(n->ssl) == -1) { 
                //printf("SSL_connect fail!\n");
        		//ERR_print_errors_fp(stderr);  
        		return -1;
        	}else {  
        		// printf("加密连接,算法:%s\n", SSL_get_cipher(n->ssl));  
        	}
		#endif

			//启动TCP层心跳
			//SocketCheck(n->my_socket);
    	}      
	}	
exit:
	if(rc != 0)
	{
		NetworkDisconnect(n);
	}
	return rc;
}


void NetworkDisconnect(Network* n)
{

    #ifdef USE_SSL
	SSL_shutdown(n->ssl);  
	SSL_free(n->ssl);
    #endif
	#if defined(USE_MBEDTLS)
	if(n->connect_mode == 2||n->connect_mode == 3)
	{
		mbedtls_ssl_close_notify(&(n->ssl));
	}
	#endif
	if(n->my_socket)
	{
		close(n->my_socket);
	}

	#if defined(USE_MBEDTLS)
	if(n->connect_mode == 2||n->connect_mode == 3)
	{
		#if defined(MBEDTLS_X509_CRT_PARSE_C)
		mbedtls_x509_crt_free( &(n->cacertc));
		if ((n->pkey).pk_info != NULL) {
			mbedtls_printf("emq need free client crt&key\n");
			mbedtls_x509_crt_free( &(n->clicert));
			mbedtls_pk_free( &(n->pkey) );
		}
		#endif
		mbedtls_ssl_free( &(n->ssl));
		mbedtls_ssl_config_free(&(n->conf));
		mbedtls_ctr_drbg_free( &(n->ctr_drbg) );
		mbedtls_entropy_free( &(n->entropy) );
		mbedtls_printf("emq_ssl_disconnect!\n" );
	}
	#elif defined(USE_SSL)
	SSL_CTX_free(n->ctx);
    #endif
}
int socket_connected(int sock) 
{
    if(sock<=0) 
    {
        return 0;
    }
    struct tcp_info info; 
    int len=sizeof(info); 
    getsockopt(sock, IPPROTO_TCP, TCP_INFO, &info, (socklen_t *)&len);
    if((info.tcpi_state==TCP_ESTABLISHED)) 
    { 
		return 1;
    } 
    else 
    {
        return 0; 
    }

}


