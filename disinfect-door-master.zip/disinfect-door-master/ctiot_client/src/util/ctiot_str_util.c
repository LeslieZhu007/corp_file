#include "ctiot_str_util.h"


unsigned long long ctiot_atoll(char* inStr)
{
	unsigned long long retval;
	int i;
	retval = 0;
	for (; *inStr ; inStr++)
	{
			retval = 10 * retval + (*inStr - '0');
	}
	return retval;
}

void ctiot_get_hexadecimal(int strLen, char* str, unsigned char* hexStr)
{
	int i = 0;
	int j = 0;
	unsigned char hex;
	unsigned char f = 0;
	unsigned char l = 0;
	for(;i < strLen;i++){
		if(str[i]<='9' && str[i]>='0'){
			f = str[i] - '0';
		}else if(str[i] >= 'a' && str[i] <= 'f'){
			f = str[i] - 'a' + 10;
		}else if(str[i] >= 'A' && str[i] <= 'F'){
			f = str[i] - 'A' + 10;
		}
		if(i%2 == 0){
			hex = f << 4;
		}else{
			hex = hex + f;
			hexStr[j] = hex;
			j++;
		}
	}
	hexStr[j] = '\0';
}

void ctiot_convert_to_hex(int strlen , char* str , char* hexStr)
{
	int i = 0;
	for (i = 0 ; i < strlen ; i++) {
		sprintf (hexStr + (i * 2) , "%02x" , str[i]);
	}
	hexStr[2 * strlen] = '\0';
}

int is_number_validate(char *data)
{
  int i;

  for(i=0;  i<strlen(data) ; i++)
	{
		if(data[i]<'0' || data[i]>'9')
		{
			return NUMBER_PARSE_ERROR;
		}
	}
	return NUMBER_PARSE_SUCCESS;
}

void str2upper(char *str)
{
	int i = 0;
	for(i = 0; i < strlen(str); i ++)
	{
		if((str[i] >= 'a') && (str[i] <= 'z'))
		{
			str[i] = toupper(str[i]);
		}
	}
}

void ltrim ( char *s )
{
	char *p;
	p = s;
	while ( *p == ' ' || *p == '\t' ) {*p++;}
	strcpy ( s,p );
}

void rtrim ( char *s )
{
	int i;
	i = strlen ( s )-1;
	while ( ( s[i] == ' ' || s[i] == '\t' ) && i >= 0 ) {i--;};
	s[i+1] = '\0';
}

void trim ( char *s )
{
	ltrim ( s );
	rtrim ( s );
}

