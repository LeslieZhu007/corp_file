#include <string.h>
#include "ctiot_if_status.h"
int cshell_netlink_status(char *if_name)
{
	char    buffer[BUFSIZ];
	char    cmd[100];
	FILE    *read_fp;
	int        chars_read;
	int        ret =0;
 
	memset( buffer, 0, BUFSIZ );
	memset( cmd, 0, 100 );
	sprintf(cmd, "ifconfig -a | grep %s",if_name);
	read_fp = popen(cmd, "r");
	if ( read_fp != NULL )
	{
		chars_read = fread(buffer, sizeof(char), BUFSIZ-1, read_fp);
		pclose(read_fp);
 
		if (chars_read > 0)
		{
			ret = 1;
		}
		else
		{
			fprintf(stderr, "DEVICE_NONE\r\n");
			return 0;
		}
	}
 
	if(ret == 1)
	{
		memset( buffer, 0, BUFSIZ );
		memset( cmd, 0, 100 );
		sprintf(cmd, "ifconfig |grep %s",if_name);
		read_fp = popen(cmd, "r");
		if ( read_fp != NULL )
		{
			chars_read = fread(buffer, sizeof(char), BUFSIZ-1, read_fp);
			pclose(read_fp);
 
			if (chars_read > 0)
			{
				ret = 2;
			}
			else
			{
				fprintf(stderr, "DEVICE_DOWN\r\n");
			return 1;
			}
		}
	}
 
	if(ret == 2)
	{
		memset( buffer, 0, BUFSIZ );
		memset( cmd, 0, 100 );
		sprintf(cmd, "ifconfig %s | grep RUNNING |  awk '{print $3}'",if_name);
		read_fp = popen(cmd, "r");
		if ( read_fp != NULL )
		{
		    chars_read = fread(buffer, sizeof(char), BUFSIZ-1, read_fp);
		    pclose(read_fp);
			
		    if (chars_read > 0)
		    {
				fprintf(stderr, "DEVICE_LINKED\r\n");
				return 3;
		    }
		    else
		    {
				fprintf(stderr, "DEVICE_UNPLUGGED\r\n");
				return 2;
		    }
		}
	}
 
	return -1;
}
 
int c_netlink_status(const char *if_name )
{
	int fd = -1; 
	struct ifreq ifr; 
 
	struct ifconf ifc;  
	struct ifreq ifrs_buf[100]; 
	int if_number =0;
	int i;
 
 
	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		fprintf(stderr, "%s: socket error [%d] %s\r\n",if_name, errno, strerror(errno));
		close(fd);
		return -1; 
	}
 
	ifc.ifc_len = sizeof(ifrs_buf);  
	ifc.ifc_buf = (caddr_t)ifrs_buf;  
	if (ioctl(fd, SIOCGIFCONF, (char *)&ifc) <0)  
	{
		fprintf(stderr, "%s: ioctl SIOCGIFCONF error [%d] %s\r\n",if_name, errno, strerror(errno));
		close(fd);
		return -1; 
	}
 
	if_number = ifc.ifc_len / sizeof(struct ifreq);
	for(i=0; i< if_number; i++)
	{
		if(strcmp(if_name,ifrs_buf[i].ifr_name ) == 0)
		{
			break;
		}
	}
 
	if(i >= if_number)
	{
		close(fd);
		fprintf(stderr, "DEVICE_NONE\r\n");
		return 0;
	}
	
	bzero(&ifr, sizeof(ifr));
	strncpy(ifr.ifr_name, if_name, IFNAMSIZ-1); 
	ifr.ifr_name[IFNAMSIZ-1] = 0; 
	if (ioctl(fd, SIOCGIFFLAGS, (char *)&ifr) <0)  
	{
		fprintf(stderr, "%s: ioctl SIOCGIFFLAGS error [%d] %s\r\n",if_name, errno, strerror(errno));
		close(fd);
		return -1; 
	}
#if 1	
	if(!(ifr.ifr_flags & IFF_UP))
	{
		close(fd);
		fprintf(stderr, "DEVICE_DOWN\r\n");
		return 1;
	}
	
	if(!(ifr.ifr_flags & IFF_RUNNING))
	{
		close(fd);
		fprintf(stderr, "DEVICE_UNPLUGGED\r\n");
		return 2 ;
	}
 
	fprintf(stderr, "DEVICE_LINKED\r\n");
	return 3;
 
#else
{
	struct ethtool_value edata;
	if(!(ifr.ifr_flags & IFF_UP) || !(ifr.ifr_flags & IFF_RUNNING))
	{
		close(fd);
		fprintf(stderr, "%s: DOWN\r\n",if_name);
		return 1;
	}
	edata.cmd = ETHTOOL_GLINK;
	edata.data = 0;
	ifr.ifr_data = (char *) &edata;
	if(ioctl( fd, SIOCETHTOOL, &ifr ) < 0)
	{
		fprintf(stderr, "%s: ioctl SIOCETHTOOL error [%d] %s\r\n",if_name, errno, strerror(errno));
		close(fd);
		return -1; 
	}
 
	if(edata.data == 0)
	{
		fprintf(stderr, "DEVICE_UNPLUGGED\r\n");
		return 2; 
	}
	else
	{
		fprintf(stderr, "DEVICE_LINKED\r\n");
		return 3; 
	}
}
#endif
}
int SocketCheck(int Client)
{
    int keepAlive = 1;//设定KeepAlive
    int keepIdle = 5;//开始首次KeepAlive探测前的TCP空闭时间
    int keepInterval = 5;//两次KeepAlive探测间的时间间隔
    int keepCount =2;//判定断开前的KeepAlive探测次数
    if(setsockopt(Client,SOL_SOCKET,SO_KEEPALIVE,(void*)&keepAlive,sizeof(keepAlive)) == -1)
    {
        return 0;
    }
    if(setsockopt(Client,SOL_TCP,TCP_KEEPIDLE,(void *)&keepIdle,sizeof(keepIdle)) == -1)
    {
        return 0;
    }

    if(setsockopt(Client,SOL_TCP,TCP_KEEPINTVL,(void *)&keepInterval,sizeof(keepInterval)) == -1)
    {
        return 0; 
    }

    if(setsockopt(Client,SOL_TCP,TCP_KEEPCNT,(void *)&keepCount,sizeof(keepCount)) == -1)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}
int IsSocketClosed(int clientSocket)  
{  
 char buff[32];  
 int recvBytes = recv(clientSocket, buff, sizeof(buff), MSG_PEEK);  
   
 int sockErr = errno;  
   
 //cout << "In close function, recv " << recvBytes << " bytes, err " << sockErr << endl;  
   
 if( recvBytes > 0) //Get data  
  return 0;  
   
 if( (recvBytes == -1) && (sockErr == EWOULDBLOCK) ) //No receive data  
  return 0;  
     
 return 1;  
}
#if 0 
int main(int argc, char* argv[])
{
	int i=0;
	if(argc != 2)
	{
		fprintf(stderr, "usage: %s <ethname>\r\n", argv[0]);
		return -1;
	}
	while(1)
	{
		//i = cshell_netlink_status(argv[1]);
	 
		//printf( "cshell_netlink_status if_status = %d\n", i );
	 
		i = c_netlink_status(argv[1]);
		printf( "c_netlink_status if_status = %d\n", i );
		usleep(1000000);
	}
	return 0;
}
#endif