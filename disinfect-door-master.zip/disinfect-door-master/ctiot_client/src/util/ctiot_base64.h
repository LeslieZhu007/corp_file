/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __BASE64__H
#define __BASE64__H

int ctiot_base64_encode( const unsigned char * bindata, char * base64, int binlength );
int ctiot_base64_decode( const char * base64, unsigned char * bindata );
#endif