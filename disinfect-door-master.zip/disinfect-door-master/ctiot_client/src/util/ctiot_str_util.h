#ifndef _STR_UTIL_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _STR_UTIL_H_

typedef enum {
   NUMBER_PARSE_ERROR = -3,
   NUMBER_PARSE_SUCCESS = 0
}NUMBER_ERROR_TYPE;

unsigned long long ctiot_atoll(char* inStr);

void ctiot_get_hexadecimal(int strLen, char* str, unsigned char* hexStr);

void ctiot_convert_to_hex(int strlen , char* str , char* hexStr);

int is_number_validate(char *data);

void str2upper(char *str);

void ltrim ( char *s );

void rtrim ( char *s );

void trim ( char *s );

#endif