#ifndef _CTIOT_IF_STATUS_H

#define _CTIOT_IF_STATUS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
 
 
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <linux/mii.h>
#include <linux/sockios.h>
#include <errno.h>
 
#include <ifaddrs.h>
#include <arpa/inet.h> 
#include <netinet/tcp.h>
#include  <linux/ethtool.h>

int cshell_netlink_status(char *if_name);
int c_netlink_status(const char *if_name);
int SocketCheck(int Client);
int IsSocketClosed(int clientSocket);
#endif//_CTIOT_IF_STATUS_H