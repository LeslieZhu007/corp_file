/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include <stdio.h>
#include <time.h>
#ifdef HTTP_OPENSSL
#include <openssl/ssl.h>
#include <openssl/err.h>
#endif
#ifdef HTTP_MBEDTLS
#include "compat-1.3.h"
#include "net.h"
#include "ssl.h"
#include "certs.h"
#include "entropy.h"
#include "ctr_drbg.h"
#endif

#define HOST_NAME_LEN 256
#define URI_MAX_LEN 2048
#define RECV_BUF 8192
#define POST_BUF_LEN 512
#define RCV_SND_TIMEOUT (10 * 1000) //!< 收发数据超时时间(ms)

#define bool int
#define false 0
#define true 1

typedef enum{
    DOWNLOAD_SUCCESS = 1300,
    SOCK_CONNECT_FAIL = 1301,
    URI_NOT_FOUND = 1302,
    DOWNLOAD_FAIL = 1303,
    OTHER_REASON = 1304
}HTTP_RESULT;

//*****************************************************************************
//! @addtogroup http_t结构体
//! @{
//*****************************************************************************
typedef void (*DOWNLOAD_FINISH)(unsigned char[]);
typedef struct
{
    unsigned long addr;              //!< 服务器地址
    int sock;                        //!< 与服务器通信的socket
    FILE *in;                        //!< sock描述符转为文件指针，方便读写
    char hostName[HOST_NAME_LEN];    //!< 主机名
    int port;                        //!< 主机端口号
    char uri[URI_MAX_LEN];           //!< 资源路径
    char buffer[RECV_BUF];           //!< 读写缓冲
    int statusCode;                  //!< http状态码
    int chunkedFlag;                 //!< chunked传输的标志位
    int len;                         //!< Content-length里的长度
    char location[URI_MAX_LEN];      //!< 重定向地址
    char *savePath;                  //!< 保存内容的路径指针
    FILE *saveFile;                  //!< 保存内容的文件指针
    int recvDataLen;                 //!< 收到数据的总长度
    time_t startRecvTime;            //!< 开始接受数据的时间
    time_t endRecvTime;              //!< 结束接受数据的时间
    int restLen;                     //!< 剩余部分的长度
#ifdef HTTP_OPENSSL
    SSL_CTX *ctx;                    //!< openssl链接配置
    SSL *ssl;                        //!< openssl链接句柄
#endif  
#ifdef HTTP_MBEDTLS
    mbedtls_ssl_context ssl;  //mbed TLS control context.
    mbedtls_net_context fd;   //mbed TLS network context.
    mbedtls_ssl_config  conf;  //mbed TLS configuration context.
    mbedtls_x509_crt    cacertc; //mbed TLS CA certification.
    mbedtls_x509_crt    clicert; //mbed TLS Client certification.
    mbedtls_pk_context  pkey;  //mbed TLS Client key
    mbedtls_entropy_context entropy; //mbed TLS entropy
    mbedtls_ctr_drbg_context ctr_drbg; //mbed TLS drbg context
    mbedtls_ssl_session saved_session;
#endif
} http_t;
//****************************************************************************
//! @}
//****************************************************************************

//*****************************************************************************
//! @addtogroup 打印宏定义
//! @{
//*****************************************************************************
#define MSG_DEBUG 0x01 //!< DEBUG宏打印
#define MSG_INFO 0x02  //!< INFO宏打印
#define MSG_ERROR 0x04 //!< ERROR宏打印

//static int printLevel = MSG_DEBUG | MSG_INFO | MSG_ERROR;
static int printLevel = MSG_ERROR;
//**************************************************
//
//! @brief 打印函数
//
//**************************************************
#define ctiot_lprintf(level, format, argv...)                                       \
    do                                                                              \
    {                                                                               \
        if (level & printLevel)                                                     \
            printf("[%s][%s(%d)]:" format, #level, __FUNCTION__, __LINE__, ##argv); \
    } while (0)

//*****************************************************************************
//! @}
//*****************************************************************************

#define HTTP_OK 200        //!< HTTP状态码:200 OK
#define HTTP_REDIRECT 302  //!< HTTP状态码:302 Move temporarily
#define HTTP_NOT_FOUND 404 //!< HTTP状态码:404 Not Found
#define HTTP_RANKS 206     //!< HTTP状态码:206 Partial Content
#define HTTP_RANGE_NOT_SATISFIABLE 416  //!< HTTP状态码:416 Requested Range not satisfiable

//**************************************************
//
//! @brief 从str中找出第一个sub字符串出现的位置截取str，并返截取后的str
//
//**************************************************
char *ctiot_get_substr_index(char *str, char *sub);

//**************************************************
//
//! @brief 解析url，将域名、端口等区分开存入结构体中
//
//**************************************************
int ctiot_parser_url(char *url, char *hostName, char *uri, int *port);

//**************************************************
//
//! @brief dns解析,返回解析到的第一个地址，失败返回-1，成功则返回相应地址
//
//**************************************************
unsigned long ctiot_dns(char *hostName);

//**************************************************
//
//! @brief 设置发送接收超时等socket参数
//
//**************************************************
int ctiot_set_socket_option(int sock);

//**************************************************
//
//! @brief 连接到服务器
//
//**************************************************
int ctiot_connect_server_by_tcp(http_t *info);

//**************************************************
//
//! @brief 发送http request
//
//**************************************************
int ctiot_send_http_request(http_t *info);

//**************************************************
//
//! @brief 解析http报文的header部分
//
//**************************************************
int ctiot_parse_http_header(http_t *info);

//**************************************************
//
//! @brief 保存服务器响应的内容
//
//**************************************************
int ctiot_save_data(http_t *info, const char *buf, int len);

//**************************************************
//
//! @brief 读取数据
//
//**************************************************
int ctiot_read_data(http_t *info, int len);

//**************************************************
//
//! @brief 接受服务器发来的数据
//
//**************************************************
int ctiot_recv_response(http_t *info);

//**************************************************
//
//! @brief 接收服务器发回的chunked数据
//
//**************************************************
int ctiot_recv_chunked_response(http_t *info);

//**************************************************
//
//! @brief 计算平均下载速度，单位byte/s
//
//**************************************************
float ctiot_calc_download_speed(http_t *info);

//**************************************************
//
//! @brief 资源清理
//
//**************************************************
void ctiot_clean_up(http_t *info);

//**************************************************
//
//! @brief 初始化http_t结构体
//
//**************************************************
int ctiot_init_http_t_by_addr(char *uri, int port, char *savePath, unsigned long addr, http_t **info, char * token);

int ctiot_init_http_t_by_hostname(char *hostName, char *uri, int port, char *savePath, http_t **info, char * token);

//**************************************************
//
//! @brief 组装并发送post请求
//
//**************************************************
int ctiot_send_http_post(http_t *info);

//**************************************************
//
//! @brief 校验返回http头，查询文件上传结果
//
//**************************************************
int ctiot_check_http_header(http_t *info);

//**************************************************
//
//! @brief 计算文件的md5
//
//**************************************************
int ctiot_file_md5(http_t *info);

//**************************************************
//
//! @brief 获取下载状态
//
//**************************************************
int ctiot_get_httpdownload_status();

//**************************************************
//
//! @brief 获取md5
//
//**************************************************
char* ctiot_get_md5();

//**************************************************
//
//! @brief 获取剩余长度
//
//**************************************************
int ctiot_get_rest_lenth();

//**************************************************
//
//! @brief 下载主函数
//
//**************************************************
int ctiot_http_download(char *url, char *savePath, int type);

//**************************************************
//
//! @brief 释放socket链接
//
//**************************************************
void ctiot_network_disconnect(http_t *info);