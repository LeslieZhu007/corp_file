/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include "ctiot_http.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>
#include <netdb.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include "ctiot_md5.h"

#ifdef HTTP_OPENSSL
#define HTTP_CA_CERT_FILE "./https/ca.crt"
#define HTTP_CLIENT_CERT_FILE "./https/client.crt"
#define HTTP_CLIENT_KEY_FILE "./https/client.key"
#endif
#ifdef HTTP_MBEDTLS
#define ca_crt "./https/ca.crt"
#define client_crt "./https/client.crt"
#define client_key "./https/client.key"
#endif

int recvDataLen = 0;                     //!< 接受的长度
unsigned char http_md5[16] = {0};           //!< 32为md5码
bool finish = 0;                     //!< 文件下载完成标志位
int http_mode = 1;          //!< 1使用http协议,2使用https协议

//**************************************************
//
//! @brief 取值宏，取两个值中的较小值
//
//**************************************************
#define MIN(x, y) ((x) > (y) ? (y) : (x))

//**************************************************
//
//! @brief 从str中找出第一个sub字符串出现的位置截取str，并返截取后的str
//
//**************************************************
char *ctiot_get_substr_index(char *str, char *sub)
{
    if(!str || !sub)
        return NULL;
    int len = strlen(sub);
    if (len == 0)
    {
        return NULL;
    }
    while (*str)
    {
        if (strncasecmp(str, sub, len) == 0)
        {
            return str;
        }
        ++str;
    }
    return NULL;
}

#if defined(HTTP_OPENSSL) || defined(HTTP_MBEDTLS)
//**************************************************
//
//! @brief https获取一行的方法
//
//**************************************************
int ctiot_https_gets(char * buffer, int len, http_t* info){
        int i = 0;
        char key;
        while(i<len){
        #if defined(HTTP_OPENSSL)
                SSL_read(info->ssl, &key, 1);
        #elif defined(HTTP_MBEDTLS)
                mbedtls_ssl_read(&(info->ssl), &key, 1);
        #endif
                buffer[i] = key;
                i++;
                if(key == '\n'||key == '\0'){
                        break;
                }    
        }
        buffer[i] = '\0';       
        return i;
}

static void my_debug(void *ctx, int level,
	const char *file, int line, const char *str)
{
	((void)level);
	fprintf((FILE *)ctx, "%s:%04d: %s", file, line, str);
	fflush((FILE *)ctx);
}
#endif

//**************************************************
//
//! @brief 解析url，将域名、端口等区分开存入结构体中
//
//**************************************************
int ctiot_parser_url(char *url,char* hostName,char* uri,int *port)
{
        char *tmp = url, *start = NULL, *end = NULL;
        int len = 0;

        if(ctiot_get_substr_index(tmp, "http://"))
        {   
                http_mode = 1;
                tmp += strlen("http://");
        }else if(ctiot_get_substr_index(tmp, "https://"))
        {
                http_mode = 2;
                tmp += strlen("https://");
        }
        start = tmp;

        if(http_mode == 1)
        {
                *port = 80;
        }
        else
        {
                *port = 443;
        }

        if(!(tmp = strchr(start, '/')))
        {
                ctiot_lprintf(MSG_ERROR, "url invaild\n");
                return -1;      
        }
        end = tmp;   

        len = MIN(end - start, HOST_NAME_LEN - 1);
        strncpy(hostName,start,len);
        hostName[len] = '\0';

        if((tmp = strchr(start, ':')) && tmp < end)
        {
                *port = atoi(tmp + 1);
                if(*port <= 0 || *port >= 65535)
                {
                        ctiot_lprintf(MSG_ERROR, "url port invaild\n");
                        return -1;
                }
                len = MIN(tmp - start, HOST_NAME_LEN - 1);
                strncpy(hostName, start, len);
                hostName[len] = '\0';
        }

        start = end;
        strncpy(uri, start, URI_MAX_LEN - 1);
        ctiot_lprintf(MSG_INFO, "parse url ok \n host:%s, port:%d, uri:%s\n", 
                        hostName, *port, uri);
        return 0;
}

//**************************************************
//
//! @brief dns解析,返回解析到的第一个地址，失败返回-1，成功则返回相应地址
//
//**************************************************
unsigned long ctiot_dns(char* hostName)
{

        //存储dns解析的主机的相关信息
        struct hostent* host;
        struct in_addr addr;
        char **pp;

        host = gethostbyname(hostName);
        if (host == NULL)
        {
                ctiot_lprintf(MSG_ERROR, "gethostbyname %s failed\n", hostName);
                return -1;
        }

        pp = host->h_addr_list;

        if (*pp!=NULL)
        {
                addr.s_addr = *((unsigned int *)*pp);
                ctiot_lprintf(MSG_INFO, "%s address is %s\n", hostName, inet_ntoa(addr));
                pp++;
                return addr.s_addr;
        }
        return -1;
}

//**************************************************
//
//! @brief 设置发送接收超时等socket参数
//
//**************************************************
int ctiot_set_socket_option(int sock)
{
        struct timeval timeout;

        timeout.tv_sec = RCV_SND_TIMEOUT/1000;
        timeout.tv_usec = RCV_SND_TIMEOUT%1000*1000;
        ctiot_lprintf(MSG_DEBUG, "%ds %dus\n", (int)timeout.tv_sec, (int)timeout.tv_usec);
        if(-1 == setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, 
                                sizeof(struct timeval)))
        {
                ctiot_lprintf(MSG_ERROR, "setsockopt error: %m\n");
                return -1;
        }
        return 0;
}

//**************************************************
//
//! @brief 连接到服务器
//
//**************************************************
int ctiot_connect_server_by_tcp(http_t *info)
{
        int sockfd;
        struct sockaddr_in server;
        unsigned long addr = 0;
        unsigned short port = info->port;
        int rc = 0;

#if defined(HTTP_OPENSSL)
	SSL_library_init();
	OpenSSL_add_all_algorithms(); 
	SSL_load_error_strings(); 

	info->ctx = SSL_CTX_new(SSLv23_client_method()); 
	if (info->ctx == NULL) {  
        printf("SSL_CTX_new fail!\n");
		return -1;
	}
	// 要求校验对方证书，表示需要验证服务器端，若不需要验证则使用  SSL_VERIFY_NONE
	
	#if !(defined(HTTP_SSL_CERTIFICATE_MONO) || defined(HTTP_SSL_CERTIFICATE_DUAL))
	SSL_CTX_set_verify(info->ctx, SSL_VERIFY_NONE, NULL);
	#else
        SSL_CTX_set_verify(info->ctx, SSL_VERIFY_PEER, NULL);
	// 加载CA的证书
	//printf("SSL_CTX_load_verify_locations start!\n");
        if(!SSL_CTX_load_verify_locations(info->ctx, HTTP_CA_CERT_FILE, NULL))
        {
                //printf("SSL_CTX_load_verify_locations error!\n");
                return -1;
        }
	#endif
        //SSL_CTX_set_verify(info->ctx, SSL_VERIFY_NONE, NULL);

	#if  defined(HTTP_SSL_CERTIFICATE_DUAL)
        // 加载自己的证书
        //printf("SSL_CTX_use_certificate_file start!\n");
        if(SSL_CTX_use_certificate_file(info->ctx, HTTP_CLIENT_CERT_FILE, SSL_FILETYPE_PEM) <= 0)
        {
                //printf("SSL_CTX_use_certificate_file error!\n");
                return -1;
        }
	//// 加载自己的私钥 加载私钥需要密码，意思是每次链接服务器都需要密码
        //若服务器需要验证客户端的身份，则需要客户端加载私钥，由于此处我们只需要验证服务器身份，故无需加载自己的私钥
        //printf("SSL_CTX_use_PrivateKey_file start!\n");
	if(SSL_CTX_use_PrivateKey_file(info->ctx, HTTP_CLIENT_KEY_FILE, SSL_FILETYPE_PEM) <= 0)
        {
                //printf("SSL_CTX_use_PrivateKey_file error!\n");
                return -1;
        }
    
        //// 判定私钥是否正确
        //printf("SSL_CTX_check_private_key start!\n");
        if(!SSL_CTX_check_private_key(info->ctx))
        {
                //printf("SSL_CTX_check_private_key error!\n");
                return -1;
        }
        #endif
#endif

#ifdef HTTP_MBEDTLS
        if(http_mode == 2)
        {
                mbedtls_net_init(&(info->fd));
                mbedtls_ssl_init(&(info->ssl));
                mbedtls_ssl_config_init(&(info->conf));
                mbedtls_x509_crt_init(&(info->cacertc));
                mbedtls_ctr_drbg_init(&(info->ctr_drbg));
                mbedtls_entropy_init(&(info->entropy));

                int len;
                const char *pers = "emq_ssl_client";
                printf("\n  . Seeding the random number generator...\n");
                //mbedtls_printf("[ca_crt:%d][client_crt:%d][client_key:%d]\n" , strlen(ca_crt) , strlen(client_crt) , strlen(client_key));
                fflush(stdout);
                if((rc = mbedtls_ctr_drbg_seed(&(info->ctr_drbg), mbedtls_entropy_func, &(info->entropy),
                                                                (const unsigned char *) pers,
                                                                strlen(pers))) != 0)
                {
                        printf("\n failed	! mbedtls_ctr_drbg_seed returned %d\n", rc);
                        goto failed;
                }

                printf(" mbedtls_ctr_drbg_seed ok\n");	
                #if defined(HTTP_SSL_CERTIFICATE_DUAL) || defined(HTTP_SSL_CERTIFICATE_MONO)				   
                printf("  . Loading the CA root certificate ...\n");
                fflush(stdout);

                if(ca_crt != NULL)
                {
                                #if defined(MBEDTLS_FS_IO)
                                        if( strlen( ca_crt ) )
                                                if( strcmp( ca_crt, "none" ) == 0 )
                                                        rc = 0;
                                                else
                                                        rc = mbedtls_x509_crt_parse_file( &(info->cacertc), ca_crt );
                                #endif
                                #if defined(MBEDTLS_CERTS_C)
                        if ((rc = mbedtls_x509_crt_parse(&(info->cacertc), (const unsigned char *) ca_crt, strlen(ca_crt) + 1)) != 0)
                        {
                        printf(" failed\n  !  mbedtls_x509_crt_parse returned -0x%x\n\n", -rc);
                        goto failed;
                        }
                                #endif
                }

                printf(" mbedtls_x509_crt_parse ok (%d skipped)\n", rc);
                #endif
                #if defined(HTTP_SSL_CERTIFICATE_DUAL)
                if (client_crt != NULL && client_key != NULL) {
                #if defined(MBEDTLS_FS_IO)
                                if( strlen( client_crt ) )
                                                if( strcmp( client_crt, "none" ) == 0 )
                                                        rc = 0;
                                                else
                                                        rc = mbedtls_x509_crt_parse_file(&(info->clicert), client_crt );
                #endif
                #if defined(MBEDTLS_CERTS_C)
                        printf(" start prepare client cert .\n");
                        rc = mbedtls_x509_crt_parse(&(info->clicert), (const unsigned char *) client_crt, strlen(client_crt) + 1);
                #endif
                if (rc != 0) {
                        printf(" failed!  mbedtls_x509_crt_parse returned -0x%x\n\n", -rc);
                        return rc;
                }
                #if defined(MBEDTLS_FS_IO)
                        if( strlen( client_key ) )
                                if( strcmp( client_key, "none" ) == 0 )
                                        rc = 0;
                                else
                                        rc = mbedtls_pk_parse_keyfile( &(info->pkey), client_key, "" );
                #endif
                #if defined(MBEDTLS_CERTS_C)
                        printf("start mbedtls_pk_parse_key[%s]", NULL);
                        rc = mbedtls_pk_parse_key(&(info->pkey),
                                                        (const unsigned char *) client_key, strlen(client_key) + 1,
                                                        NULL, NULL);
                #endif

                if (rc != 0) {
                        printf(" failed\n  !  mbedtls_pk_parse_key returned -0x%x\n\n", -rc);
                        return rc;
                }
                }
                #endif
        }

#endif

        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (-1 == sockfd)
        {
                ctiot_lprintf(MSG_ERROR, "socket create failed\n");
                goto failed;
        }
        if(-1 == ctiot_set_socket_option(sockfd))
        {
                goto failed;
        }
        memset(&server, 0, sizeof(server));
        server.sin_family = AF_INET; 
        server.sin_port = htons(port); 
        server.sin_addr.s_addr = info->addr;
        if (-1 == connect(sockfd, (struct sockaddr *)&server, sizeof(struct sockaddr)))
        {
                ctiot_lprintf(MSG_ERROR, "connect failed: %m\n");
                goto failed;
        }
        info->sock = sockfd;

#ifdef HTTP_OPENSSL
        if(rc == 0)
    	{
                info->ssl = SSL_new(info->ctx);  
                SSL_set_fd(info->ssl, info->sock);  
          	if (SSL_connect(info->ssl) == -1) { 
                        ctiot_lprintf(MSG_ERROR, "SSL_connect fail!\n");
        		//ERR_print_errors_fp(stderr);  
        		goto failed;
        	} else {  
        		printf("加密连接,算法:%s\n", SSL_get_cipher(info->ssl));  
        	}
    	}  
#endif

#ifdef HTTP_MBEDTLS
        if(http_mode == 2)
        {
                printf(" Setting up the SSL/TLS structure...\n");
                fflush(stdout);
                info->fd.fd = info->sock;
                        if((rc = mbedtls_ssl_config_defaults(&(info->conf),
                        MBEDTLS_SSL_IS_CLIENT,
                        MBEDTLS_SSL_TRANSPORT_STREAM,
                        MBEDTLS_SSL_PRESET_DEFAULT))!= 0)
                {
                printf(" failed\n  ! mbedtls_ssl_config_defaults returned %d\n\n", rc);
                goto failed;
                }

                printf("Setting up the SSL/TLS structure ok\n");

                mbedtls_ssl_conf_authmode(&(info->conf), MBEDTLS_SSL_VERIFY_NONE);

                        mbedtls_ssl_conf_rng(&(info->conf), mbedtls_ctr_drbg_random, &(info->ctr_drbg));
                mbedtls_ssl_conf_dbg(&(info->conf), my_debug, stdout);

                #if defined(MBEDTLS_X509_CRT_PARSE_C)
                mbedtls_ssl_conf_ca_chain(&(info->conf), &(info->cacertc), NULL);

                if ((rc = mbedtls_ssl_conf_own_cert(&(info->conf), &(info->clicert), &(info->pkey))) != 0) {
                printf(" failed\n  ! mbedtls_ssl_conf_own_cert returned %d\n\n", rc);
                return rc;
                }
                #endif

                if((rc = mbedtls_ssl_setup(&(info->ssl), &(info->conf))) != 0)
                {
                printf(" failed\n  ! mbedtls_ssl_setup returned %d\n\n", rc);
                goto failed;
                }

                if((rc = mbedtls_ssl_set_hostname(&(info->ssl), NULL)) != 0)
                {
                printf(" failed\n  ! mbedtls_ssl_set_hostname returned %d\n\n", rc);
                goto failed;
                }

                mbedtls_ssl_set_bio(&(info->ssl), &(info->fd), mbedtls_net_send, mbedtls_net_recv, NULL);

                printf("  . Performing the SSL/TLS handshake...\n");
                fflush(stdout);

                while((rc = mbedtls_ssl_handshake(&(info->ssl))) != 0)
                {
                if(rc != MBEDTLS_ERR_SSL_WANT_READ && rc != MBEDTLS_ERR_SSL_WANT_WRITE)
                {
                        printf(" failed\n  ! mbedtls_ssl_handshake returned -0x%x\n\n", -rc);
                        goto failed;
                }
                }

                printf("Performing the SSL/TLS handshake ok\n");
                info->sock = (int)((info->fd).fd);

                if (rc != 0) {
                        printf("connect fail\n");
                        goto failed;
                }
        }      
#endif
        return 0;
failed:
        if(sockfd != -1)
                close(sockfd);
        return -1;
}

//**************************************************
//
//! @brief 发送http request
//
//**************************************************
int ctiot_send_http_request(http_t *info)
{
        int len;
        unsigned long filesize = 0; 
        struct stat statbuff;
        memset(info->buffer, 0x0, RECV_BUF);       
        if(stat(info->savePath, &statbuff) < 0){

        }else{
            filesize = statbuff.st_size;
        }
        snprintf(info->buffer  , RECV_BUF - 1, "GET %s HTTP/1.1\r\n"
                    "Range:bytes=%ld-\r\n"  
                    "Accept: */*\r\n"
                    "User-Agent: Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)\r\n"
                    "Host: %s\r\n"
                    "Connection: Close\r\n\r\n", info->uri,filesize, info->hostName);
#ifdef HTTP_OPENSSL
	return SSL_write(info->ssl, info->buffer, strlen(info->buffer));
#elif defined(HTTP_MBEDTLS)
        if(http_mode == 2)
        {
                return mbedtls_ssl_write(&(info->ssl), info->buffer,strlen(info->buffer));
        }
        else if(http_mode == 1)
        {
                return write(info->sock, info->buffer, strlen(info->buffer));
        }       
#else
	return write(info->sock, info->buffer, strlen(info->buffer));
#endif
}

//**************************************************
//
//! @brief 解析http报文的header部分
//
//**************************************************
int ctiot_parse_http_header(http_t *info)
{
        char *p = NULL;
#if defined(HTTP_OPENSSL) || defined(HTTP_MBEDTLS)
        if(http_mode == 2)
        {
                ctiot_https_gets(info->buffer,RECV_BUF,info);
        }
        else if(http_mode == 1)
        {
                fgets(info->buffer, RECV_BUF, info->in);
        }
#else
        fgets(info->buffer, RECV_BUF, info->in);
#endif
       p = strchr(info->buffer, ' ');
        if(!p || !strcasestr(info->buffer, "HTTP"))
        {
                ctiot_lprintf(MSG_ERROR, "bad http head\n");
                return -1;
        }
        info->statusCode = atoi(p + 1);   
        ctiot_lprintf(MSG_DEBUG, "http status code: %d\n", info->statusCode);

        unsigned long long fl = 0;
#if defined(HTTP_OPENSSL) || defined(HTTP_MBEDTLS)
        if(http_mode == 2)
        {
                fl = ctiot_https_gets(info->buffer,RECV_BUF,info);
        }
        else if(http_mode == 1)
        {
                fl = (unsigned long long)fgets(info->buffer, RECV_BUF, info->in);  
        }
        while(fl){
#else   
        fl = (unsigned long long)fgets(info->buffer, RECV_BUF, info->in)>>0;
        while(fl){
#endif
                if(!strcmp(info->buffer, "\r\n"))
                {
                        return 0;  
                }
                ctiot_lprintf(MSG_DEBUG, "%s", info->buffer);
                if(p = ctiot_get_substr_index(info->buffer, "Content-length"))
                {
                        p = strchr(p, ':');
                        p += 2;  
                        info->len = atoi(p);
                        ctiot_lprintf(MSG_INFO, "Content-length: %d\n", info->len);
                }
                else if(p = ctiot_get_substr_index(info->buffer, "Transfer-Encoding"))
                {
                        if(ctiot_get_substr_index(info->buffer, "chunked"))
                        {
                                info->chunkedFlag = 1;
                        }
                        else
                        {
                                ctiot_lprintf(MSG_ERROR, "Not support %s", info->buffer);
                                return -1;
                        }
                        ctiot_lprintf(MSG_INFO, "%s", info->buffer);
                }
                else if(p = ctiot_get_substr_index(info->buffer, "Location"))
                {
                        p = strchr(p, ':');
                        p += 2;   
                        strncpy(info->location, p, URI_MAX_LEN - 1);
                        ctiot_lprintf(MSG_INFO, "Location: %s\n", info->location);
                }
                #if defined(HTTP_OPENSSL) || defined(HTTP_MBEDTLS)
                        if(http_mode == 2)
                        {
                                fl = ctiot_https_gets(info->buffer,RECV_BUF,info);
                        }
                        else if(http_mode == 1)
                        {
                                fl = (unsigned long long)fgets(info->buffer, RECV_BUF, info->in);   
                        }
                #else   
                        fl = (unsigned long long)fgets(info->buffer, RECV_BUF, info->in);
                #endif
        }
        ctiot_lprintf(MSG_ERROR, "bad http head\n");
        return -1;
}

//**************************************************
//
//! @brief 保存服务器响应的内容
//
//**************************************************
int ctiot_save_data(http_t *info, const char *buf, int len)
{
        int totalLen = len;
        int writeLen = 0;
        // 文件没有打开则先打开
        if(!info->saveFile)
        {
                info->saveFile = fopen(info->savePath, "a+");
                if(!info->saveFile)
                {
                        ctiot_lprintf(MSG_ERROR, "fopen %s error: %m\n", info->savePath);
                        return -1;
                }
        }
        while(totalLen)
        {
                writeLen = fwrite(buf, sizeof(char), len, info->saveFile);
                if(writeLen < len && errno != EINTR)
                {
                        ctiot_lprintf(MSG_ERROR, "fwrite error: %m\n");
                        return -1;
                }
                totalLen -= writeLen;
        }
}

//**************************************************
//
//! @brief 读取数据
//
//**************************************************
int ctiot_read_data(http_t *info, int len)
{
        int totalLen = len;
        int readLen = 0;
        int rtnLen = 0;

        static int count = 0;

        while(totalLen)
        {
                readLen = MIN(totalLen, RECV_BUF);
        #ifdef HTTP_OPENSSL
                rtnLen = SSL_read(info->ssl, info->buffer, readLen);
                if(rtnLen <= 0 ){
                        break;
                }
        #elif defined(HTTP_MBEDTLS)
                if(http_mode == 2)
                {
                        rtnLen = mbedtls_ssl_read(&(info->ssl), info->buffer, readLen);   
                        if(rtnLen <= 0 ){
                                break;
                        }  
                }
                else if(http_mode == 1)
                {
                        rtnLen = fread(info->buffer, sizeof(char), readLen, info->in);
                        if(rtnLen < readLen)
                        {
                                if(ferror(info->in))
                                {
                                        if(errno == EAGAIN || errno == EWOULDBLOCK) 
                                        {
                                                ctiot_lprintf(MSG_ERROR, "socket recvice timeout: %dms\n", RCV_SND_TIMEOUT);
                                                totalLen -= rtnLen;
                                                ctiot_lprintf(MSG_DEBUG, "read len: %d\n", rtnLen);
                                                break;
                                        }
                                        else   
                                        {
                                                ctiot_lprintf(MSG_ERROR, "fread error: %m\n");
                                                break;
                                        }
                                }
                                else   
                                {
                                        ctiot_lprintf(MSG_ERROR, "socket closed by peer\n");
                                        totalLen -= rtnLen;
                                        ctiot_lprintf(MSG_DEBUG, "read len: %d\n", rtnLen);
                                        break;
                                }
                        }                       
                }    
        #else
                rtnLen = fread(info->buffer, sizeof(char), readLen, info->in);
                if(rtnLen < readLen)
                {
                        if(ferror(info->in))
                        {
                                 if(errno == EAGAIN || errno == EWOULDBLOCK) 
                                {
                                        ctiot_lprintf(MSG_ERROR, "socket recvice timeout: %dms\n", RCV_SND_TIMEOUT);
                                        totalLen -= rtnLen;
                                        ctiot_lprintf(MSG_DEBUG, "read len: %d\n", rtnLen);
                                        break;
                                }
                                else   
                                {
                                        ctiot_lprintf(MSG_ERROR, "fread error: %m\n");
                                        break;
                                }
                        }
                        else   
                        {
                                ctiot_lprintf(MSG_ERROR, "socket closed by peer\n");
                                totalLen -= rtnLen;
                                ctiot_lprintf(MSG_DEBUG, "read len: %d\n", rtnLen);
                                break;
                        }
                }
        #endif
                totalLen -= rtnLen;
                ctiot_lprintf(MSG_DEBUG, "read len: %d\n", rtnLen);
                if(-1 == ctiot_save_data(info, info->buffer, rtnLen))
                {
                        return -1;
                }
                info->recvDataLen += rtnLen;
                recvDataLen = info->recvDataLen;
        }
        if(totalLen != 0)
        {
                ctiot_lprintf(MSG_ERROR, "we need to read %d bytes, but read %d bytes now\n", 
                                len, len - totalLen);
                return -1;
        }
}

//**************************************************
//
//! @brief 接收服务器发回的chunked数据
//
//**************************************************
int ctiot_recv_chunked_response(http_t *info)
{
        long partLen;
        do{
                // 获取这一个部分的长度
        #if defined(HTTP_OPENSSL) || defined(HTTP_MBEDTLS)
                if(http_mode == 2)
                {
                        ctiot_https_gets(info->buffer, RECV_BUF,info);
                }
                else if(http_mode == 1)
                {
                        fgets(info->buffer, RECV_BUF, info->in);   
                }
        #else
                fgets(info->buffer, RECV_BUF, info->in);
        #endif       
                partLen = strtol(info->buffer, NULL, 16);
                ctiot_lprintf(MSG_DEBUG, "part len: %ld\n", partLen);
                if(-1 == ctiot_read_data(info, partLen))
                        return -1;

                //读走后面的\r\n两个字符
        #ifdef HTTP_OPENSSL
                if(2 != SSL_read(info->ssl, info->buffer, 2)&& info->buffer[0] == '\r' && info->buffer[1] == '\n'){
                        ctiot_lprintf(MSG_ERROR, "SSL_read \\r\\n error : %m\n");
                        return -1;  
                }
        #elif defined(HTTP_MBEDTLS)
                if(http_mode == 2)
                {
                        if(2 != mbedtls_ssl_read(&(info->ssl), info->buffer,2) && info->buffer[0] == '\r' && info->buffer[1] == '\n')
                        {
                                ctiot_lprintf(MSG_ERROR, "Mbed_read \\r\\n error : %m\n");
                                return -1;  
                        }
                }
                else if(http_mode == 1)
                {
                        if(2 != fread(info->buffer, sizeof(char), 2, info->in)&& info->buffer[0] == '\r' && info->buffer[1] == '\n')
                        {
                                ctiot_lprintf(MSG_ERROR, "fread \\r\\n error : %m\n");
                                return -1;
                        }  
                }
        #else
                if(2 != fread(info->buffer, sizeof(char), 2, info->in)&& info->buffer[0] == '\r' && info->buffer[1] == '\n'){
                        ctiot_lprintf(MSG_ERROR, "fread \\r\\n error : %m\n");
                        return -1;
                }
        #endif
        }while(partLen);
        return 0;
}

//**************************************************
//
//! @brief 接受服务器发来的数据
//
//**************************************************
int ctiot_recv_response(http_t *info)
{
        int len = 0, totalLen = info->len;

        if(info->chunkedFlag)
                return ctiot_recv_chunked_response(info);

        if(-1 == ctiot_read_data(info, totalLen))
                return -1;
        return 0;
}

//**************************************************
//
//! @brief 计算平均下载速度，单位byte/s
//
//**************************************************
float ctiot_calc_download_speed(http_t *info)
{
        int diff_time = 0; 
        float speed = 0.0;
        diff_time = info->endRecvTime - info->startRecvTime;
        if(0 == diff_time)
                diff_time = 1;
        speed = (float)info->recvDataLen / diff_time;
        return  speed;
}

//**************************************************
//
//! @brief 资源清理
//
//**************************************************
void ctiot_clean_up(http_t *info)
{
        if(info->in)
                fclose(info->in);
        if(-1 != info->sock)
                ctiot_network_disconnect(info);
        if(info->saveFile)
                fclose(info->saveFile);
        if(info)
                free(info);
}

void ctiot_network_disconnect(http_t *info)
{
#ifdef HTTP_OPENSSL
	SSL_shutdown(info->ssl);  
	SSL_free(info->ssl);
#endif
	close(info->sock);
#ifdef HTTP_OPENSSL
	SSL_CTX_free(info->ctx);
#endif
#ifdef HTTP_MBEDTLS
        if(http_mode == 2)
        {
                mbedtls_ssl_close_notify(&(info->ssl));
                mbedtls_net_free(&(info->fd));
        #if defined(MBEDTLS_X509_CRT_PARSE_C)
                mbedtls_x509_crt_free( &(info->cacertc));
                if ((info->pkey).pk_info != NULL) 
                {
                        mbedtls_x509_crt_free( &(info->clicert));
                        mbedtls_pk_free( &(info->pkey) );
                }
        #endif
                mbedtls_ssl_free( &(info->ssl));
                mbedtls_ssl_config_free(&(info->conf));
                mbedtls_ctr_drbg_free( &(info->ctr_drbg) );
                mbedtls_entropy_free( &(info->entropy) );
        } 
#endif
}

//**************************************************
//
//! @brief 初始化http_t结构体
//
//**************************************************
int ctiot_init_http_t_by_hostname(char *hostName, char *uri, int port,char* savePath, http_t **info, char* token)
{
        recvDataLen = 0;
        memset(http_md5,0,16);
        finish = false;

        int len = 0;
        (*info) = malloc(sizeof(http_t));
        if(!(*info))
        {
                ctiot_lprintf(MSG_ERROR, "malloc failed\n");
                return -1;
        }
        memset((*info), 0x0, sizeof(http_t));
        (*info)->sock = -1;
        (*info)->savePath = savePath;
        
        len = MIN(HOST_NAME_LEN, strlen(hostName));
        strncpy((*info)->hostName, hostName, len);
        (*info)->hostName[len] = '\0';

        len = MIN(URI_MAX_LEN, strlen(uri));
        strncpy((*info)->uri, uri, len);
        (*info)->uri[len] = '\0';
        (*info)->port = port;
        (*info)->addr = ctiot_dns((*info)->hostName);
        return 0;
}

int ctiot_init_http_t_by_addr(char *uri, int port,char* savePath,unsigned long addr, http_t **info, char* token)
{
        recvDataLen = 0;
        memset(http_md5,0,16);
        finish = false;

        int len = 0;
        char * hostName = NULL;
        struct in_addr addrs;
        (*info) = malloc(sizeof(http_t));
        if(!(*info))
        {
                ctiot_lprintf(MSG_ERROR, "malloc failed\n");
                return -1;
        }
        memset((*info), 0x0, sizeof(http_t));
        (*info)->sock = -1;
        (*info)->savePath = savePath;

        len = MIN(URI_MAX_LEN, strlen(uri));
        strncpy((*info)->uri, uri, len);
        (*info)->uri[len] = '\0';
        (*info)->port = port;
        (*info)->addr = addr;

        addrs.s_addr = addr;
        hostName = inet_ntoa(addrs);
        len = MIN(HOST_NAME_LEN,strlen(hostName));
        strncpy((*info)->hostName, hostName, len);
        return 0;
}

//**************************************************
//
//! @brief 组装并发送post请求
//
//**************************************************
int ctiot_send_http_post(http_t *info)
{
    char post_begin_buf[POST_BUF_LEN] = {0};
    char post_end_buf[POST_BUF_LEN] = {0};
    char post_file_buf[POST_BUF_LEN] = {0};
  //  FILE *fp = NULL;
    long len = 0;
    unsigned long filesize = -1; 

    
    if (info == NULL)
        return -1;
    
    info->in = fopen(info->savePath, "rb+");  
    
    if(info->in == NULL)  
        return -1;  
 
    struct stat statbuff;  
    if(stat(info->savePath, &statbuff) < 0){  
             
    }else{  
        filesize = statbuff.st_size;  
    }  

    len = filesize;
                            
    snprintf(post_end_buf,POST_BUF_LEN-1,"------WebKitFormBoundaryKBxpuuwBi1oSgh9T\r\n"
                "Content-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n"
                "Content-Type: application/octet-stream\r\n\r\n\r\n"
                "------WebKitFormBoundaryKBxpuuwBi1oSgh9T--\r\n",info->savePath);          

    filesize += strlen(post_end_buf);

    snprintf(post_begin_buf,POST_BUF_LEN-1,"POST %s HTTP/1.1\r\nHost: %s:%d\r\n"
                "Connection: close\r\n"
                "Content-Length: %ld\r\n"
                "Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryKBxpuuwBi1oSgh9T\r\n\r\n"
                "------WebKitFormBoundaryKBxpuuwBi1oSgh9T\r\n"
                "Content-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n"
                "Content-Type: application/octet-stream\r\n\r\n",info->uri, info->hostName, info->port, filesize, info->savePath);

    ctiot_lprintf(MSG_DEBUG, "post_begin:\n%s\n", post_begin_buf); 
    memset(post_end_buf, 0 , sizeof(post_end_buf));
    sprintf(post_end_buf, "\r\n------WebKitFormBoundaryKBxpuuwBi1oSgh9T--\r\n");

    if(-1 == send(info->sock, post_begin_buf, strlen(post_begin_buf), 0))
        goto err;

    while(len > 0)
    {
        memset(info->buffer, 0, RECV_BUF);
        filesize = fread(info->buffer,sizeof(char),RECV_BUF, info->in);
        if(-1 == send(info->sock, info->buffer, filesize, 0))
            goto err;
        len -= filesize;
    }
    if(-1 == send(info->sock, post_end_buf, strlen(post_end_buf),0))
        goto err;

    fclose(info->in);  
    return 0;

err:
    fclose(info->in);
    return -1;
}

//**************************************************
//
//! @brief 校验返回http头，查询文件上传结果
//
//**************************************************
int ctiot_check_http_header(http_t *info)
{
    char *p = NULL;
    memset(info->buffer, 0, RECV_BUF);
    fgets(info->buffer, RECV_BUF, info->in);
    p = strchr(info->buffer, ' ');
    //简单检查http头第一行是否合法
    if(!p || !strcasestr(info->buffer, "HTTP"))
    {       
        ctiot_lprintf(MSG_ERROR, "bad http head\n");
        return -1;
    }  
    info->statusCode = atoi(p + 1);   
    ctiot_lprintf(MSG_DEBUG, "http status code: %d\n", info->statusCode);
    memset(info->buffer, 0, RECV_BUF);
    // 循环读取解析http头
    while(fgets(info->buffer, RECV_BUF, info->in))
    {       
        // 判断头部是否读完
        if(!strcmp(info->buffer, "\r\n"))
        {       
        //头部解析通过
            return 0;   
        }
        ctiot_lprintf(MSG_DEBUG, "%s", info->buffer);
        memset(info->buffer, 0, RECV_BUF);
    }
    ctiot_lprintf(MSG_ERROR, "bad http head\n");
    //头部解析出错
    return -1;  

}

//**************************************************
//
//! @brief 计算文件的md5
//
//**************************************************
int ctiot_file_md5(http_t *info){
    if(info->savePath == NULL){
        return -1;
    }
    struct stat st;
    MD5_CTX context;
    MD5Init(&context);
    int bytes = 0;
    int i = 0;
    
    if(-1 == stat(info->savePath, &st)){
            return -1;
    }

    FILE *fp = info->saveFile;
    char* data = NULL;
    int ret = 0;

    if(fp == NULL){
        return -1;
    }
    
    data = malloc(1024);
    if(!data){
        return -1;
    }    
    while ((bytes = fread (data, 1, 1024, fp)) != 0)  
    {  
        if(bytes == -1){
            return -1;
        }
        MD5Update (&context, data, bytes);  
    }  
    MD5Final(&context, http_md5);
    free(data);

    return 0;
}

//**************************************************
//
//! @brief 获取下载状态
//
//**************************************************
int ctiot_get_httpdownload_status(){
    return finish;
}

//**************************************************
//
//! @brief 获取md5
//
//**************************************************
char* ctiot_get_md5(){
    return http_md5;
}

//**************************************************
//
//! @brief 获取剩余长度
//
//**************************************************
int ctiot_get_recv_lenth(){
    return recvDataLen;
}

//**************************************************
//
//! @brief 下载主函数
//
//**************************************************
int ctiot_http_download(char *url, char *savePath, int type)
{
        http_t *info = NULL;
        char tmp[URI_MAX_LEN] = {0};
        char hostName[HOST_NAME_LEN] = {0};
        char uri[URI_MAX_LEN] = {0};
        int port = 0;
        unsigned long addr = 0;
        int ret = 0;

        if (!url || !savePath)
        {
                ret = OTHER_REASON;
                return -1;
        }

        //解析url
        if (-1 == ctiot_parser_url(url, hostName, uri, &port))
        {
                ret = OTHER_REASON;
                return -1;
        }

        if (type == 0)
        { /* IP地址形式 */
                //将IP地址转换为一个长整型
                addr = inet_addr(hostName);
                //初始化http_t结构体
                if (-1 == ctiot_init_http_t_by_addr(uri, port, savePath, addr, &info, NULL))
                {
                        ret = OTHER_REASON;
                        goto failed;
                }
        }
        else
        {       /* 域名形式 */
                //当使用域名对结构体初始化时，可以调用此接口，其会根据hostName解析出IP地址
                if (-1 == ctiot_init_http_t_by_hostname(hostName, uri, port, savePath, &info, NULL))
                {
                        ret = OTHER_REASON;
                        goto failed;
                }
        }

        //初始化socket句柄，设置socket参数，与服务端建立socket链接
        if (-1 == ctiot_connect_server_by_tcp(info)){
                ret = SOCK_CONNECT_FAIL; //scoket连接出错
                goto failed;
        }
                
        // 发送http请求报文
        if (-1 == ctiot_send_http_request(info)){
                ret = SOCK_CONNECT_FAIL; //scoket连接出错
                goto failed;
        }

        // 接收响应的头信息
        info->in = fdopen(info->sock, "r");
        if (!info->in)
        {
                ctiot_lprintf(MSG_ERROR, "fdopen error\n");
                ret = OTHER_REASON;  
                goto failed;
        }

        // 解析头部
        if (-1 == ctiot_parse_http_header(info)){
                ret = OTHER_REASON;
                goto failed;
        }

        //根据状态码进行操作
        switch (info->statusCode)
        {
        case HTTP_RANKS:
        case HTTP_OK:
                // 接收数据
                ctiot_lprintf(MSG_DEBUG, "recv data now\n");
                info->startRecvTime = time(0);
                if (-1 == ctiot_recv_response(info))
                {
                        ret = DOWNLOAD_FAIL; // 下载失败
                        goto failed;
                }
                info->endRecvTime = time(0);
                ctiot_lprintf(MSG_INFO, "recv %d bytes\n", info->recvDataLen);
                ctiot_lprintf(MSG_INFO, "Average download speed: %.2fKB/s\n",
                              ctiot_calc_download_speed(info) / 1000);
                break;
        case HTTP_REDIRECT:
                // 重启本函数
                ctiot_lprintf(MSG_INFO, "redirect: %s\n", info->location);
                strncpy(tmp, info->location, URI_MAX_LEN - 1);
                ctiot_clean_up(info);
                return ctiot_http_download(tmp, savePath, type);

        case HTTP_NOT_FOUND:
                // 退出
                ctiot_lprintf(MSG_ERROR, "Page not found\n");
                ret = URI_NOT_FOUND;
                goto failed;
                break;

        case HTTP_RANGE_NOT_SATISFIABLE:
                // range 参数范围不支持
                ctiot_lprintf(MSG_ERROR, "Requested Range not satisfiable\n");
                break;

        default:
                ctiot_lprintf(MSG_INFO, "Not supported http code %d\n", info->statusCode);
                ret = OTHER_REASON;
                goto failed;
        }
        finish = 1;
        if(info->saveFile == NULL){
                info->saveFile = fopen(info->savePath, "r");
                if(info->saveFile == NULL) {
                        ret = OTHER_REASON;
                        goto failed;
                }
        }
        rewind(info->saveFile);
        ctiot_file_md5(info);
        ctiot_clean_up(info);
        return DOWNLOAD_SUCCESS;
failed:
        finish = -1;
        ctiot_clean_up(info);
        return ret;
}
