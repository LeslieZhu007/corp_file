/**
 *
 * @file ctiot_tlink_client 终端客户端程序
 * 
 * @author 中国电信上海院AEP项目组
 * @version V2.5.2
 * @date 2018-02-26
 * @copyright 版权 中国电信上海院 2018-2023
 */

#ifndef __CTIOT_TLINK_CLIENT_H
#define __CTIOT_TLINK_CLIENT_H

#include "ctiot_basetype.h"
#include "MQTTPacket.h"
#include "MQTTClient.h"
#include "ctiot_tlink_config.h"

#define SDK_MAX_DEVICE_ID_LEN 32 /*refer to DID in REG CNF*/

#define SDK_RESULT_CODE_SUCC 0x0

typedef struct
{
    SDK_U32 nextMID;
} TLINK_CLIENT;

typedef enum
{
    RDAP_STATE_DETACHED,
    RDAP_STATE_INITIALIZED,
    RDAP_STATE_LOGOUTED,
    RDAP_STATE_LOGINED,
    RDAP_STATE_BEFORE_LOGIN,
    RDAP_STATE_ERROR,
} T_SDK_STATE;

//*****************************************************************************
//! @addtogroup 公用结构体
//! @{
//*****************************************************************************
typedef struct
{
    SDK_U8 identityMode;    //!< 必选,定长	终端身份标识模式
    SDK_U16 identityLength; //!< 必选,定长	终端身份标识长度
    SDK_U8 *identity;       //!< 必选,变长	终端身份标识
} CTIOT_MQTT_IDENTITY;      //!< 密码结构体

typedef struct
{
    SDK_U16 globalCommandTimeout;    /*ms*/
    SDK_U16 globalRreadSocketPeriod; /*ms*/
    SDK_U16 globalRegLoginDuration;  /*ms*/
    SDK_U16 globalMaxPduLenSent;     /*Byte*/
    SDK_U16 globalMaxPduLenRecv;     /*Byte*/
    char globalHostIP[20];
    SDK_U16 globalHostPort;
    SDK_U16 globalHbtLength;
    char *globalDeviceId;
    SDK_U64 globalPlatformTimestamp;
    char globalRedirectIP[20];
    CTIOT_STATUS globalLastError;
    SDK_U8 globalRunThread;
#ifdef CREATE_LOOP_IN_SDK
    pthread_t globalLoopTid;
#endif
    //CTIOT_INTERFACE callbacks;
} CTIOT_GLOBAL_INFO;     //!< SDK全局变量结构体


typedef struct
{
    SDK_U16 datasetID;    //!<必选,定长,数据集标识
    SDK_U16 payloadLen;   //!<必选,定长,结果（紧凑二进制串）长度
    SDK_U8 *payload;      //!<必选,定长,结果（紧凑二进制串）
} CTIOT_MQTT_COMPACT_ELE; //!< 普通的紧凑二进制模式报文结构体

typedef struct
{
    SDK_U16 datasetID;             //!<必选,定长,数据集标识
    SDK_U16 resultLen;             //!<必选,定长,结果说明数组长度
    SDK_U8 *result;                //!<必选,变长,结果说明数组
    SDK_U16 payloadLen;            //!<必选,定长,结果（紧凑二进制串）长度
    SDK_U8 *payload;               //!<必选,变长,结果（紧凑二进制串）
} CTIOT_MQTT_COMPACT_WITH_RLT_ELE; //!< 带查询结果说明的紧凑二进制格式报文结构体

typedef struct
{
    union {
        SDK_U16 datasetID; //!<必选,定长,数据集标识
        char *datasetName; //!<必选,变长,数据集名称
        SDK_U16 eventID;   //!<必选,定长,事件ID
    } u;
    char *payload;     //!<必选,变长,JSON数据内容
} CTIOT_MQTT_JSON_ELE; //!< 普通JSON模式报文结构体

//*****************************************************************************

//! @}
//*****************************************************************************

//*************************************************
//
//! @addtogroup 登录入参，报文，返回
//! @{
//
//*************************************************

typedef struct
{
    char *deviceNo;
    SDK_U8 networkType;
    char *softwareVersion;
    char *deviceType;
    CTIOT_MQTT_IDENTITY identity;
    SDK_U16 heartBeatLen;
    SDK_U64 timeStamp;
    char utcOffset[7];
} CTIOT_MQTT_LOGIN_REQ; //!< 登录请求的入参

typedef struct
{
    SDK_U64 platformTimeStamp;
    SDK_U16 heartBeatLen;
    char *redirectServerIP;
    SDK_U16 resultCode;
} CTIOT_MQTT_LOGIN_CNF; //!< 登录返回的报文

//*************************************************
//
//! @}
//
//*************************************************
typedef enum
{
    COMPACT_MODE,          //!<普通的紧凑二进制模式
    COMPACT_WITH_RLT_MODE, //!<带查询结果说明的紧凑二进制格式
    JSON_MODE,             //!<普通JSON模式
    FILE_MODE,             //!<文件类型
                           //  TEXT_STRING_MODE,           //!<文本串模式
    CUSTOM_FORMAT_MODE     //!<自定义模式
} CTIOT_MQTT_PAYLOAD_TYPE; //!<自定义文件模式

//*************************************************
//
//! @addtogroup 远程控制回调入参
//! @{
//
//*************************************************
typedef SDK_U16 CTIOT_MQTT_REMOTE_CTRL_TYPE; //!< 远程控制命令类型

#define CTRL_REBOOT 1         //!< 强制终端重启
#define CTRL_LOGOUT 2         //!< 强制终端退出AEP平台
#define CTRL_RE_LOGIN 3       //!< 强制终端重新登录AEP平台（先退出平台，再登录平台）
#define CTRL_SELF_CHECK 4     //!< 终端自检
#define CTRL_UPGRADE 5        //!< 通知终端软件升级
#define CTRL_START_DATA_TRX 6 //!< 开始发送数据
#define CTRL_STOP_DATA_TRX 7  //!< 停止发送数据
#define CTRL_FACTORY_REST 8   //!< Factory Rest

typedef struct
{
    SDK_U8 upgradeID;        //!< 必选，定长，目标软件序号 (0－预留，1－应用软件包 （含SDK）)
    SDK_U8 fileChecksum[16]; //!< 必选，定长，文件的MD5校验和
    SDK_U8 upgradeType;      //!< 必选，定长，升级模式 （0-全量升级 其它预留）
    char *upgradeVersion;    //!< 必选，变长，目标版本
    char *upgradeURL;        //!< 必选，变长，升级URL
    char *token;             //!< 必选，变长，如果采用UserName/Password模式，则Token需将两者合并为一个字符串，中间使用空格分开（UserName和Password不能使用空格）
} CTIOT_MQTT_UPGRADE_INFO;   //!< 远程控制程序升级信息

typedef struct
{
    SDK_U32 dmsn;                            //!< 必选，定长，终端管理操作序号
    CTIOT_MQTT_REMOTE_CTRL_TYPE controlType; //!< 参见@ref CTIOT_MQTT_REMOTE_CTRL_TYPE
    SDK_U8 *additionalInfo;                  //!< 可选，变长，控制附加信息
    SDK_U32 additionalInfoLen;
    CTIOT_MQTT_UPGRADE_INFO upgradeInfo; //!< 参见@ref CTIOT_MQTT_UPGRADE_INFO /*only present when Controltype is 6*/
} CTIOT_MQTT_REMOTE_CTRL_REQ;            //!< 远程控制回调函数的入参

//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 数据获取回调入参
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 gdsn;
    SDK_U8 payloadType;
    SDK_U16 datasetID;
} CTIOT_MQTT_RETRIEVE_DATA_REQ;

//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 数据获取回调入参
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 upSmallFileSN;
    SDK_U8 resultCode;
} CTIOT_TLINK_FILE_UPLOAD_REQ;

//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 云端指令下发和终端指令回应，非指定
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 cmdSN;      //!< 指令下发操作序列号
    SDK_U8 payloadType; //!< 数据表示模式 0:普通的紧凑二进制模式;2:普通JSON模式
    union {
        CTIOT_MQTT_COMPACT_ELE compact; //!< 参见@ref CTIOT_MQTT_COMPACT_ELE
        CTIOT_MQTT_JSON_ELE json;       //!< 参见@ref CTIOT_MQTT_JSON_ELE
    } u;
} CTIOT_MQTT_EXECUTE_CMD_REQUEST; //!< 云端指令下发

typedef struct
{
    SDK_U8 qos;
    SDK_U32 cmdSN;      //!< 与指令下发操作中的指令下发操作序列号一致
    SDK_U8 resultCode;  //!< 0 执行成功1 执行失败2 无效数据集类型3 无效数据集标识（终端无法识别的DatasetID）
    SDK_U8 payloadType; //!< 结果通知字段类型 0:普通紧凑二进制模式 2:普通JSON模式
    union {
        CTIOT_MQTT_COMPACT_ELE compact; //!< 参见@ref CTIOT_MQTT_COMPACT_ELE
        CTIOT_MQTT_JSON_ELE json;       //!< 参见@ref CTIOT_MQTT_JSON_ELE
    } u;
} CTIOT_MQTT_EXECUTE_CMD_CNF; //!< 终端指令回应
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 透明传输下发报文入参
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 dnTpDataSN; //!< 透明数据下行报文序列号
    SDK_U16 length;     //!< 下发数据长度
    SDK_U8 *payload;    //!< 下发数据
} CTIOT_MQTT_DL_TRANSPARENT_DATA_RECV;
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 透明传输终端上行报文入参
//! @{
//
//*************************************************
typedef struct
{
    SDK_U8 qos;                        //!< 0（尽力传送）或1（至少一次）都支持
    SDK_U32 upTpDataSN;                //!< 透明数据上行报文序列号
    SDK_U16 payloadLen;                //!< 上报数据长度
    SDK_U8 *payload;                   //!< 上报数据内容
} CTIOT_MQTT_TRANSPARENT_DATA_REQUEST; //!< 透明传输上行报文入参
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 参数获取下行参数
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 dmsn;
    SDK_U8 payloadType;
    union {
        SDK_U16 datasetID;
        //char* datasetName;
        char *content;
    } u;
} CTIOT_MQTT_PARA_ENQUIRE_REQ;
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 参数配置下行参数
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 dmsn;
    SDK_U8 payloadType;
    union {
        CTIOT_MQTT_COMPACT_ELE compact;
        CTIOT_MQTT_JSON_ELE json;
        char *payload;
    } u;
} CTIOT_MQTT_SET_PARA_REQ;
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 参数配置上行参数
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 qos;
    SDK_U32 dmsn;
    SDK_U8 resultCode;
    SDK_U8 payloadType;
    union {
        CTIOT_MQTT_COMPACT_ELE compact; /*payload is result*/
        CTIOT_MQTT_JSON_ELE json;
        //T_SDK_FILE_ELE file;
    } u;
} CTIOT_MQTT_SET_PARA_CNF;
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 参数查询上行参数
//! @{
//
//*************************************************
typedef struct
{
    SDK_U8 qos;
    SDK_U32 dmsn;
    SDK_U8 resultCode;
    SDK_U8 payloadType;
    union {
        union {
            CTIOT_MQTT_COMPACT_ELE compact;
            CTIOT_MQTT_COMPACT_WITH_RLT_ELE compactWithRslt;
            CTIOT_MQTT_JSON_ELE json;
            //T_SDK_FILE_ELE file;
        } succ; /*present if ResultCode == succ*/
        union {
            //T_SDK_COMPACT_ELE compact; /*payload is result*/
            //T_SDK_COMPACT_WITH_RLT_ELE compactWithRslt;
            CTIOT_MQTT_JSON_ELE json;
            //T_SDK_FILE_ELE file;
        } invalidData; /*present if ResultCode != succ*/
    } u;
} CTIOT_MQTT_ENQUIRE_PARA_CNF;
//*************************************************
//
//! @}
//
//*************************************************

//**************************************************
//
//! @brief  透明传输回调
//!
//! @param CTIOT_MQTT_DL_TRANSPARENT_DATA_RECV*，透明传输下行参数，见@ref CTIOT_MQTT_DL_TRANSPARENT_DATA_RECV
//!
//! @retval  无
//! @note   用户自定义，根据服务器发的透明传输命令进行相应处理
//
//**************************************************
typedef void (*CTIOT_MQTT_DOWNLINK_TRANSPARENT_DATA_RECV_API)(CTIOT_MQTT_DL_TRANSPARENT_DATA_RECV *);
//**************************************************
//
//! @brief  数据获取回调
//!
//! @param CTIOT_MQTT_RETRIEVE_DATA_REQ*，远程控制回调入参，见@ref CTIOT_MQTT_RETRIEVE_DATA_REQ
//!
//! @retval  无
//! @note   用户自定义，根据服务器下发的数据获取消息进行相应处理
//
//**************************************************
typedef void (*CTIOT_MQTT_RETRIEVE_DATA_REQ_API)(CTIOT_MQTT_RETRIEVE_DATA_REQ *);
//**************************************************
//
//! @brief  指令下发回调
//!
//! @param CTIOT_MQTT_EXECUTE_CMD_REQUEST*，指令下发回调入参，见@ref CTIOT_MQTT_EXECUTE_CMD_REQUEST
//!
//! @retval  无
//! @note   用户自定义，根据服务器下发的指令消息进行相应处理
//
//**************************************************
typedef void (*CTIOT_MQTT_EXECUTE_CMD_REQ_API)(CTIOT_MQTT_EXECUTE_CMD_REQUEST *);
//**************************************************
//
//! @brief  参数查询回调
//!
//! @param CTIOT_MQTT_PARA_ENQUIRE_REQ*，参数查询回调入参，见@ref CTIOT_MQTT_PARA_ENQUIRE_REQ
//!
//! @retval  无
//! @note   用户自定义，根据服务器下发的参数查询消息进行相应处理
//
//**************************************************
typedef void (*CTIOT_MQTT_PARA_ENQUIRE_REQ_API)(CTIOT_MQTT_PARA_ENQUIRE_REQ *);
//**************************************************
//
//! @brief  参数配置回调
//!
//! @param CTIOT_MQTT_SET_PARA_REQ*，参数配置回调入参，见@ref CTIOT_MQTT_SET_PARA_REQ
//!
//! @retval  无
//! @note   用户自定义，根据服务器下发的参数配置消息进行相应处理
//
//**************************************************
typedef void (*CTIOT_MQTT_SET_PARA_REQ_API)(CTIOT_MQTT_SET_PARA_REQ *);
//**************************************************
//
//! @brief  远程控制回调
//!
//! @param CTIOT_MQTT_REMOTE_CTRL_REQ*，远程控制回调入参，见@ref CTIOT_MQTT_REMOTE_CTRL_REQ
//!
//! @retval  无
//! @note   用户自定义，根据服务器发的远程控制命令进行相应处理
//
//**************************************************
typedef void (*CTIOT_MQTT_REMOTE_CTRL_REQ_API)(CTIOT_MQTT_REMOTE_CTRL_REQ *);
//**************************************************
//
//! @brief  设备断连回调
//!
//! @retval  无
//! @note   用户自定义，根据设备的连接状态进行相应处理
//
//**************************************************
typedef void (*CTIOT_MQTT_LOST_CONNECTION_IND_API)(CTIOT_STATUS);
//**************************************************
//
//! @brief  QoS=1、QoS=2情况下上行消息状态回调
//!
//! @param SDK_U32，msgId
//! @param SDK_U8，消息状态
//!
//! @retval  无
//! @note   用户自定义，根据服务器发的远程控制命令进行相应处理
//
//**************************************************
typedef void (*CTIOT_TLINK_MSG_STATUS_API)(SDK_U32, SDK_U8);
//**************************************************
//
//! @brief  小文件上传回调
//!
//! @param CTIOT_TLINK_FILE_UPLOAD_REQ*，小文件上传下行入参，见@ref CTIOT_TLINK_FILE_UPLOAD_REQ
//!
//! @retval  无
//! @note   用户自定义，根据服务器下发的小文件上传反馈信息进行相应处理
//
//**************************************************
typedef void (*CTIOT_TLINK_FILE_UPLOAD_API)(CTIOT_TLINK_FILE_UPLOAD_REQ *);
//*************************************************
//
//! @addtogroup 系统初始化参数
//! @{
//
//*************************************************
typedef struct
{
    char *hostIp;     //!< 必选,MQTT服务器地址
    SDK_U16 hostPort; //!< 必选,MQTT服务器服务端口

    SDK_U16 commandTimeout;    //!< 可选,报文往返最长时间
    SDK_U16 readSocketPeriod;  //!< 可选,轮询所需接收报文单次等待时间
    SDK_U16 regLoginDuration;  //!< 可选,登录和注册函数后的等待云端下发应答报文的超时时间
    SDK_U16 maxPayloadLenSent; //!< 可选,MQTT报文最大长度发送
    SDK_U16 maxPayloadLenRecv; //!< 可选,MQTT报文最大长度接收
    SDK_U16 maxQueueLen;       //!< 可选,最大队列长度
    SDK_U8 maxProcessMessageNum;//!< 可选, 单次处理消息数目
    SDK_U8 pingTimes;          //!< 可选,心跳包文重发次数
    SDK_U8 QOSMaxRetrans;      //!< 可选,QOS1最大重传次数
    SDK_U32 QOSMsgRetransTimeout;//!< 可选,QOS1报文ACK超时时间
    SDK_U8 ifAutoReconnect;    //!< 可选,是否重连
    SDK_U32 connectMode;       //!< 网络连接模式

    /*Part2*below is call back for Dl events****/
    CTIOT_MQTT_DOWNLINK_TRANSPARENT_DATA_RECV_API downlinkTransparentDataCallback; //!< 可选,透明传输回调函数
    CTIOT_MQTT_EXECUTE_CMD_REQ_API executeCmdCallback;                             //!< 可选,指令下发回调函数
    CTIOT_MQTT_RETRIEVE_DATA_REQ_API retrieveDataCallback;
    CTIOT_MQTT_PARA_ENQUIRE_REQ_API paraEnquireCallback;
    CTIOT_MQTT_SET_PARA_REQ_API setParaCallback;
    CTIOT_MQTT_REMOTE_CTRL_REQ_API remoteControlCallback; //!< 可选,远程控制回调函数
    CTIOT_MQTT_LOST_CONNECTION_IND_API lostConnToServer;  //!< 可选,服务器断开连接回调函数
    CTIOT_TLINK_MSG_STATUS_API msgStatusCallback;
    CTIOT_TLINK_FILE_UPLOAD_API fileUploadCallback;
} CTIOT_MQTT_INIT_REQ;   //!< SDK初始化结构体
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 数据上报，报文
//! @{
//
//*************************************************
typedef struct
{
    SDK_U8 qos;
    SDK_U32 upDataSN;
    CTIOT_MQTT_PAYLOAD_TYPE payloadType;
    union {
        CTIOT_MQTT_COMPACT_ELE compact;
        CTIOT_MQTT_COMPACT_WITH_RLT_ELE compactWithRslt;
        CTIOT_MQTT_JSON_ELE json;
    } u;

} CTIOT_MQTT_DATA_REQ; //!< 数据上报请求的入参
//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 远程控制，接收报文
//! @{
//
//*************************************************
typedef struct
{
    SDK_U8 qos;
    SDK_U32 dmsn;
    SDK_U16 controlType;
    SDK_U8 resultCode;
    SDK_U16 additionalInfoLen;
    SDK_U8 *additionalInfo;   //!< 控制附加信息
} CTIOT_MQTT_REMOTE_CTRL_CNF; //!< 远程控制接收的报文
//*************************************************
//
//! @}
//
//*************************************************

//**************************************************
//
//! @brief  登录功能
//!
//! @param CTIOT_MQTT_LOGIN_REQ* ptrLoginReqPara,登录入参，见@ref CTIOT_MQTT_LOGIN_REQ
//! @param CTIOT_MQTT_LOGIN_CNF* pRegReq,必选
//! @retval  T_SDK_BOOL 成功0，失败1
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_login_request(CTIOT_MQTT_LOGIN_REQ *ptrLoginRequestPara, CTIOT_MQTT_LOGIN_CNF *ptrLoginCnf);

//**************************************************
//
//! @brief  登出功能
//!
//! @param 无
//!
//! @retval  T_SDK_BOOL 成功0，失败1
//! @note   提示，可选
//
//**************************************************
T_SDK_BOOL ctiot_logout_request(void);

#if defined(USE_CTIOT_SEND_DATA)
//**************************************************
//
//! @brief  数据上报功能
//!
//! @param CTIOT_MQTT_DATA_REQ* ptrDataRequest，数据上报入参，见@ref CTIOT_MQTT_DATA_REQ
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//!
//! @retval  T_SDK_BOOL 成功0，失败1
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_send_data_request(CTIOT_MQTT_DATA_REQ *ptrDataRequest, SDK_U32 *msgID);

//**************************************************
//
//! @brief  紧凑二进制数据上报功能
//!
//! @param CTIOT_MQTT_PAYLOAD_TYPE payloadType
//! @param SDK_U16 dataSetID
//! @param SDK_U16 payloadLen
//! @param SDK_U8* payload
//! @param SDK_U8 qos
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_send_compact_mode_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
                                          SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID);
CTIOT_STATUS ctiot_send_compact_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
                                          SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos,SDK_U32 updataSN, SDK_U32 *msgID);
//**************************************************
//
//! @brief  带结果反馈的紧凑二进制数据上报
//!
//! @param CTIOT_MQTT_PAYLOAD_TYPE payloadType
//! @param SDK_U16 dataSetID
//! @param SDK_U16 payloadLen
//! @param SDK_U8* payload
//! @param SDK_U16 resultLen
//! @param SDK_U8* result
//! @param SDK_U8 qos
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_send_compact_with_rlt_mode_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
                                                   SDK_U16 payloadLen, SDK_U8 *payload, SDK_U16 resultLen, SDK_U8 *result, SDK_U8 qos, SDK_U32 *msgID);
CTIOT_STATUS ctiot_send_compact_with_rlt_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
                                                   SDK_U16 payloadLen, SDK_U8 *payload, SDK_U16 resultLen, SDK_U8 *result, SDK_U8 qos,SDK_U32 upDataSN, SDK_U32 *msgID);
//**************************************************
//
//! @brief  json结构数据上报功能
//!
//! @param CTIOT_MQTT_PAYLOAD_TYPE payloadType
//! @param SDK_U16 dataSetID
//! @param SDK_U8* payload
//! @param SDK_U8 qos
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//!
//! @retval CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_send_json_mode_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID);

CTIOT_STATUS ctiot_send_json_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID, SDK_U8 *payload, SDK_U8 qos, SDK_U32 upDataSN, SDK_U32 *msgID);

//**************************************************
//
//! @brief  数据上报功能数据校验
//!
//! @param CTIOT_MQTT_DATA_REQ ptrDataRequest
//!
//! @retval CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_send_data_para(CTIOT_MQTT_DATA_REQ *ptrDataRequest);
#endif

#if defined(USE_CTIOT_EVENT_REPORT)
//**************************************************
//
//! @brief  二进制结构事件上报功能
//!
//! @param CTIOT_MQTT_PAYLOAD_TYPE payloadType
//! @param SDK_U32 eventSn
//! @param SDK_U16 eventID
//! @param SDK_U64 eventTime
//! @param SDK_U8 eventType
//! @param CTIOT_MQTT_PAYLOAD_TYPE payloadType ，见@ref CTIOT_MQTT_PAYLOAD_TYPE
//! @param SDK_U16 payloadLen
//! @param SDK_U8* payload
//! @param SDK_U8 qos
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//!
//! @retval CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_event_report(SDK_U32 eventSn, SDK_U16 eventID, SDK_U64 eventTime, SDK_U8 eventType,
                                CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID);
//**************************************************
//
//! @brief  事件上报数据校验
//!
//! @param SDK_U32 eventSn
//! @param SDK_U16 eventID
//! @param SDK_U64 eventTime
//! @param SDK_U8 eventType
//! @param CTIOT_MQTT_PAYLOAD_TYPE payloadType
//! @param SDK_U16 payloadLen
//! @param SDK_U8 *payload
//!
//! @retval CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_event_report_para(SDK_U32 eventSn, SDK_U16 eventID, SDK_U64 eventTime, SDK_U8 eventType,
                                              CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos);
#endif

#if defined(USE_CTIOT_RETRIEVEDATA)
//**************************************************
//
//! @brief  数据获取回应
//!
//! @param SDK_U32 gdsn
//! @param SDK_U8 resultCode
//! @param SDK_U16 payloadType
//! @param SDK_U16 datasetID
//! @param SDK_U16 payloadLen
//! @param SDK_U8* payload
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS send_retrieve_data_cnf(SDK_U32 gdsn, SDK_U8 resultCode, SDK_U16 payloadType, SDK_U16 datasetID, SDK_U16 dataCollectResultLen, SDK_U8 *dataCollectResult, SDK_U16 payloadLen, SDK_U8 *payload, SDK_U32 *msgID);

//**************************************************
//
//! @brief  数据获取数据校验
//!
//! @param SDK_U32 gdsn
//! @param SDK_U8 resultCode
//! @param SDK_U16 payloadType
//! @param SDK_U16 datasetID
//! @param SDK_U16 dataCollectResultLen
//! @param SDK_U8* dataCollectResult
//! @param SDK_U16 payloadLen
//! @param SDK_U8* payload
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_retrieve_data_cnf_para(SDK_U32 gdsn, SDK_U8 resultCode, SDK_U16 payloadType, SDK_U16 datasetID, SDK_U16 dataCollectResultLen, SDK_U8 *dataCollectResult, SDK_U16 payloadLen, SDK_U8 *payload);
#endif

#if defined(USE_CTIOT_TRANSPARENT_DATA_UL)
//**************************************************
//
//! @brief  透明传输功能
//!
//! @param CTIOT_MQTT_TRANSPARENT_DATA_REQUEST* ,透明传输入参，见@ref CTIOT_MQTT_TRANSPARENT_DATA_REQUEST
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_send_transparent_data_request(CTIOT_MQTT_TRANSPARENT_DATA_REQUEST *, SDK_U32 *msgID);

//**************************************************
//
//! @brief  透明传输功能
//!
//! @param SDK_U16 payloadLen
//! @param SDK_U8* payload
//! @param SDK_U8 qos
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_send_tr_data(SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID);

CTIOT_STATUS ctiot_send_transparent_data(SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos,SDK_U32 upTpDataSN, SDK_U32 *msgID);

//**************************************************
//
//! @brief  透明传输数据校验
//!
//! @param CTIOT_MQTT_TRANSPARENT_DATA_REQUEST *ptrTransparentRequestParameter见@ref CTIOT_MQTT_TRANSPARENT_DATA_REQUEST
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_transparent_data_para(CTIOT_MQTT_TRANSPARENT_DATA_REQUEST *ptrTransparentRequestParameter);
#endif

#if defined(USE_CTIOT_REMOTECTRL_EXCUTE)
//**************************************************
//
//! @brief  远程控制
//!
//! @param CTIOT_MQTT_REMOTE_CTRL_CNF* PtrRemoteCtrlCnf，远程控制接收参数，见@ref CTIOT_MQTT_REMOTE_CTRL_CNF
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_remote_ctrl_confirm(CTIOT_MQTT_REMOTE_CTRL_CNF *ptrRemoteCtrlCnf, SDK_U32 *msgID);
//**************************************************
//
//! @brief  远程控制
//!
//! @param SDK_U32 dmsn
//! @param SDK_U16 controlType
//! @param SDK_U8 resultCode
//! @param SDK_U16 additionalInfoLen
//! @param SDK_U8* additionalInfo
//! @param SDK_U32* msgID
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_send_remote_ctrl_cnf(SDK_U32 dmsn, SDK_U16 controlType, SDK_U8 resultCode,
                                        SDK_U16 additionalInfoLen, SDK_U8 *additionalInfo, SDK_U32 *msgID);

#endif

#if defined(USE_CTIOT_CMD_EXCUTE)
//**************************************************
//
//! @brief 终端指令下发回应
//!
//! @param CTIOT_MQTT_EXECUTE_CMD_CNF* 终端指令回应入参，参见@ref CTIOT_MQTT_EXECUTE_CMD_CNF
//! @param SDK_U32 *msgID ,出参，用于返回Message ID
//!
//! @retval T_SDK_BOOL 成功0，失败1
//
//**************************************************
CTIOT_STATUS ctiot_execute_cmd_cnf_response(CTIOT_MQTT_EXECUTE_CMD_CNF *ptrPara, SDK_U32 *msgID);

//**************************************************
//
//! @brief 终端指令下发回应
//!
//! @param SDK_U8 payloadType
//! @param SDK_U32 cmdSN
//! @param SDK_U8 resultCode
//! @param SDK_U16 datasetID
//! @param SDK_U8 *payload
//! @param SDK_U16 payloadLen
//! @param SDK_U32 *msgID
//!
//! @retval T_SDK_BOOL 成功0，失败1
//
//**************************************************
CTIOT_STATUS ctiot_send_execute_cmd_cnf(SDK_U8 payloadType, SDK_U32 cmdSN, SDK_U8 resultCode, SDK_U16 datasetID,
                                        SDK_U8 *payload, SDK_U16 payloadLen, SDK_U32 *msgID);
#endif

//**************************************************
//
//! @brief 应用初始化
//!
//! @param CTIOT_MQTT_INIT_REQ* ptrInfo，应用初始化入参，参见@ref CTIOT_MQTT_INIT_REQ
//!
//! @retval CTIOT_STATUS 结果码
//
//**************************************************
CTIOT_STATUS ctiot_initial_request(CTIOT_MQTT_INIT_REQ *ptrInfo);


//**************************************************
//
//! @brief 获取SDK状态函数
//!
//! @retval T_SDK_STATE 成功或失败
//
//**************************************************
T_SDK_STATE ctiot_get_status();

//**************************************************
//
//! @brief 设置SDK状态函数
//
//**************************************************
void ctiot_set_status(T_SDK_STATE newState);

//**************************************************
//
//! @brief 获取SDK最后出错状态
//!
//! @retval CTIOT_STATUS 结果吗
//
//**************************************************
CTIOT_STATUS ctiot_get_last_error();

//**************************************************
//
//! @brief 设置SDK最后出错状态
//! @param CTIOT_STATUS *ptrStatus
//! @param CTIOT_STATUS status
//
//**************************************************
void ctiot_set_last_error(CTIOT_STATUS *ptrStatus, CTIOT_STATUS status);

//**************************************************
//
//! @brief 清楚SDK出错状态
//
//**************************************************
void ctiot_clear_error();

#if 0
CTIOT_STATUS ctiot_validate_register_para(CTIOT_MQTT_REGISTER_REQUEST* ptrRegisterRequest);
#endif
//**************************************************
//
//! @brief  登录信息校验
//!
//! @param CTIOT_MQTT_LOGIN_REQ* ptrLoginRequestPara,参数查询返回参数,见@ref CTIOT_MQTT_LOGIN_REQ
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_login_para(CTIOT_MQTT_LOGIN_REQ *ptrLoginRequestPara);

//**************************************************
//
//! @brief  mqtt报文校验
//!
//! @param MessageData* ptrMsgdata,参数查询返回参数,见@ref MessageData
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_mqtt_message(MessageData *ptrMsgdata);

#if defined(USE_CTIOT_ENQUIREPARA_EXCUTE)
//**************************************************
//
//! @brief  参数查询返回函数
//!
//! @param CTIOT_MQTT_ENQUIRE_PARA_CNF* ptrConfirm,参数查询返回参数,见@ref CTIOT_MQTT_ENQUIRE_PARA_CNF
//! @param SDK_U32 *msgID
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_enquire_para_confirm(CTIOT_MQTT_ENQUIRE_PARA_CNF *ptrConfirm, SDK_U32 *msgID);

CTIOT_STATUS ctiot_enquire_para_conf(SDK_U32 dmsn,SDK_U8 resultCode,SDK_U8 payloadType,SDK_U16 datasetID,
					SDK_U16 payloadLen,SDK_U8 *payload,SDK_U16 resultLen,SDK_U8 *result,SDK_U32 *msgID);
//**************************************************
//
//! @brief  参数查询返回消息校验
//!
//! @param CTIOT_MQTT_ENQUIRE_PARA_CNF* ptrConfirm,参数查询返回参数,见@ref CTIOT_MQTT_ENQUIRE_PARA_CNF
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_enquire_para_confirm(CTIOT_MQTT_ENQUIRE_PARA_CNF *ptrConfirm);
#endif

#if defined(USE_CTIOT_SETPARA_EXCUTE)
//**************************************************
//
//! @brief  参数设置返回函数
//!
//! @param CTIOT_MQTT_SET_PARA_CNF* ptrConfirm,参数设置返回参数,见@ref CTIOT_MQTT_SET_PARA_CNF
//! @param SDK_U32 *msgID
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_set_para_confirm(CTIOT_MQTT_SET_PARA_CNF *ptrConfirm, SDK_U32 *msgID);

CTIOT_STATUS ctiot_set_para_conf(SDK_U32 dmsn,SDK_U8 resultCode,SDK_U8 payloadType,SDK_U16 datasetID,
								SDK_U16 payloadLen,SDK_U8* payload,SDK_U32 *msgID);
//**************************************************
//
//! @brief  参数设置返回消息校验
//!
//! @param CTIOT_MQTT_ENQUIRE_PARA_CNF* ptrConfirm,参数设置返回参数,见@ref CTIOT_MQTT_ENQUIRE_PARA_CNF
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_set_para_confirm(CTIOT_MQTT_SET_PARA_CNF *ptrConfirm);
#endif

extern char globalDeviceId[65];
extern SDK_U64 globalPlatformTimestamp;
extern char globalRedirectIP[20];

#if 0
CTIOT_STATUS ctiot_validate_params(CTIOT_VALIDATE_PARAMS params,...);
#endif

//**************************************************
//
//! @brief 消息入队函数
//!
//! @param SDK_U16 len
//! @param SDK_U8* ptrPayload
//! @param char* ptrTopic
//! @param SDK_U8 qos
//! @param SDK_U32* msgID
//!
//! @retval CTIOT_STATUS 返回结果码
//
//**************************************************
CTIOT_STATUS ctiot_tlink_publish_request(SDK_U16 len, SDK_U8 *ptrPayload, char *ptrTopic, SDK_U8 qos, SDK_U32 *msgID);

//**************************************************
//
//! @brief 新消息获取msgId函数
//!
//! @param TLINK_CLIENT
//!
//! @retval CTIOT_STATUS 返回结果码
//
//**************************************************
static SDK_U32 ctiot_tlink_getnextmid(TLINK_CLIENT *tlink);

//**************************************************
//
//! @brief ACK报文处理函数
//!
//! @retval T_SDK_BOOL 成功或失败
//
//**************************************************
void ctiot_tlink_handlemessage(unsigned short myPacketid);

//**************************************************
//
//! @brief 消息队列处理函数
//!
//! @retval T_SDK_BOOL 成功或失败
//
//**************************************************
T_SDK_BOOL ctiot_tlink_loop(void *arg);

//**************************************************
//
//! @brief 队列消息发送函数
//!
//! @retval T_SDK_BOOL 成功或失败
//
//**************************************************
T_SDK_BOOL ctiot_tlink_pub_queue();

#if defined(USE_CTIOT_FILE_UPLOAD)
//**************************************************
//
//! @brief  小文件上传（下行）解析功能
//!
//! @param MessageData* ptrMd,入参，见@ref MessageData
//!
//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_file_upload_cof_arrived(MessageData *ptrMd);

//**************************************************
//
//! @brief  小文件上传上传文件内容函数
//!
//! @param SDK_U32 upSmallFileSN
//! @param SDK_U8 isLastBlock
//! @param SDK_U16 blockSeq
//! @param SDK_U32 blockContentLen
//! @param SDK_U8 *blockContent
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_file_content_upload_request(SDK_U32 upSmallFileSN, SDK_U8 isLastBlock, SDK_U16 blockSeq, SDK_U32 blockContentLen, SDK_U8 *blockContent);

//**************************************************
//
//! @brief  小文件上传上传文件内容参数校验函数
//!
//! @param SDK_U32 upSmallFileSN
//! @param SDK_U8 isLastBlock
//! @param SDK_U16 blockSeq
//! @param SDK_U32 blockContentLen
//! @param SDK_U8 *blockContent
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_file_content_upload_para(SDK_U32 upSmallFileSN, SDK_U8 isLastBlock, SDK_U16 blockSeq, SDK_U32 blockContentLen, SDK_U8 *blockContent);

//**************************************************
//
//! @brief  小文件上传请求函数
//!
//! @param SDK_U32 upSmallFileSN
//! @param SDK_U32 fileNameLen
//! @param SDK_U8 *fileName
//! @param SDK_U32 fileSize
//! @param SDK_U16 blockNum
//! @param SDK_U16 blockSize
//! @param SDK_U8 *checksum
//! @param SDK_U32 *msgID
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_file_upload_request(SDK_U32 upSmallFileSN, SDK_U32 fileNameLen, SDK_U8 *fileName, SDK_U32 fileSize, SDK_U16 blockNum, SDK_U16 blockSize, SDK_U8 *checksum, SDK_U32 *msgID);

//**************************************************
//
//! @brief  小文件上传请求校验函数
//!
//! @param SDK_U32 upSmallFileSN
//! @param SDK_U32 fileNameLen
//! @param SDK_U8 *fileName
//! @param SDK_U32 fileSize
//! @param SDK_U16 blockNum
//! @param SDK_U16 blockSize
//! @param SDK_U8 *checksum
//! @param SDK_U32 *msgID
//!
//! @retval  CTIOT_STATUS 返回结果码
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_validate_file_upload_para(SDK_U32 upSmallFileSN, SDK_U32 fileNameLen, SDK_U8 *fileName, SDK_U32 fileSize, SDK_U16 blockNum, SDK_U16 blockSize, SDK_U8 *checksum);
#endif

CTIOT_STATUS ctiot_get_tlink_and_sdk_ver(TLINK_SDK_VER* tlinkSdkVer);

T_SDK_BOOL ctiot_close_session();

#endif
