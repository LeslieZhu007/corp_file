/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __CTIOT_MSG_PRINT_H
#define __CTIOT_MSG_PRINT_H

#if defined(USE_CTIOT_TRANSPARENT_DATA_UL)
//**************************************************
//
//! @brief  打印透明传输请求
//!
//! @param CTIOT_MQTT_MSG_SEND_TRANSPARENT_DATA_REQUEST* ptrReq,透明传输入参，见@ref CTIOT_MQTT_MSG_SEND_TRANSPARENT_DATA_REQUEST

//! @retval  无
//! @note   提示，可选
//
//**************************************************

void ctiot_print_send_transparent_data_request(CTIOT_MQTT_MSG_SEND_TRANSPARENT_DATA_REQUEST *ptrReq);
#endif

#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
//**************************************************
//
//! @brief  打印透明传输下行数据
//!
//! @param CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND* ptrReq,透明传输入参，见@ref CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND

//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_print_receive_downlink_transparent_data(CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND *ptrReq);
#endif

//**************************************************
//
//! @brief  打印登录请求信息
//!
//! @param CTIOT_MQTT_MSG_LOGIN_REQ* ptrReq,注册入参，见@ref CTIOT_MQTT_MSG_LOGIN_REQ

//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_print_login_request(CTIOT_MQTT_MSG_LOGIN_REQ *ptrReq);
//**************************************************
//
//! @brief  打印登录确认信息
//!
//! @param CTIOT_MQTT_MSG_LOGIN_CNF* ptrCnf,注册入参，见@ref CTIOT_MQTT_MSG_LOGIN_CNF

//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_print_login_confirm(CTIOT_MQTT_MSG_LOGIN_CNF *ptrCnf);

#if defined(USE_CTIOT_SEND_DATA)
//**************************************************
//
//! @brief  打印数据上报请求信息
//!
//! @param CTIOT_MQTT_MSG_SEND_DATA_REQ* ptrReq,注册入参，见@ref CTIOT_MQTT_MSG_SEND_DATA_REQ

//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_print_send_upload_data_request(CTIOT_MQTT_MSG_SEND_DATA_REQ *ptrReq);
#endif

#if defined(USE_CTIOT_CMD_EXCUTE)
//**************************************************
//
//! @brief  打印指令下发信息
//!
//! @param ptrReq 指令下发消息，参见@ref CTIOT_MQTT_EXECUTE_CMD_MSG
//!
//! @retval 无
//
//**************************************************
void ctiot_print_execute_cmd_request(CTIOT_MQTT_EXECUTE_CMD_MSG *ptrReq);

//**************************************************
//
//! @brief 打印指令下发响应信息
//!
//! @param ptrReq 指令下发响应信息，参见@ref CTIOT_MQTT_MSG_EXECUTE_CMD_CNF
//!
//! @retval 无
//
//**************************************************
void ctiot_print_execute_cmd_cnf(CTIOT_MQTT_MSG_EXECUTE_CMD_CNF *ptrReq);
#endif

#endif
