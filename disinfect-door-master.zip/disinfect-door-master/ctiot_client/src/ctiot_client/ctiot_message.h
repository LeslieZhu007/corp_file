/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __CTIOT_MESSAGE_H
#define __CTIOT_MESSAGE_H

#include "ctiot_tlink.h"

typedef SDK_U8 T_RDAP_RESULT_CODE;
#define RDAP_RESULT_SUCC 0
#define RDAP_RESULT_ILLEGAL_SN 10

//*****************************************************************************
//*************************************************
//
//! @addtogroup 登录编解码码入参，报文，返回
//! @{
//
//*************************************************

typedef struct
{
    SDK_U32 upPacketSN;      //!< 必选,定长	上行报文序列号
    SDK_U8 cmdType;          //!< 必选,定长	报文类型：固定为0x01
    SDK_U16 dasn;            //!< 必选,定长	终端接入报文序列号
    SDK_U64 deviceTimeStamp; //!< 必选,定长	终端当前本地时间(如果终端不能取到时间，则填写0x0000000000000000)
    SDK_U8 networkType;      //!< 必选,定长	底层网络类型
    SDK_U16 mqttHbt;         //!< 必选,定长	MQTT协议HeartbeatTimer(秒)
    SDK_U8 sdkVersion[3];    //!< 必选,定长     AEP终端SDK版本(第一个Byte表示协议类型,第二个Byte表示主版本号,第三个Byte表示次版本号)
    SDK_U8 sdkMode;          //!< 必选,定长	SDK加载模式
    char utcOffset[7];       //!< 必选,定长	终端当前的UTC时区差，如“区差，如ing（如果终端不能提供，则填写“+00:00”）
    char *softVersion;       //!< 必选,变长	终端应用软件版本
    char *deviceInfo;        //!< 可选,变长	设备型号
} CTIOT_MQTT_MSG_LOGIN_REQ;  //!< 登录请求编码的入参

typedef struct
{
    SDK_U32 dnPacketSN;        //!< 必选,定长 下行报文序列号
    SDK_U8 cmdType;            //!< 必选,定长	报文类型:固定为0x081
    SDK_U16 dasn; /*TBD:*/     //!< 必选,定长	与Connect报文中的终端接入报文序列号一致
    SDK_U8 resultCode;         //!< 必选,必选	响应码 成功(0) 失败(订阅失败(1)) 失败(终端鉴权失败(2)) 失败(其它原因(3))
    SDK_U64 platformTimeStamp; //!< 必选,定长	平台当前时间           *ResultCode为“成功”时的应答使用*
    SDK_U16 heartBeatTimer;    //!< 必选,定长 平台下发MQTT协议HeartbeatTimer（秒）
    char *redirectServerIP;    //!< 必选,变长 平台下发终端应登录的节点IP地址
} CTIOT_MQTT_MSG_LOGIN_CNF;    //!< 登录返回解码的报文

//*************************************************
//
//! @}
//
//*************************************************
typedef struct
{
    SDK_U16 datasetID;
    SDK_U16 payloadLen;
    SDK_U8 *payload;
} CTIOT_MQTT_MSG_COMPACT_ELE;

typedef struct
{
    SDK_U16 datasetID;
    SDK_U16 resultLen;
    SDK_U8 *result;
    SDK_U16 payloadLen;
    SDK_U8 *payload;
} CTIOT_MQTT_MSG_COMPACT_WITH_RLT_ELE;

typedef struct
{
    union {
        SDK_U16 datasetID;
        char *datasetName;
        SDK_U16 eventID;
    } u;
    char *payload;
} CTIOT_MQTT_MSG_JSON_ELE;
//*************************************************
//
//! @addtogroup 数据上报，数据编码，入参
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 upPacketSN;
    SDK_U8 cmdType;
    SDK_U32 upDataSN;
    SDK_U8 payloadType;
    union {
        CTIOT_MQTT_MSG_COMPACT_ELE compact;
        CTIOT_MQTT_MSG_COMPACT_WITH_RLT_ELE compactWithRlt;
        CTIOT_MQTT_MSG_JSON_ELE json;
    } u;
} CTIOT_MQTT_MSG_SEND_DATA_REQ;

//*************************************************
//
//! @}
//
//*************************************************
typedef struct
{
    SDK_U32 dnPacketSN;
    SDK_U8 cmdType;
    SDK_U32 dmsn;
    SDK_U16 controlType;
    /*the below parameters exist only when ControlType== 6*/
    SDK_U8 upgradeID;
    SDK_U8 fileChecksum[16];
    SDK_U8 upgradeType;
    char *upgradeVersion;
    char *upgradeURL;
    char *token;
} CTIOT_MQTT_MSG_REMOTE_CTRL_REQ;

typedef struct
{
    SDK_U32 upPacketSN;
    SDK_U8 cmdType; /**/
    SDK_U32 dmsn;
    SDK_U16 controlType;
    SDK_U8 resultCode;
    /*below only exist when ControlType == 5*/
    SDK_U16 additionalInfoLen;
    SDK_U8 *additionalInfo;
} CTIOT_MQTT_MSG_REMOTE_CTRL_CNF;

typedef struct
{
    SDK_U16 DatasetID;
    SDK_U16 payloadLen;
    SDK_U8 *payload;
} T_MSG_COMPACT_ELE;

typedef struct
{
    SDK_U16 DatasetID;
    SDK_U16 resultLen;
    SDK_U8 *result;
    SDK_U16 payloadLen;
    SDK_U8 *payload;
} T_MSG_COMPACT_WITH_RLT_ELE;

typedef struct
{
    union {
        SDK_U16 DatasetID;
        char *DatasetName;
        SDK_U16 EventID;
    } u;
    char *Payload;
} T_MSG_JSON_ELE;

//*************************************************
//
//! @addtogroup 透明传输终端上行报文
//! @{
//
//*************************************************

typedef struct
{
    SDK_U32 upPacketSN;                         //!<上行报文序列号
    SDK_U8 cmdType;                             //!<报文类型：固定为0x03
    SDK_U32 upTpDataSN;                         //!<透明数据上行报文序列号
    SDK_U16 payloadLen;                         //!<上报数据长度
    SDK_U8 *payload;                            //!<上报数据内容
} CTIOT_MQTT_MSG_SEND_TRANSPARENT_DATA_REQUEST; //!< 透明传输上行报文

//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 透明传输终端下行报文
//! @{
//
//*************************************************

typedef struct
{
    SDK_U32 dnPacketSN;                     //!<下行报文序列号
    SDK_U8 cmdType;                         //!<报文类型：固定为0x04
    SDK_U32 dnTpDataSN;                     //!<透明数据下行报文序列号
    SDK_U16 payloadLen;                     //!<下发数据长度
    SDK_U8 *payload;                        //!<下发数据
} CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND; //!< 透明传输下行报文

//*************************************************
//
//! @}
//
//*************************************************

//*************************************************
//
//! @addtogroup 云端指令下发和终端指令回应，全部
//! @{
//
//*************************************************
typedef struct
{
    SDK_U32 dnPacketSN; //!< 下行报文序列号
    SDK_U8 cmdType;     //!< 报文类型：固定为0x06
    SDK_U32 cmdSN;      //!< 指令下发操作序列号
    SDK_U8 payloadType; //!< 数据表示模式 0:普通的紧凑二进制模式 2:普通JSON模式
    union {
        CTIOT_MQTT_MSG_COMPACT_ELE compact; //!< 参见@ref CTIOT_MQTT_TOTAL_MSG_COMPACT_ELE
        CTIOT_MQTT_MSG_JSON_ELE json;       //!< 参见@ref CTIOT_MQTT_TOTAL_MSG_JSON_ELE
    } u;
} CTIOT_MQTT_EXECUTE_CMD_MSG; //!< 云端指令下发

typedef struct
{
    SDK_U32 upPacketSN; //!< 上行报文序列号
    SDK_U8 cmdType;     //!< 报文类型：固定为0x86
    SDK_U32 cmdSN;      //!< 与指令下发操作中的指令下发操作序列号一致
    SDK_U8 resultCode;  //!< 0:执行成功 1:执行失败 2:无效数据集类型 3:无效数据集标识（终端无法识别的DatasetID）4:数据集Payload解析失败
    SDK_U8 payloadType; //!< 结果通知字段类型 0:普通紧凑二进制模式 2:普通JSON模式
    union {
        CTIOT_MQTT_MSG_COMPACT_ELE compact; //!< 参见@ref CTIOT_MQTT_TOTAL_MSG_COMPACT_ELE
        CTIOT_MQTT_MSG_JSON_ELE json;       //!< 参见@ref CTIOT_MQTT_TOTAL_MSG_JSON_ELE
    } u;
} CTIOT_MQTT_MSG_EXECUTE_CMD_CNF; //!< 终端指令回应

//*************************************************
//
//! @}
//
//*************************************************

#endif
