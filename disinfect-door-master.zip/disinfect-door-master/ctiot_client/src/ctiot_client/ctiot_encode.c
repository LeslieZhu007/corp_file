/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_encode.h"
#include "ctiot_log.h"
#include "ctiot_tlink.h"

CTIOT_STATUS ctiot_encode(SDK_U8 **ptrStream, SDK_U16 *ptrLen, CTIOT_PARAMS params, ...)
{
    *ptrLen = 0;
    CTIOT_STATUS ret = CTIOT_SUCCESS;
    int i = 0, j = 0;
    for (i = 0; i < params.ctiot_param_counts; i++)
    {
        *ptrLen += params.ctiot_params[i].ctiot_param_len;
        if (params.ctiot_params[i].ctiot_param_type == CTIOT_PARAM_TYPE_TEXT || params.ctiot_params[i].ctiot_param_type == CTIOT_PARAM_TYPE_BINARY)
        {
            *ptrLen += 2;
        }
    }
    OS_GET_MEM(*ptrStream, SDK_U8, *ptrLen);
    if (ptrStream == NULL)
    {
        ret = CTIOT_OS_NOT_ENOUGH_MEM;
        goto exit;
    }
    int curPos = 0;
    va_list argp;
    va_start(argp, params);
    for (i = 0; i < params.ctiot_param_counts; i++)
    {
        switch (params.ctiot_params[i].ctiot_param_type)
        {
        case CTIOT_PARAM_TYPE_DIGIT:
        {
            int len = params.ctiot_params[i].ctiot_param_len;
            if (len == 1 || len == 2 || len == 4)
            {
                SDK_U32 val = (SDK_U32)va_arg(argp, int);
                for (j = 0; j < len; j++)
                {
                    (*ptrStream)[j + curPos] = (SDK_U8)(val >> (8 * (len - 1 - j)) & 0x0ff);
                }
            }
            else if (len == 8)
            {
                SDK_U64 val = (SDK_U64)va_arg(argp, long long);
                for (j = 0; j < len; j++)
                {
                    (*ptrStream)[j + curPos] = (SDK_U8)(val >> (8 * (len - 1 - j)) & 0x0ff);
                }
            }
            curPos += params.ctiot_params[i].ctiot_param_len;
            break;
        }
        case CTIOT_PARAM_TYPE_BINARY:
        case CTIOT_PARAM_TYPE_TEXT:
        {
            SDK_U8 *ptrContent = (SDK_U8 *)va_arg(argp, char *);
            (*ptrStream)[curPos++] = (SDK_U8)(params.ctiot_params[i].ctiot_param_len >> 8 & 0x0ff);
            (*ptrStream)[curPos++] = (SDK_U8)(params.ctiot_params[i].ctiot_param_len & 0x0ff);
            for (j = 0; j < params.ctiot_params[i].ctiot_param_len; j++)
            {
                (*ptrStream)[j + curPos] = ptrContent[j];
            }
            curPos += params.ctiot_params[i].ctiot_param_len;
            break;
        }
        case CTIOT_PARAM_TYPE_BINARY_STATIC:
        case CTIOT_PARAM_TYPE_TEXT_STATIC:
        {
            SDK_U8 *ptrContent = (SDK_U8 *)va_arg(argp, char *);
            for (j = 0; j < params.ctiot_params[i].ctiot_param_len; j++)
            {
                (*ptrStream)[j + curPos] = ptrContent[j];
            }
            curPos += params.ctiot_params[i].ctiot_param_len;
            break;
        }
        default:
            break;
        }
    }
exit:
    va_end(argp);
    return ret;
}
