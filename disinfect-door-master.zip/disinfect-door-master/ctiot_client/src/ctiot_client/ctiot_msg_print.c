/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_message.h"
#include <string.h>
#include "ctiot_log.h"

#if defined(USE_CTIOT_TRANSPARENT_DATA_UL)
void ctiot_print_send_transparent_data_request(CTIOT_MQTT_MSG_SEND_TRANSPARENT_DATA_REQUEST *ptrReq)
{
	SDK_U16 i = 0;
	log_print_plain_text("upPacketSN:%u\n", ptrReq->upPacketSN);
	log_print_plain_text("cmdType:%u\n", ptrReq->cmdType);
	log_print_plain_text("upTpDataSN:%u\n", ptrReq->upTpDataSN);
	log_print_plain_text("payloadLen:%u\n", ptrReq->payloadLen);
	log_print_plain_text("payload:\n");
	for (i = 0; i < ptrReq->payloadLen; i++)
	{
		log_print_plain_text("%02x", ptrReq->payload[i]);
	}
	log_print_plain_text("\n");
}
#endif

#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
void ctiot_print_receive_downlink_transparent_data(CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND *ptrReq)
{
	SDK_U16 i = 0;
	log_print_plain_text("dnPacketSN:%u\n", ptrReq->dnPacketSN);
	log_print_plain_text("cmdType:%u\n", ptrReq->cmdType);
	log_print_plain_text("dnTpDataSN:%u\n", ptrReq->dnTpDataSN);
	log_print_plain_text("payloadLen:%u\n", ptrReq->payloadLen);
	log_print_plain_text("payload:\n");
	for (i = 0; i < ptrReq->payloadLen; i++)
	{
		log_print_plain_text("%02x", ptrReq->payload[i]);
	}
	log_print_plain_text("\n");
}
#endif

void ctiot_print_login_request(CTIOT_MQTT_MSG_LOGIN_REQ *ptrReq)
{
	SDK_U16 i = 0;
	log_print_plain_text("upPacketSN:%u\n", ptrReq->upPacketSN);
	log_print_plain_text("cmdType:%u\n", ptrReq->cmdType);
	log_print_plain_text("dasn:%u\n", ptrReq->dasn);
	log_print_plain_text("deviceTimeStamp:%llx\n", ptrReq->deviceTimeStamp);
	log_print_plain_text("networkType:%u\n", ptrReq->networkType);
	log_print_plain_text("mqttHbt:%u\n", ptrReq->mqttHbt);
	log_print_plain_text("sdkVersion:%u%u%u\n", ptrReq->sdkVersion[0], ptrReq->sdkVersion[1], ptrReq->sdkVersion[2]);
	log_print_plain_text("sdkMode:%u\n", ptrReq->sdkMode);
	log_print_plain_text("softVersion:%s\n", ptrReq->softVersion);
	log_print_plain_text("deviceInfo:%s\n", ptrReq->deviceInfo);
}
void ctiot_print_login_confirm(CTIOT_MQTT_MSG_LOGIN_CNF *ptrCnf)
{
	log_print_plain_text("dnPacketSN:%u\n", ptrCnf->dnPacketSN);
	log_print_plain_text("dasn:%u\n", ptrCnf->dasn);
	log_print_plain_text("cmdType:%u\n", ptrCnf->cmdType);
	log_print_plain_text("resultCode:%u\n", ptrCnf->resultCode);
	log_print_plain_text("platformTimeStamp:%llx\n", ptrCnf->platformTimeStamp);
	log_print_plain_text("heartBeatTimer:%u\n", ptrCnf->heartBeatTimer);
	log_print_plain_text("redirectServerIP:%s\n", ptrCnf->redirectServerIP);
}

#if defined(USE_CTIOT_SEND_DATA)
void ctiot_print_send_upload_data_request(CTIOT_MQTT_MSG_SEND_DATA_REQ *ptrReq)
{
	SDK_U16 i = 0;
	log_print_plain_text("upPacketSN:%u\n", ptrReq->upPacketSN);
	log_print_plain_text("cmdType:%u\n", ptrReq->cmdType);
	log_print_plain_text("upDataSN:%u\n", ptrReq->upDataSN);
	log_print_plain_text("payloadType:%u\n", ptrReq->payloadType);
	if (ptrReq->payloadType == 0)
	{
		log_print_plain_text("compact.datasetID:%u\n", ptrReq->u.compact.datasetID);
		log_print_plain_text("compact.payloadLen:%u\n", ptrReq->u.compact.payloadLen);
		log_print_plain_text("compact.payload:\n");
		for (i = 0; i < ptrReq->u.compact.payloadLen; i++)
		{
			log_print_plain_text("%02x", ptrReq->u.compact.payload[i]);
		}
		log_print_plain_text("\n");
	}
	else if (ptrReq->payloadType == 1)
	{
		log_print_plain_text("compactWithRlt.datasetID:%u\n", ptrReq->u.compactWithRlt.datasetID);
		log_print_plain_text("compactWithRlt.resultLen;:%u\n", ptrReq->u.compactWithRlt.resultLen);
		log_print_plain_text("compactWithRlt.result:\n");
		for (i = 0; i < ptrReq->u.compactWithRlt.resultLen; i++)
		{
			log_print_plain_text("%02x", ptrReq->u.compactWithRlt.result[i]);
		}
		log_print_plain_text("\n");
		log_print_plain_text("compactWithRslt.payloadLen:%u\n", ptrReq->u.compactWithRlt.payloadLen);
		log_print_plain_text("compactWithRslt.payload:\n");
		for (i = 0; i < ptrReq->u.compactWithRlt.payloadLen; i++)
		{
			log_print_plain_text("%02x", ptrReq->u.compactWithRlt.payload[i]);
		}
		log_print_plain_text("\n");
	}
	else if (ptrReq->payloadType == 2)
	{
		log_print_plain_text("json.datasetID:%u\n", ptrReq->u.json.u.datasetID);
		log_print_plain_text("json.Payload:%s\n", ptrReq->u.json.payload);
	}
}
#endif

void ctiot_print_remote_ctrl_request(CTIOT_MQTT_MSG_REMOTE_CTRL_REQ *ptrReq)
{
	SDK_U16 i = 0;
	log_print_plain_text("dnPacketSN:%u\n", ptrReq->dnPacketSN);
	log_print_plain_text("cmdType:%u\n", ptrReq->cmdType);
	log_print_plain_text("dmsn:%u\n", ptrReq->dmsn);
}

#if defined(USE_CTIOT_CMD_EXCUTE)
void ctiot_print_execute_cmd_request(CTIOT_MQTT_EXECUTE_CMD_MSG *ptrReq)
{
	SDK_U16 i = 0;
	//log_print_plain_text方法,不记录日志打印的时间、文件、方法、所在行
	log_print_plain_text("dnPacketSN:%u\n", ptrReq->dnPacketSN);
	log_print_plain_text("cmdType:%u\n", ptrReq->cmdType);
	log_print_plain_text("cmdSN:%u\n", ptrReq->cmdSN);
	log_print_plain_text("payloadType:%u\n", ptrReq->payloadType);
	if (ptrReq->payloadType == 0)
	{
		log_print_plain_text("compact.datasetID:%u\n", ptrReq->u.compact.datasetID);
		log_print_plain_text("compact.payloadLen:%u\n", ptrReq->u.compact.payloadLen);
		log_print_plain_text("compact.payload:\n");
		for (i = 0; i < ptrReq->u.compact.payloadLen; i++)
		{
			log_print_plain_text("%02x", ptrReq->u.compact.payload[i]);
		}
		log_print_plain_text("\n");
	}
	else if (ptrReq->payloadType == 2)
	{
		log_print_plain_text("json.datasetID:%u\n", ptrReq->u.json.u.datasetID);
		log_print_plain_text("json.payload:%s\n", ptrReq->u.json.payload);
	}
}
void ctiot_print_execute_cmd_cnf(CTIOT_MQTT_MSG_EXECUTE_CMD_CNF *ptrReq)
{
	SDK_U16 i = 0;
	log_print_plain_text("UpPacketSN:%u\n", ptrReq->upPacketSN);
	log_print_plain_text("CmdType:%u\n", ptrReq->cmdType);
	log_print_plain_text("CmdSN:%u\n", ptrReq->cmdSN);
	log_print_plain_text("ResultCode:%u\n", ptrReq->resultCode);
	log_print_plain_text("PayloadType:%u\n", ptrReq->payloadType);
	if (ptrReq->payloadType == 0)
	{
		log_print_plain_text("compact.datasetID:%u\n", ptrReq->u.compact.datasetID);
		log_print_plain_text("compact.payloadLen:%u\n", ptrReq->u.compact.payloadLen);
		log_print_plain_text("compact.payload:\n");
		for (i = 0; i < ptrReq->u.compact.payloadLen; i++)
		{
			log_print_plain_text("%02x", ptrReq->u.compact.payload[i]);
		}
		log_print_plain_text("\n");
	}
	else if (ptrReq->payloadType == 2)
	{
		log_print_plain_text("json.datasetID:%u\n", ptrReq->u.json.u.datasetID);
		log_print_plain_text("json.payload:%s\n", ptrReq->u.json.payload);
	}
}
#endif
