/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __CTIOT_TLINK_H
#define __CTIOT_TLINK_H

#define TOPIC_UL_DATA_REQ       "v1/up/ad"
#define TOPIC_UL_TR_DATA_REQ    "v1/up/tr"
#define TOPIC_FILE_UPLOAD_REQ   "v1/up/ft"
#define TOPIC_RETRIEVE_DATA_CNF "v1/up/gd"
#define TOPIC_EXECUTE_CMD_CNF   "v1/up/cmd"
#define TOPIC_EVENT_REPORT      "v1/up/er"
#define TOPIC_ENQUIRE_PARA_CNF  "v1/up/dm"
#define TOPIC_SET_PARA_CNF      "v1/up/dm"
#define TOPIC_REMOTE_CTRL_CNF   "v1/up/dm"
#define TOPIC_ALARM_REPORT      "v1/up/dm"

#define TOPIC_REG_CNF           "v1/dn/da"
#define TOPIC_DL_TR_DATA        "v1/dn/tr"
#define TOPIC_RETRIEVE_DATA     "v1/dn/gd"
#define TOPIC_EXECUTE_CMD       "v1/dn/cmd"
#define TOPIC_ENQUIRE_PARA      "v1/dn/dm"
#define TOPIC_SET_PARA          "v1/dn/dm"
#define TOPIC_REMOTE_CTRL       "v1/dn/dm"
#define TOPIC_FILE_UPLOAD       "v1/dn/ft"

#define QOS_UL_DATA_REQ       QOS1
#define QOS_UL_TR_DATA_REQ    QOS1
#define QOS_RETRIEVE_DATA_CNF QOS1
#define QOS_EXECUTE_CMD_CNF   QOS1
#define QOS_EVENT_REPORT      QOS1
#define QOS_ENQUIRE_PARA_CNF  QOS1
#define QOS_SET_PARA_CNF      QOS1
#define QOS_REMOTE_CTRL_CNF   QOS1
#define QOS_ALARM_REPORT      QOS1
#define QOS_FILE_UPLOAD_REQ   QOS1

#define QOS_DL_TR_DATA           QOS0
#define QOS_RETRIEVE_DATA_REQ    QOS0
#define QOS_EXECUTE_CMD_REQ      QOS0
#define QOS_ENQUIRE_PARA_REQ     QOS0
#define QOS_SET_PARA_REQ         QOS0
#define QOS_REMOTE_CTRL_REQ      QOS0

/*CMD type*/
#define CMD_ID_LOGIN_REQ         0x01
#define CMD_ID_LOGOUT_REQ        0xff /*Reserved*/
#define CMD_ID_UL_DATA_REQ       0x02
#define CMD_ID_UL_TR_DATA_REQ    0x03
#define CMD_ID_RETRIEVE_DATA_CNF 0x85
#define CMD_ID_EXECUTE_CMD_CNF   0x86
#define CMD_ID_EVENT_REPORT      0x07
#define CMD_ID_ENQUIRE_PARA_CNF  0x88
#define CMD_ID_SET_PARA_CNF      0x89
#define CMD_ID_REMOTE_CTRL_CNF   0x8a
#define CMD_ID_ALARM_REPORT      0x0b
#define CMD_ID_FILE_UPLOAD_REQ   0x0d
#define CMD_ID_FILE_CONTENT_UPLOAD_REQ 0x0e

#define CMD_ID_LOGIN_CNF            0x81
#define CMD_ID_DL_TR_DATA           0x04
#define CMD_ID_RETRIEVE_DATA_REQ    0x05
#define CMD_ID_EXECUTE_CMD_REQ      0x06
#define CMD_ID_ENQUIRE_PARA_REQ     0x08
#define CMD_ID_SET_PARA_REQ         0x09
#define CMD_ID_REMOTE_CTRL_REQ      0x0a

#endif
