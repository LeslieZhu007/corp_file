/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __CTIOT_ENCODE_H
#define __CTIOT_ENCODE_H

#include "ctiot_message.h"

CTIOT_STATUS ctiot_encode(SDK_U8 **ptrStream, SDK_U16 *ptrLen, CTIOT_PARAMS params, ...);

#endif
