/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __CTIOT_TLINK_QUEQUE_H
#define __CTIOT_TLINK_QUEQUE_H

#include "MQTTClient.h"
#include "ctiot_tlink_config.h"

typedef enum
{
	TLINK_QUEUE_WAIT_FOR_SEND,
	TLINK_QUEUE_WAIT_FOR_ACK,
	TLINK_QUEUE_FAILURE,
	TLINK_QUEUE_SUCCESS
} TLINK_MSG_STATUS;

typedef struct
{
	char *topic;
	enum QoS qos;
	messageHandler cb;
} T_RDAP_SUBSCRIBE_EVENT_REQ;

typedef struct
{
	char *topic;
} T_RDAP_UNSUBSCRIBE_EVENT_REQ;

typedef struct
{
	SDK_U16 len;
	SDK_U8 *payload;
	char *topic;
	SDK_U8 qos;
	SDK_U16 mqttPacketID;
} T_RDAP_PUBLISH_EVENT_REQ;

typedef struct
{
	SDK_U8 msgType;
	SDK_U8 *ptrMsg;
	SDK_U32 msgID;
	TLINK_MSG_STATUS status; //消息状态
	SDK_U8 retrans;			 //重传次数
	Timer time;				 //超时时间
} T_RDAP_MSG;

typedef struct msg_node
{
	T_RDAP_MSG *msg;
	struct msg_node *next;
} T_RDAP_MSG_NODE;

typedef struct
{
	SDK_U32 msgNum;
	SDK_U32 maxQueueLen;
	T_RDAP_MSG_NODE *send;
	T_RDAP_MSG_NODE *head;
	T_RDAP_MSG_NODE *tail;
} T_RDAP_QUEUE;

typedef enum
{
	RDAP_SUBSCRIBE_EVENT_REQ,
	RDAP_UNSUBSCRIBE_EVENT_REQ,
	RDAP_PUBLISH_EVENT_REQ,
} T_RDAP_MSG_TYPE;

T_SDK_BOOL tlink_create_queue(T_RDAP_QUEUE *tlinkQueue, int maxQueuelen);
CTIOT_STATUS tlink_add_msg(T_RDAP_QUEUE *tlinkQueue, T_RDAP_MSG *pMsg);
T_SDK_BOOL tlink_remove_msg_by_msgid(T_RDAP_QUEUE *tlinkQueue, SDK_U32 msgId);
T_SDK_BOOL tlink_get_msg(T_RDAP_QUEUE *tlinkQueue, T_RDAP_MSG **pMsg);
CTIOT_STATUS tlink_clean_queue(T_RDAP_QUEUE *tlinkQueue);
T_SDK_BOOL tlink_remove_msg_by_packetid(T_RDAP_QUEUE *tlinkQueue, SDK_U16 mqttpacketID, SDK_U32 *msgID);
#endif
