/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include <stdio.h>
#include <string.h>
#ifdef WIN32
#include <memory.h>
#include <process.h>
#include <windows.h>
#endif
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_tlink_queue.h"

extern SDK_U16 globalMaxQueueLen;

#ifdef WIN32
T_MUTEX_ID mut;
T_RDAP_QUEUE rdapQueue;
#else
#if defined(OS_FREERTOS_CT)
T_MUTEX_ID mut;
T_RDAP_QUEUE rdapQueue;
#else
pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;
T_RDAP_QUEUE rdapQueue;
#endif
#endif

T_SDK_BOOL tlink_create_queue(T_RDAP_QUEUE *tlinkQueue, int maxQueuelen)
{
	T_SDK_BOOL ret = SDK_TRUE;
	if (maxQueuelen == 0 || maxQueuelen >= globalMaxQueueLen)
	{
		tlinkQueue->maxQueueLen = globalMaxQueueLen;
	}
	else
	{
		tlinkQueue->maxQueueLen = maxQueuelen;
	}
#ifdef WIN32
	mut = OS_CREATE_MUTEX(NULL, SDK_FALSE, NULL);
#else
#if defined(OS_FREERTOS_CT)
	OS_CREATE_MUTEX(mut);
#else
	OS_CREATE_MUTEX(&(mut));
#endif
#endif
	tlinkQueue->msgNum = 0;
	tlinkQueue->head = NULL;
	tlinkQueue->tail = NULL;
	return ret;
}

CTIOT_STATUS tlink_add_msg(T_RDAP_QUEUE *tlinkQueue, T_RDAP_MSG *pMsg)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	T_RDAP_MSG_NODE *pNode = NULL;
	if (tlinkQueue->msgNum >= tlinkQueue->maxQueueLen)
	{
		return CTIOT_QUEUE_OUT_BORDER;
	}
#if defined(WIN32)
	OS_GET_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_GET_MUTEX(mut);
#else
	OS_GET_MUTEX(&(mut));
#endif
	OS_GET_MEM(pNode, T_RDAP_MSG_NODE, sizeof(T_RDAP_MSG_NODE));
	if (pNode == NULL)
	{
		return CTIOT_OS_NOT_ENOUGH_MEM;
	}
	pNode->msg = pMsg;
	pNode->next = NULL;

	if (pNode != NULL)
	{
		if (tlinkQueue->head == NULL)
		{
			tlinkQueue->head = pNode;
		}
		else
		{
			tlinkQueue->tail->next = pNode;
		}
		tlinkQueue->tail = pNode;
		tlinkQueue->msgNum++;
	}
#if defined(WIN32)
	OS_PUT_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_PUT_MUTEX(mut);
#else
	OS_PUT_MUTEX(&(mut));
#endif
	return ret;
}

T_SDK_BOOL tlink_remove_msg_by_msgid(T_RDAP_QUEUE *tlinkQueue, SDK_U32 msgId)
{
	T_SDK_BOOL ret = SDK_FALSE;
	T_RDAP_MSG_NODE *temp = NULL;

	T_RDAP_MSG_NODE *find = NULL;
#if defined(WIN32)
	OS_GET_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_GET_MUTEX(mut);
#else
	OS_GET_MUTEX(&(mut));
#endif
	if (tlinkQueue->head == NULL || tlinkQueue->msgNum == 0)
	{
		ret = SDK_FALSE;
	}
	else
	{
		if (tlinkQueue->head->msg->msgID == msgId)
		{
			temp = tlinkQueue->head;
			tlinkQueue->head = tlinkQueue->head->next;
			tlinkQueue->msgNum--;
			ret = SDK_TRUE;
		}
		else
		{
			find = tlinkQueue->head;
			while (find->next != NULL)
			{
				if (find->next->msg->msgID == msgId)
				{
					temp = find->next;
					find->next = temp->next;
					tlinkQueue->msgNum--;
					ret = SDK_TRUE;
					break;
				}
				find = find->next;
			}
		}
		if (tlinkQueue->msgNum == 0)
		{
			tlinkQueue->head = NULL;
			tlinkQueue->tail = NULL;
			tlinkQueue->send = NULL;
		}
		else
		{
			if (tlinkQueue->send == temp)
			{
				tlinkQueue->send = temp->next;
			}
		}

		T_RDAP_PUBLISH_EVENT_REQ *pubEvent = NULL;
		T_RDAP_MSG *msg = temp->msg;
		switch (msg->msgType)
		{
		case RDAP_PUBLISH_EVENT_REQ:
			pubEvent = (T_RDAP_PUBLISH_EVENT_REQ *)msg->ptrMsg;
			break;
		default:
			break;
		}

		if (msg->ptrMsg != NULL)
		{
			if (msg->msgType == RDAP_PUBLISH_EVENT_REQ)
			{
				OS_PUT_MEM(pubEvent->payload);
				OS_PUT_MEM(pubEvent->topic);
			}
			OS_PUT_MEM(msg->ptrMsg);
		}

		if (msg != NULL)
		{
			OS_PUT_MEM(msg);
		}
		if (temp != NULL)
		{
			OS_PUT_MEM(temp);
		}
		ret = SDK_TRUE;
	}
#if defined(WIN32)
	OS_PUT_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_PUT_MUTEX(mut);
#else
	OS_PUT_MUTEX(&(mut));
#endif
	return ret;
}

T_SDK_BOOL tlink_remove_msg_by_packetid(T_RDAP_QUEUE *tlinkQueue, SDK_U16 mqttPacketID, SDK_U32 *msgID)
{
	T_SDK_BOOL ret = SDK_FALSE;
	T_RDAP_MSG_NODE *temp = NULL;

	T_RDAP_MSG_NODE *find = NULL;
#if defined(WIN32)
	OS_GET_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_GET_MUTEX(mut);
#else
	OS_GET_MUTEX(&(mut));
#endif
	if (tlinkQueue->head == NULL || tlinkQueue->msgNum == 0)
	{
		ret = SDK_FALSE;
	}
	else
	{
		T_RDAP_PUBLISH_EVENT_REQ *pubEvent = NULL;
		switch (tlinkQueue->head->msg->msgType)
		{
		case RDAP_PUBLISH_EVENT_REQ:
			pubEvent = (T_RDAP_PUBLISH_EVENT_REQ *)tlinkQueue->head->msg->ptrMsg;
			break;
		default:
			break;
		}
		if (pubEvent != NULL && pubEvent->mqttPacketID == mqttPacketID)
		{
			temp = tlinkQueue->head;
			(*msgID) = temp->msg->msgID;
			tlinkQueue->head = tlinkQueue->head->next;
			tlinkQueue->msgNum--;
			ret = SDK_TRUE;
		}
		else
		{
			find = tlinkQueue->head;
			while (find->next != NULL)
			{
				pubEvent = NULL;
				switch (find->next->msg->msgType)
				{
				case RDAP_PUBLISH_EVENT_REQ:
					pubEvent = (T_RDAP_PUBLISH_EVENT_REQ *)find->next->msg->ptrMsg;
					break;
				default:
					break;
				}
				if (pubEvent != NULL && pubEvent->mqttPacketID == mqttPacketID)
				{
					temp = find->next;
					(*msgID) = temp->msg->msgID;
					find->next = temp->next;
					tlinkQueue->msgNum--;
					ret = SDK_TRUE;
					break;
				}
				find = find->next;
			}
		}
		if (tlinkQueue->msgNum == 0)
		{
			tlinkQueue->head = NULL;
			tlinkQueue->tail = NULL;
			tlinkQueue->send = NULL;
		}
		else
		{
			if (tlinkQueue->send == temp && ret == SDK_TRUE)
			{
				tlinkQueue->send = temp->next;
			}
		}
		if (ret == SDK_TRUE)
		{
			pubEvent = NULL;
			T_RDAP_MSG *msg = temp->msg;
			switch (msg->msgType)
			{
			case RDAP_PUBLISH_EVENT_REQ:
				pubEvent = (T_RDAP_PUBLISH_EVENT_REQ *)msg->ptrMsg;
				break;
			default:
				break;
			}

			if (msg->ptrMsg != NULL)
			{
				if (msg->msgType == RDAP_PUBLISH_EVENT_REQ)
				{
					OS_PUT_MEM(pubEvent->payload);
					OS_PUT_MEM(pubEvent->topic);
				}
				OS_PUT_MEM(msg->ptrMsg);
			}

			if (msg != NULL)
			{
				OS_PUT_MEM(msg);
			}
			if (temp != NULL)
			{
				OS_PUT_MEM(temp);
			}
		}
	}
#if defined(WIN32)
	OS_PUT_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_PUT_MUTEX(mut);
#else
	OS_PUT_MUTEX(&(mut));
#endif
	return ret;
}

T_SDK_BOOL tlink_get_msg(T_RDAP_QUEUE *tlinkQueue, T_RDAP_MSG **pMsg)
{
	T_SDK_BOOL ret = SDK_TRUE;
	T_RDAP_MSG_NODE *temp = NULL;
	T_RDAP_MSG_NODE *find = NULL;
#if defined(WIN32)
	OS_GET_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_GET_MUTEX(mut);
#else
	OS_GET_MUTEX(&(mut));
#endif
	if (tlinkQueue->head == NULL || tlinkQueue->msgNum == 0)
	{
		*pMsg = NULL;
		ret = SDK_FALSE;
	}
	else
	{
		if (tlinkQueue->send == NULL)
		{
			tlinkQueue->send = tlinkQueue->head;
		}
		*pMsg = tlinkQueue->send->msg;
		temp = tlinkQueue->send;
		tlinkQueue->send = tlinkQueue->send->next;
		T_RDAP_PUBLISH_EVENT_REQ *pubEvent = NULL;
		switch ((*pMsg)->msgType)
		{
		case RDAP_PUBLISH_EVENT_REQ:
			pubEvent = (T_RDAP_PUBLISH_EVENT_REQ *)(*pMsg)->ptrMsg;
			if (pubEvent == NULL || (pubEvent->qos != 1 && pubEvent->qos != 2))
			{
				if (temp == tlinkQueue->head)
				{
					tlinkQueue->head = temp->next;
					tlinkQueue->msgNum--;
				}
				else
				{
					find = tlinkQueue->head;
					while (find->next != NULL)
					{
						if (find->next == temp)
						{
							find->next = temp->next;
							tlinkQueue->msgNum--;
							break;
						}
						find = find->next;
					}
				}
				OS_PUT_MEM(temp);
			}
			break;
		default:
			break;
		}
		ret = SDK_TRUE;
	}
#if defined(WIN32)
	OS_PUT_MUTEX(mut);
#elif defined(OS_FREERTOS_CT)
	OS_PUT_MUTEX(mut);
#else
	OS_PUT_MUTEX(&(mut));
#endif
	return ret;
}

CTIOT_STATUS tlink_clean_queue(T_RDAP_QUEUE *tlinkQueue)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	T_RDAP_MSG *msg = NULL;
	T_RDAP_PUBLISH_EVENT_REQ *pubEvent = NULL;
#if defined(OS_FREERTOS_CT)
	OS_GET_MUTEX(mut);
#else
	if (OS_GET_MUTEX(&mut) != 0)
	{
		return CTIOT_OS_MUTEX_ERROR;
	}
#endif
	while (tlinkQueue->msgNum != 0 && tlinkQueue->head != NULL)
	{
		msg = tlinkQueue->head->msg;
		switch (msg->msgType)
		{
		case RDAP_PUBLISH_EVENT_REQ:
			pubEvent = (T_RDAP_PUBLISH_EVENT_REQ *)msg->ptrMsg;
			break;
		default:
			break;
		}

		if (msg->ptrMsg != NULL)
		{
			if (msg->msgType == RDAP_PUBLISH_EVENT_REQ)
			{
				OS_PUT_MEM(pubEvent->payload);
				OS_PUT_MEM(pubEvent->topic);
			}
			OS_PUT_MEM(msg->ptrMsg);
		}

		if (msg != NULL)
		{
			OS_PUT_MEM(msg);
		}
		tlinkQueue->head = tlinkQueue->head->next;
		tlinkQueue->msgNum--;
	}
	tlinkQueue->msgNum = 0;
	tlinkQueue->head = 0;
	tlinkQueue->tail = 0;
#if defined(OS_FREERTOS_CT)
	OS_PUT_MUTEX(mut);
#else
	if (OS_PUT_MUTEX(&(mut)) != 0)
	{
		return CTIOT_OS_MUTEX_ERROR;
	}
#endif
	return ret;
}
