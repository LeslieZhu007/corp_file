/*心跳包文重发次数*/
#define PING_TIMES 3
/*队列最大长度*/
#define MAX_QUEUE_LEN 50
/*单次处理消息数目*/
#define MAX_PROCESS_MESSAGE_NUM 5
/*登录阻塞时间(MS)*/
#define MAX_LOGIN_DURATION 5000
/*读取报文阻塞超时时间*/
#define MQTT_CMD_TIMEOUT_MS 5000
/*单次读取报文超时时间*/
#define SOCKET_READ_TIMEOUT_MS 200
/*BUFFER可接收最大报文长度*/
#define SDK_MAX_RECV_BUFFER_LEN 2000
/*BUFFER可发送最大报文长度*/
#define SDK_MAX_SEND_BUFFER_LEN 2000
/*BUFFER可接收最小报文长度*/
#define SDK_MIN_RECV_BUFFER_LEN 2000
/*BUFFER可发送最小报文长度*/
#define SDK_MIN_SEND_BUFFER_LEN 2000

#define TLINK_MAX_RETRANS 3
#define TLINK_MSG_RETRANS_TIMEOUT 3000

/*TLS*/
/*TLS双向认证*/
#define SSL_CERTIFICATE_DUAL
/*TLS单向认证*/
//#define SSL_CERTIFICATE_MONO
/*TLS加密通道*/
//#define SSL_CERTIFICATE_NONE

#if defined(USE_MBEDTLS)
#ifndef ca_crt
/*TLS 根证书路径*/
#define ca_crt "./root.cer"
#endif
#ifndef client_crt
/*TLS 客户端证书路径*/
#define client_crt "./clientpublic.cer"
#endif
#ifndef client_key
/*TLS 客户端私钥路径*/
#define client_key "./clientprivate.key"

#endif
#endif

/*LOG*/
/*LOG输出至文件*/
//#define FILE_PRINT
/*LOG输出文件目录*/
#define LOG_FILE_PATH_PREFIX "./"
/*LOG输出至控制台*/
#define SOUT_PRINT
/*LOG同时输出至文件与控制台*/
//#define FILE_AND_SOUT_PRINT
/*输出DEBUG信息*/
// #define ID_LEVEL_LOG_COMPILE
/*输出ERR级别LOG*/
#define ERR_LEVEL_LOG_COMPILE

//数据上报
#define USE_CTIOT_SEND_DATA
//透明传输上行
#define USE_CTIOT_TRANSPARENT_DATA_UL
//透明传输下行
#define USE_CTIOT_TRANSPARENT_DATA_DL
//数据获取
#define USE_CTIOT_RETRIEVEDATA
//指令下发
#define USE_CTIOT_CMD_EXCUTE
//事件上报
#define USE_CTIOT_EVENT_REPORT
//参数查询
#define USE_CTIOT_ENQUIREPARA_EXCUTE
//参数配置
#define USE_CTIOT_SETPARA_EXCUTE
//远程控制
#define USE_CTIOT_REMOTECTRL_EXCUTE
//小文件上传
#define USE_CTIOT_FILE_UPLOAD
