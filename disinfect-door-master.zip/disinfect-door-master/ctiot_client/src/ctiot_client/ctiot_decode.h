/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __CTIOT_DECODE_H
#define __CTIOT_DECODE_H

#include "ctiot_basetype.h"
#include "ctiot_message.h"
#include "ctiot_os.h"
#include "ctiot_log.h"
#include "ctiot_tlink.h"
typedef enum
{
    DC_SUCC,
    DC_FAIL
} T_DC_RESULT;

//**************************************************
//
//! @brief  登录信息解码
//!
//! @param [out]CTIOT_MQTT_MSG_LOGIN_REQ* ptrLogin，远程控制请求参数，见@ref CTIOT_MQTT_MSG_LOGIN_REQ
//! @param [in]ptrStream,接收到的数据流
//! @param [in]len,接收到的数据流长度
//! @retval  DC_FAIL,失败; DC_SUCC,成功
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_decode_login_confirm(CTIOT_MQTT_MSG_LOGIN_CNF *ptrRegCnf, SDK_U8 *ptrStream, SDK_U16 len);

#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
//**************************************************
//
//! @brief  透明传输下发数据解码功能
//!
//! @param CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND* dataInd
//! @param SDK_U8** stream
//! @param SDK_U16 len
//! @retval  出参说明，必选
//! @note   提示，可选
//
//**************************************************
CTIOT_STATUS ctiot_decode_downlink_transparent_data_request(CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND *dataInd, SDK_U8 *stream, SDK_U16 len);

//**************************************************
//
//! @brief  透明传输数据内存释放
//!
//! @param CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND*
//! @retval  出参说明，必选
//! @note   提示，可选
//
//**************************************************

CTIOT_STATUS ctiot_destruct_downlink_transparent_data_indication(CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND *);
#endif

#if defined(USE_CTIOT_CMD_EXCUTE)
//**************************************************
//
//! @brief 对指令下发进行解码
//!
//! @param ptrDataInd，解码后的数据
//! @param ptrStream，需要解码的数据
//! @param len，解码数据的长度
//! @retval CTIOT_STATUS
//
//**************************************************
CTIOT_STATUS ctiot_decode_execute_cmd_request(CTIOT_MQTT_EXECUTE_CMD_MSG *ptrDataInd, SDK_U8 *ptrStream, SDK_U16 len);
#endif

CTIOT_STATUS ctiot_decode(SDK_U8 *ptrStream, SDK_U16 len, CTIOT_DECODE_PARAMS *ptrDecodeParams, int startPos);

void ctiot_release_decode_buffer(CTIOT_DECODE_PARAMS param);

#endif
