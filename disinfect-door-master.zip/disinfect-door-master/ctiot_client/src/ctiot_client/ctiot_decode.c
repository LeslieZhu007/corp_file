/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include "ctiot_decode.h"

#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
CTIOT_STATUS ctiot_destruct_downlink_transparent_data_indication(CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND *ptrDataInd)
{
    CTIOT_STATUS ret = CTIOT_SUCCESS;
    OS_PUT_MEM(ptrDataInd->payload);
    return ret;
}

CTIOT_STATUS ctiot_decode_downlink_transparent_data_request(CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND *ptrDataInd, SDK_U8 *ptrStream, SDK_U16 len)
{
    CTIOT_STATUS ret = CTIOT_SUCCESS;
    SDK_U16 i = 0;
    SDK_U16 j = 0;
    SDK_U16 tempLen = 0;
    if (ptrDataInd == NULL)
    {
        ret = CTIOT_OS_NULL_POINTER;
        goto exit;
    }
    if (len < 11)
    {
        ret = CTIOT_TRANSPARENT_DATA_DL_DECODE_ERROR;
        goto exit;
    }
    //SDK_U32 dnPacketSN;
    ptrDataInd->dnPacketSN = ((ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0));
    j += 4;
    //SDK_U8 cmdType;
    ptrDataInd->cmdType = ptrStream[j];
    j++;
    if (ptrDataInd->cmdType != CMD_ID_DL_TR_DATA)
    {
        ret = CTIOT_TRANSPARENT_DATA_DL_DECODE_ERROR;
        goto exit;
    }
    //SDK_U32 dnTpDataSN;
    ptrDataInd->dnTpDataSN = ((ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0));
    j += 4;
    //SDK_U16   payloadLen;
    ptrDataInd->payloadLen = ((ptrStream[j] << 8) | (ptrStream[j + 1]));
    j += 2;
    //SDK_U8*  payload;
    if ((ptrDataInd->payloadLen > 0) && (ptrDataInd->payloadLen + 11) > len)
    {
        ret = CTIOT_TRANSPARENT_DATA_DL_DECODE_ERROR;
        goto exit;
    }
    OS_GET_MEM(ptrDataInd->payload, SDK_U8, ptrDataInd->payloadLen);
    if (ptrDataInd->payload == NULL || ptrDataInd->payloadLen == 0)
    {
        ret = CTIOT_OS_NOT_ENOUGH_MEM;
        goto exit;
    }
    for (i = 0; i < ptrDataInd->payloadLen; i++)
    {
        ptrDataInd->payload[i] = ptrStream[j];
        j++;
    }
    if (j != len)
    {
#ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Error:ctiot_decode_downlink_transparent_data_request,j[%u] != len[%u]\n", j, len);
#endif
    }
exit:
    return ret;
}
#endif

T_DC_RESULT ctiot_decode_login_request(CTIOT_MQTT_MSG_LOGIN_REQ *ptrLogin, SDK_U8 *ptrStream, SDK_U16 len)
{
    T_DC_RESULT ret = DC_SUCC;
    SDK_U16 i = 0;
    SDK_U16 j = 0;
    SDK_U16 tempLen = 0;
    /*SDK_U32 UpPacketSN;*/
    ptrLogin->upPacketSN = (ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0);
    j += 4;
    /*SDK_U8 cmdType;*/
    ptrLogin->cmdType = (ptrStream[j]);
    j++;
    /*SDK_U16 DASN;*/
    ptrLogin->dasn = (ptrStream[j] << 8) | (ptrStream[j + 1]);
    j += 2;
    /*SDK_U64 DeviceTimeStamp;*/
    ptrLogin->deviceTimeStamp = ((ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0));
    j += 4;
    ptrLogin->deviceTimeStamp = (ptrLogin->deviceTimeStamp << 32);
    ptrLogin->deviceTimeStamp |= ((ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0));
    j += 4;
    /*SDK_U8 NetworkType;*/
    ptrLogin->networkType = (ptrStream[j]);
    j++;
    /*SDK_U16 MQTTHBT;*/
    ptrLogin->mqttHbt = (ptrStream[j] << 8) | (ptrStream[j + 1]);
    j += 2;
    /*SDK_U8 SDKVersion[3]*/
    ptrLogin->sdkVersion[0] = (ptrStream[j]);
    j++;
    ptrLogin->sdkVersion[1] = (ptrStream[j]);
    j++;
    ptrLogin->sdkVersion[2] = (ptrStream[j]);
    j++;
    /*SDK_U8 SDKMode*/
    ptrLogin->sdkMode = (ptrStream[j]);
    j++;
    /*char* SoftVersion;*/
    tempLen = (ptrStream[j] << 8) | (ptrStream[j + 1]);
    j += 2;
    OS_GET_MEM(ptrLogin->softVersion, char, tempLen + 1);
    for (i = 0; i < tempLen; i++)
    {
        ptrLogin->softVersion[i] = (ptrStream[j]);
        j++;
    }
    ptrLogin->softVersion[i] = 0;
    /*char *DeviceInfo;*/
    tempLen = (ptrStream[j] << 8) | (ptrStream[j + 1]);
    j += 2;
    OS_GET_MEM(ptrLogin->deviceInfo, char, tempLen + 1);
    for (i = 0; i < tempLen; i++)
    {
        ptrLogin->deviceInfo[i] = (ptrStream[j]);
        j++;
    }
    ptrLogin->deviceInfo[i] = 0;
    if (j != len)
    {
#ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Error:ctiot_decode_login_request error,j[%u] != len[%u]\n", j, len);
#endif
    }
    return ret;
}

CTIOT_STATUS ctiot_decode_login_confirm(CTIOT_MQTT_MSG_LOGIN_CNF *ptrRegCnf, SDK_U8 *ptrStream, SDK_U16 len)
{
    CTIOT_STATUS ret = CTIOT_SUCCESS;
    SDK_U16 i = 0;
    SDK_U16 j = 0;
    SDK_U16 tempLen = 0;
    /*TBD:*/
    if (ptrRegCnf == NULL || ptrStream == NULL)
    {
        ret = CTIOT_OS_NULL_POINTER;
        goto exit;
    }
    if (len < 8)
    {
        ret = CTIOT_LOGIN_DECODE_ERROR;
        goto exit;
    }
    /*SDK_U32   dnPacketSN;*/
    ptrRegCnf->dnPacketSN = ((ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0));
    j += 4;
    /*SDK_U8    cmdType;*/
    ptrRegCnf->cmdType = ptrStream[j];
    j++;
    /*SDK_U16   DASN;*/ /*TBD:*/
    ptrRegCnf->dasn = (ptrStream[j] << 8) | (ptrStream[j + 1]);
    j += 2;
    /*SDK_U8    ResultCode;*/
    ptrRegCnf->resultCode = ptrStream[j];
    j++;
    if (ptrRegCnf->resultCode == 0)
    {
        /*SDK_U64   PlatformTimeStamp*/
        if (len < 20)
        {
            ret = CTIOT_LOGIN_DECODE_ERROR;
            goto exit;
        }
        ptrRegCnf->platformTimeStamp = ((ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0));
        j += 4;
        ptrRegCnf->platformTimeStamp = (ptrRegCnf->platformTimeStamp << 32);
        ptrRegCnf->platformTimeStamp |= (SDK_U32)((ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0));
        j += 4;

        /*SDK_U16    HeartBeatTimer;*/
        ptrRegCnf->heartBeatTimer = (ptrStream[j] << 8) | (ptrStream[j + 1] << 0);
        j += 2;
        /*char* RedirectServerIP;*/
        tempLen = (ptrStream[j] << 8) | (ptrStream[j + 1]);
        j += 2;
        if (len < (tempLen + 20))
        {
            ret = CTIOT_LOGIN_DECODE_ERROR;
            goto exit;
        }
        OS_GET_MEM(ptrRegCnf->redirectServerIP, char, tempLen + 1);
        if (ptrRegCnf->redirectServerIP == NULL)
        {
            ret = CTIOT_OS_NOT_ENOUGH_MEM;
            goto exit;
        }
        for (i = 0; i < tempLen; i++)
        {
            ptrRegCnf->redirectServerIP[i] = ptrStream[j];
            j++;
        }
        ptrRegCnf->redirectServerIP[i] = 0;
    }
    if (j != len)
    {
#ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Error:ctiot_decode_login_confirm error! j[%u] != len[%u]\n", j, len);
#endif
    }
exit:
    return ret;
}

T_DC_RESULT ctiot_dc_destruct_login_confirm(CTIOT_MQTT_MSG_LOGIN_CNF *ptrLogin)
{
    T_DC_RESULT ret = DC_SUCC;
    if (ptrLogin->redirectServerIP != NULL)
    {
        OS_PUT_MEM(ptrLogin->redirectServerIP);
    }
    return ret;
}


#if defined(USE_CTIOT_CMD_EXCUTE)
//**************************************************
////! @brief  指令下发内存销毁

//!
//! @param ptrDataInd,指令下发需要释放内存的数据
//! @retval  CTIOT_STATUS
//
//**************************************************
CTIOT_STATUS ctiot_destruct_exe_cmd_request(CTIOT_MQTT_EXECUTE_CMD_MSG *ptrDataInd)
{
    CTIOT_STATUS ret = CTIOT_SUCCESS;

    if (ptrDataInd->payloadType == 0)
    {
        OS_PUT_MEM(ptrDataInd->u.compact.payload);
    }
    else if (ptrDataInd->payloadType == 2)
    {
        OS_PUT_MEM(ptrDataInd->u.json.payload);
    }
    return ret;
}

CTIOT_STATUS ctiot_decode_execute_cmd_request(CTIOT_MQTT_EXECUTE_CMD_MSG *ptrDataInd, SDK_U8 *ptrStream, SDK_U16 len)
{
    CTIOT_STATUS ret = CTIOT_SUCCESS;
    SDK_U16 i = 0;
    SDK_U16 j = 0;
    SDK_U16 tempLen = 0;
    if (len <= 14)
    {
        ret = CTIOT_CMD_DECODE_REQ_PAYLOAD_LEN_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "CMD request payload length error!\n");
#endif
        goto exit;
    }
    //SDK_U32 DnPacketSN;
    ptrDataInd->dnPacketSN = (ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0);
    j += 4;
    //SDK_U8 CmdType;
    ptrDataInd->cmdType = (ptrStream[j]);
    j++;
    if (ptrDataInd->cmdType != CMD_ID_EXECUTE_CMD_REQ)
    {
        ret = CTIOT_CMD_CMDTYPE_REQ_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "CMD request cmdType error!\n");
#endif
        goto exit;
    }
    //SDK_U32 CmdSN;
    ptrDataInd->cmdSN = (ptrStream[j] << 24) | (ptrStream[j + 1] << 16) | (ptrStream[j + 2] << 8) | (ptrStream[j + 3] << 0);
    j += 4;
    //SDK_U8 PayloadType;
    ptrDataInd->payloadType = (ptrStream[j]);
    j++;
    //union
    //{
    //CTIOT_MQTT_MSG_COMPACT_ELE compact;
    if (ptrDataInd->payloadType == 0)
    {
        //SDK_U16 DatasetID;
        ptrDataInd->u.compact.datasetID = (ptrStream[j] << 8) | (ptrStream[j + 1] << 0);
        j += 2;
        //SDK_U16 PayloadLen;
        ptrDataInd->u.compact.payloadLen = (ptrStream[j] << 8) | (ptrStream[j + 1] << 0);
        j += 2;
        if ((len - 14) != ptrDataInd->u.compact.payloadLen)
        {
            ret = CTIOT_CMD_DECODE_REQ_PAYLOAD_LEN_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
            log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Compact payload length error!\n");
#endif
            goto exit;
        }
        //SDK_U8* Payload;
        OS_GET_MEM(ptrDataInd->u.compact.payload, SDK_U8, ptrDataInd->u.compact.payloadLen + 1);
        if (ptrDataInd->u.compact.payload == NULL)
        {
            ret = CTIOT_CMD_DECODE_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
            log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Compact payload get mem fail!\n");
#endif
            goto exit;
        }
        memcpy(ptrDataInd->u.compact.payload, &ptrStream[j], ptrDataInd->u.compact.payloadLen);
        ptrDataInd->u.compact.payload[ptrDataInd->u.compact.payloadLen] = '\0';
        j += ptrDataInd->u.compact.payloadLen;
    }
    //CTIOT_MQTT_MSG_JSON_ELE json;
    else if (ptrDataInd->payloadType == 2)
    {
        //char* DatasetName;
        ptrDataInd->u.json.u.datasetID = (ptrStream[j] << 8) | ptrStream[j + 1];
        j += 2;
        //char* Payload;
        tempLen = (ptrStream[j] << 8) | (ptrStream[j + 1] << 0);
        j += 2;
        if ((len - 14) != tempLen)
        {
            ret = CTIOT_CMD_DECODE_REQ_PAYLOAD_LEN_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
            log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Json payload length error!\n");
#endif
            goto exit;
        }
        OS_GET_MEM(ptrDataInd->u.json.payload, char, tempLen + 1);
        if (ptrDataInd->u.json.payload == NULL)
        {
            ret = CTIOT_CMD_DECODE_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
            log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Json payload get mem fail!\n");
#endif
            goto exit;
        }
        memcpy(ptrDataInd->u.json.payload, &ptrStream[j], tempLen);
        ptrDataInd->u.json.payload[tempLen] = '\0';
        j += tempLen;
    }
    else
    {
        ret = CTIOT_CMD_DECODE_PLAYLOAD_TYPE_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Payload type is unkown!\n");
#endif
        goto exit;
    }
    //}u;
    if (j != len)
    {
        ret = CTIOT_CMD_DECODE_ERROR;
#ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE,
                  "decode execute cmd request is fail , j[%u] != length[%u]\n", j, len);
#endif
    }
exit:
    return ret;
}
#endif

//**************************************************
//
//! @brief  数据解码公用程序
//!
//! @param ptrStream,需解码的数据流
//! @param len,需解码的数据流长度
//! @param ptrDecodeParams,数据结构，输出内容定义，返回输出结果
//! @param startPos,解码数据在数据流中的起始位置
//! @retval  CTIOT_STATUS
//
//**************************************************
CTIOT_STATUS ctiot_decode(SDK_U8 *ptrStream, SDK_U16 len, CTIOT_DECODE_PARAMS *ptrDecodeParams, int startPos)
{
    int i = 0;
    CTIOT_STATUS ret = CTIOT_SUCCESS;
    int aa;
    int jj = startPos;
    for (i; i < ptrDecodeParams->ctiot_param_counts; i++)
    {
        switch (ptrDecodeParams->ctiot_decode_params[i].ctiot_param_type)
        {
        case CTIOT_PARAM_TYPE_DIGIT:
        {
            if (len < (startPos + ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len))
            {
                ret = CTIOT_INVALID_PARAM_LEN;
                goto exit;
            }
            if (ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len == 1)
            {
                ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u8value = ptrStream[jj];
                //printf("ctiot_decode_u8:%d\n",ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u8value);
                jj++;
            }
            else if (ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len == 2)
            {
                ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u16value = (SDK_U16)((ptrStream[jj] << 8) | (ptrStream[jj + 1]) << 0);
                //printf("ctiot_decode_u16:%d\n",ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u16value);
                jj += 2;
            }
            else if (ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len == 4)
            {
                ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u32value = (SDK_U32)((ptrStream[jj] << 24) | (ptrStream[jj + 1]) << 16 | (ptrStream[jj + 2] << 8) | (ptrStream[jj + 3]) << 0);
                //printf("ctiot_decode_u32:%d\n",ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u32value);
                jj += 4;
            }
            else if (ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len == 8)
            {
                SDK_U64 tmpvalue = (SDK_U32)((ptrStream[jj] << 24) | (ptrStream[jj + 1]) << 16 | (ptrStream[jj + 2] << 8) | (ptrStream[jj + 3]) << 0);
                jj += 4;
                ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u64value = (SDK_U32)((ptrStream[jj] << 24) | (ptrStream[jj + 1]) << 16 | (ptrStream[jj + 2] << 8) | (ptrStream[jj + 3]) << 0);
                jj += 4;
                ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u64value |= (SDK_U64)(tmpvalue << 32);
                //printf("ctiot_decode_u64:%l\n",ptrDecodeParams->ctiot_decode_params[i].u.ctiot_u64value);
            }
            break;
        }
        case CTIOT_PARAM_TYPE_BINARY:
        case CTIOT_PARAM_TYPE_TEXT:
        {
            if (len < jj + 2)
            {
                ret = CTIOT_INVALID_PARAM_LEN;
                goto exit;
            }
            SDK_U16 tmplen = (SDK_U16)((ptrStream[jj] << 8) | (ptrStream[jj + 1]) << 0);
            //printf("len:%d\n",tmplen);
            jj += 2;
            ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len = tmplen;
            if (len < jj + tmplen)
            {
                ret = CTIOT_INVALID_PARAM_LEN;
                goto exit;
            }
            if (tmplen > 0)
            {
                OS_GET_MEM(ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content, char, tmplen + 1);
                if (ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content == NULL)
                {
                    ret = CTIOT_BUFFER_OVERFLOW;
                    goto exit;
                }
                for (aa = 0; aa < tmplen; aa++)
                {
                    ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content[aa] = ptrStream[jj + aa];
                    //printf("%d ",ptrStream[jj+aa]);
                }
                ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content[aa] = '\0';
            }
            jj += tmplen;
            //printf("\n");
            break;
        }
        case CTIOT_PARAM_TYPE_BINARY_STATIC:
        case CTIOT_PARAM_TYPE_TEXT_STATIC:
        {
            if (len < jj + ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len)
            {
                ret = CTIOT_INVALID_PARAM_LEN;
                goto exit;
            }
            OS_GET_MEM(ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content, char, ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len);
            if (ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content == NULL)
            {
                ret = CTIOT_BUFFER_OVERFLOW;
                goto exit;
            }
            for (aa = 0; aa < ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len; aa++)
            {
                ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content[aa] = ptrStream[jj + aa];
                //printf("%d ",ptrStream[jj+aa]);
            }
            jj += ptrDecodeParams->ctiot_decode_params[i].ctiot_param_len;
            //printf("\n");
            break;
        }
        default:
            break;
        }
    }
exit:
    if (i > 0 && ret != CTIOT_SUCCESS)
    {
        int j = 0;
        while (j < i)
        {
            if (ptrDecodeParams->ctiot_decode_params[j].ctiot_param_type != CTIOT_PARAM_TYPE_DIGIT)
            {
                if (ptrDecodeParams->ctiot_decode_params[j].u.ctiot_content != NULL)
                {
                    OS_PUT_MEM(ptrDecodeParams->ctiot_decode_params[i].u.ctiot_content);
                }
            }
            j++;
        }
    }
    return ret;
}
//**************************************************
//
//! @brief 释放解码时分配的内存
//! @param ptrDecodeParams,需释放内存的解码后的数据
//! @retval  无
//
//**************************************************
void ctiot_release_decode_buffer(CTIOT_DECODE_PARAMS param)
{
    int i = 0;
    while (i < param.ctiot_param_counts)
    {
        if (param.ctiot_decode_params[i].ctiot_param_type != CTIOT_PARAM_TYPE_DIGIT)
        {
            if (param.ctiot_decode_params[i].u.ctiot_content != NULL)
            {
                OS_PUT_MEM(param.ctiot_decode_params[i].u.ctiot_content);
            }
        }
        i++;
    }
}

