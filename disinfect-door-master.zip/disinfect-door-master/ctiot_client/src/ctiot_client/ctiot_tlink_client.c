/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/

#include <stdio.h>
#include <time.h>
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_message.h"
#include "MQTTClient.h"
#include "ctiot_tlink_queue.h"
#include "ctiot_tlink_client.h"
#include "ctiot_msg_print.h"
#include "ctiot_log.h"
#include "ctiot_decode.h"
#include "ctiot_encode.h"
#ifdef SM9
#include <string.h>
#include "gmibc.h"
#include "pbc/pbc_algid.h"
#include "oldapi.h"
#include "sign.h"
#endif
enum client_state
{
	CLIENT_IDLE,
	LINK_SETUP,
	IN_WORK,
	QUIT_WORK
};
enum client_state tastCreateEnd = CLIENT_IDLE;

#ifdef OS_FREERTOS_CT
#include <FreeRTOS.h>
#include <task.h>
#include "semphr.h"
#include "wm_include.h"
#include "wm_rtc.h"
#define OS_SLEEP_TIME 500
#define CLIENT_TASK_STACKSZ ((4 * 1024 + 512) / sizeof(portSTACK_TYPE))
#define CLIENT_TASK_PRIO (tskIDLE_PRIORITY + 40)
static OS_STK ClientTaskStk[CLIENT_TASK_STACKSZ];
#else
#define OS_SLEEP_TIME 500
#endif //OS_FREERTOS_CT

#define assert(A, C, B, D)            \
	{                                 \
		if (C)                        \
		{                             \
			PRINT_STRING(A);          \
			PRINT_STRING("\n");       \
			PRINT_STRING(B, D);       \
			PRINT_STRING("\n");       \
		}                             \
		else                          \
		{                             \
			PRINT_STRING(A);          \
			PRINT_STRING(" fail!\n"); \
		}                             \
	}
CTIOT_MQTT_LOGIN_REQ loginPara = {0};

#define TLINKVER_1 1
#define TLINKVER_2 0

#define PROTOCOL_TYPE 1
#define PRIMARY_VERSION 0
#define SECONDARY_VERSION 0
#ifndef AT_MODE
#define SDK_MODE 1
#else
#define SDK_MODE 2
#endif

T_RDAP_QUEUE tlinkQueue = {0};

SDK_U16 globalCommandTimeout = 0;	       /*ms*/
SDK_U16 globalRreadSocketPeriod = 0;       /*ms*/
SDK_U16 globalRegLoginDuration = 0;        /*ms*/
SDK_U16 globalMaxPduLenSent = 0;	       /*Byte*/
SDK_U16 globalMaxPduLenRecv = 0;	       /*Byte*/
SDK_U32 globalQOSMsgRetransTimeout = 0;    /*ms*/
SDK_U16 globalMaxQueueLen = 0;             //最大队列长度
SDK_U8  globalMaxProcessMessageNum = 0;    //单次处理消息数目
SDK_U8  globalPingTimes = 0;               //心跳包文重发次数
SDK_U8  globalQOSMaxRetrans = 0;           //QOS1最大重传次数

char globalHostIP[20] = {0};
SDK_U16 globalHostPort;
SDK_U16 globalHbtLength = 0;
char globalDeviceId[65] = {0};
SDK_U64 globalPlatformTimestamp = 0;
char globalRedirectIP[20] = {0};
CTIOT_STATUS globalLastError = CTIOT_SUCCESS;
SDK_U8 globalRunThread = 0;

#if !defined(OS_FREERTOS_CT)
pthread_t globalLoopTid;
#else
tls_os_task_t globalLoopTid;
#endif

CTIOT_GLOBAL_INFO globalInfo;


#define SDK_MQTT_VERSION 4

typedef SDK_U32 CTIOT_MQTT_PACKET_SN;
CTIOT_MQTT_PACKET_SN ctiotUpPacketSn = 0;
typedef SDK_U16 CTIOT_MQTT_DASN;
CTIOT_MQTT_DASN ctiotDasn = 0;
typedef SDK_U32 T_SDK_PACKET_SN;
T_SDK_PACKET_SN sdk_upPacketSn = 0;
T_SDK_PACKET_SN sdk_dnPacketSn = 0;

CTIOT_MQTT_DOWNLINK_TRANSPARENT_DATA_RECV_API ctiot_downlink_transparent_data_callback = NULL;
CTIOT_MQTT_REMOTE_CTRL_REQ_API ctiot_remote_control_callback = NULL;
CTIOT_MQTT_EXECUTE_CMD_REQ_API ctiot_execute_cmd_callback = NULL;
CTIOT_MQTT_LOST_CONNECTION_IND_API ctiot_lost_connection_ind_callback = NULL;
CTIOT_MQTT_PARA_ENQUIRE_REQ_API ctiot_para_enquire_request_callback = NULL;
CTIOT_MQTT_SET_PARA_REQ_API ctiot_set_para_request_callback = NULL;
CTIOT_MQTT_RETRIEVE_DATA_REQ_API ctiot_retrieve_data_callback = NULL;
CTIOT_TLINK_MSG_STATUS_API ctiot_msg_status_callback = NULL;
CTIOT_TLINK_FILE_UPLOAD_API ctiot_file_upload_callback = NULL;

SDK_U8 *writebuf = NULL;
SDK_U8 *readbuf = NULL;

MQTTMessage pubmsg;
T_SDK_STATE state;
MQTTClient c;
Network n;
CTIOT_STATUS finish;
#define MIN_HEARTBEAT_TIME 0
#define MAX_HEARTBEAT_TIME 65535

TLINK_CLIENT tlinkClient;
SDK_U16 ctiot_get_command_timeout();
void ctiot_set_command_timeout(SDK_U16 commandTimeout);
SDK_U16 ctiot_get_read_socket_period();
void ctiot_set_read_socket_period(SDK_U16 readSocketPeriod);
SDK_U16 ctiot_get_register_login_duration();
void ctiot_set_register_login_duration(SDK_U16 regLoginDuration);
SDK_U16 ctiot_get_max_pdu_len_sent();
void ctiot_set_max_pdu_len_sent(SDK_U16 maxPduLenSent);
SDK_U16 ctiot_get_max_pdu_len_recv();
CTIOT_STATUS ctiot_create_socket_buff();
void ctiot_release_socket_buff();
CTIOT_STATUS ctiot_realloc_socket_buff();

void ctiot_update_mqtt_heartbeat_time(MQTTClient *c, SDK_U16 timeOfHeartbeat /*以秒为单位*/)
{
	if (timeOfHeartbeat >= MIN_HEARTBEAT_TIME && timeOfHeartbeat <= MAX_HEARTBEAT_TIME)
	{
		c->keepAliveInterval = (timeOfHeartbeat);
	}
	else if (timeOfHeartbeat < MIN_HEARTBEAT_TIME)
	{
		c->keepAliveInterval = (MIN_HEARTBEAT_TIME);
	}
	else
	{
		c->keepAliveInterval = (MAX_HEARTBEAT_TIME);
	}
}
CTIOT_PARAMS all_params[] = {
	{10, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 8}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY_STATIC, 3}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_TEXT, 0}, {CTIOT_PARAM_TYPE_TEXT, 0}}},
	{2, {{CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_BINARY, 0}}},
	{6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, 0}}},
	{7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, 0}, {CTIOT_PARAM_TYPE_BINARY, 0}}},
	{4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_BINARY, 0}}},
	{6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_BINARY, 0}}},
	{5, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 1}}},
	{7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, 0}}}};

CTIOT_PARAMS ctiot_get_all_params(SDK_U8 param_operation)
{
	if (param_operation >= 7)
		return (CTIOT_PARAMS){0, {{0, 0}}};
	CTIOT_PARAMS result = (CTIOT_PARAMS)all_params[param_operation];
	return result;
}

CTIOT_MQTT_PACKET_SN ctiot_generate_packet_sn()
{
	ctiotUpPacketSn++;
#ifdef ID_LEVEL_LOG_COMPILE
	log_print(INFO_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_generate_packet_sn:%u\n", ctiotUpPacketSn);
#endif
	return ctiotUpPacketSn;
}
CTIOT_MQTT_DASN ctiot_generate_dasn_sn()
{
	ctiotDasn++;
#ifdef ID_LEVEL_LOG_COMPILE
	log_print(INFO_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_generate_dasn_sn:%u\n", ctiotDasn);
#endif
	return ctiotDasn;
}

void ctiot_set_status(T_SDK_STATE newState)
{
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("State %u -> %u\n", state, newState);
#endif
	state = newState;
}

T_SDK_STATE ctiot_get_status()
{
	return state;
}
CTIOT_STATUS ctiot_mqtt_connection(char *clientID, char *username, char *password)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	int rc = 0;
	MQTTConnackData connackData;
	MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
	NetworkInit(&n);
	if ((rc = NetworkConnect(&n, globalHostIP, globalHostPort)) != 0)
	{
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_plain_text("ctiot_mqtt_connection:NetworkConnect fail,please confirm server Ip:%s,Port:%u\n", globalHostIP, globalHostPort);
#endif	
		if(rc == CTIOT_TLS_ROOT_CERTIFICATE_ERROR || rc == CTIOT_TLS_CLIENT_CERTIFICATE_ERROR || rc == CTIOT_TLS_CLIENT_KEY_ERROR || rc == CTIOT_TLS_HANDSHAKE_ERROR)
		{
			return rc;
		}
		return CTIOT_OS_SOCK_CONNECT_FAIL;
	}
	MQTTClientInit(&c, &n, ctiot_get_command_timeout(), writebuf, ctiot_get_max_pdu_len_sent(), readbuf, ctiot_get_max_pdu_len_recv(), ctiot_tlink_handlemessage);
	data.willFlag = 1;
	data.MQTTVersion = SDK_MQTT_VERSION;
	data.clientID.cstring = clientID;
	data.username.cstring = username;
	data.password.cstring = password;
	data.keepAliveInterval = globalHbtLength;
	if (ctiot_get_status() == RDAP_STATE_DETACHED)
	{
		data.cleansession = 1;
	}
	else
	{
		data.cleansession = 0;
	}
	data.will.message.cstring = "i will leave";
	data.will.qos = QOS0;
	data.will.retained = 1;
	data.will.topicName.cstring = "will topic";

	rc = MQTTConnectWithResults(&c, &data, &connackData);
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("ctiot_mqtt_connection:get message from connection server; rc was %d\n", rc);
#endif
	if (rc != MQTT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_mqtt_connection:MQTTConnectWithResults fail,please confirm server Ip:%s,Port:%u\n", globalHostIP, globalHostPort);
#endif
		ret = CTIOT_MQTT_CONNECT_FAIL;
		MQTTCleanSession(&c);
		NetworkDisconnect(&n);
	}

	return ret;
}

CTIOT_STATUS ctiot_initial_request(CTIOT_MQTT_INIT_REQ *ptrInfo)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if( ctiot_get_status() == RDAP_STATE_LOGINED ||  ctiot_get_status() == RDAP_STATE_BEFORE_LOGIN)
	{
		return CTIOT_INIT_FAIL;
	}
	if (ptrInfo->commandTimeout == 0)
	{
		ptrInfo->commandTimeout = ctiot_get_command_timeout();
	}
	if (ptrInfo->readSocketPeriod == 0)
	{
		ptrInfo->readSocketPeriod = ctiot_get_read_socket_period();
	}
	if (ptrInfo->regLoginDuration == 0)
	{
		ptrInfo->regLoginDuration = ctiot_get_register_login_duration();
	}
	if (ptrInfo->maxPayloadLenSent == 0)
	{
		ptrInfo->maxPayloadLenSent = ctiot_get_max_pdu_len_sent();
	}
	if (ptrInfo->maxPayloadLenRecv == 0)
	{
		ptrInfo->maxPayloadLenRecv = ctiot_get_max_pdu_len_recv();
	}
	if (ptrInfo->maxQueueLen == 0)
	{
		ptrInfo->maxQueueLen = MAX_QUEUE_LEN;
	}
	if (ptrInfo->maxProcessMessageNum == 0)
	{
		ptrInfo->maxProcessMessageNum = MAX_PROCESS_MESSAGE_NUM;
	}
	if (ptrInfo->pingTimes == 0)
	{
		ptrInfo->pingTimes = PING_TIMES;
	}
	if (ptrInfo->QOSMaxRetrans == 0)
	{
		ptrInfo->QOSMaxRetrans = TLINK_MAX_RETRANS;
	}
	if (ptrInfo->QOSMsgRetransTimeout == 0)
	{
		ptrInfo->QOSMsgRetransTimeout = TLINK_MSG_RETRANS_TIMEOUT;
	}
	n.connect_mode = ptrInfo->connectMode;
#ifdef OS_FREERTOS_CT
	int now = tls_os_get_time();
#else
	time_t now;
	time(&now);
	srand(now);
#endif
	/*Part1:Call terminal API to save terminal attributes*/
	memcpy(globalHostIP, ptrInfo->hostIp, strlen(ptrInfo->hostIp));
	globalHostIP[strlen(ptrInfo->hostIp)] = 0;
	globalHostPort = ptrInfo->hostPort;
	globalCommandTimeout = ptrInfo->commandTimeout;
	globalRreadSocketPeriod = ptrInfo->readSocketPeriod;
	globalRegLoginDuration = ptrInfo->regLoginDuration;
	globalMaxPduLenRecv = ptrInfo->maxPayloadLenRecv;
	globalMaxPduLenSent = ptrInfo->maxPayloadLenSent;
	globalQOSMsgRetransTimeout = ptrInfo->QOSMsgRetransTimeout;  
	globalMaxQueueLen = ptrInfo->maxQueueLen;             
	globalMaxProcessMessageNum = ptrInfo->maxProcessMessageNum;  
	globalPingTimes = ptrInfo->pingTimes;            
	globalQOSMaxRetrans = ptrInfo->QOSMaxRetrans;        
	if (globalCommandTimeout < globalRreadSocketPeriod)
	{
		globalCommandTimeout = globalRreadSocketPeriod;
	}

	ret = ctiot_create_socket_buff();
	if (ret != CTIOT_SUCCESS)
	{
		goto exit;
	}
	/*Part2: save call backs*/
	ctiot_downlink_transparent_data_callback = ptrInfo->downlinkTransparentDataCallback;
	ctiot_execute_cmd_callback = ptrInfo->executeCmdCallback;
	ctiot_remote_control_callback = ptrInfo->remoteControlCallback;
	ctiot_lost_connection_ind_callback = ptrInfo->lostConnToServer;
	ctiot_para_enquire_request_callback = ptrInfo->paraEnquireCallback;
	ctiot_set_para_request_callback = ptrInfo->setParaCallback;
	ctiot_retrieve_data_callback = ptrInfo->retrieveDataCallback;
	ctiot_msg_status_callback = ptrInfo->msgStatusCallback;
	ctiot_file_upload_callback = ptrInfo->fileUploadCallback;

	ctiotUpPacketSn = (SDK_U32)rand();
	ctiotDasn = (SDK_U16)rand() % 65536;
	ctiot_set_status(RDAP_STATE_INITIALIZED);
exit:
	return ret;
}

#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
//**************************************************
//
//! @brief  透明传输下行数据到达
//!
//! @param MessageData * ptrMD
//!
//! @retval  出参说明，必选
//! @note   提示，可选
//
//**************************************************
void ctiot_downlink_transparent_data_arrived(MessageData *ptrMD)
{
	CTIOT_STATUS result = ctiot_validate_mqtt_message(ptrMD);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_downlink_transparent_data_arrived: validate message error!\n:result=%d\n", result);
#endif
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	MQTTMessage *m = ptrMD->message;
	CTIOT_MQTT_MSG_RECV_TRANSPARENT_DATA_IND dlTransparentData = {0};
	CTIOT_MQTT_DL_TRANSPARENT_DATA_RECV revTransparentData = {0};
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Transparent data arrived:\n");
	log_print_array(m->payload, m->payloadlen);
	log_print_mark_end();
#endif
	/*Parase message*/
	result = ctiot_decode_downlink_transparent_data_request(&dlTransparentData, m->payload, m->payloadlen);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_downlink_transparent_data_arrived:ctiot_decode_downlink_transparent_data_request:result=%d\n", result);
#endif
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Decode transparent data arrived:\n");
	ctiot_print_receive_downlink_transparent_data(&dlTransparentData);
	log_print_mark_end();
#endif
	/*Send to user*/
	if (ctiot_downlink_transparent_data_callback != NULL)
	{
		revTransparentData.dnTpDataSN = dlTransparentData.dnTpDataSN;
		revTransparentData.length = dlTransparentData.payloadLen;
		revTransparentData.payload = dlTransparentData.payload;
		ctiot_downlink_transparent_data_callback(&revTransparentData);
	}
	else
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "Callback for downlink_transparent_data_arrived is NULL!\n");
#endif
	}
	ctiot_destruct_downlink_transparent_data_indication(&dlTransparentData);
exit:
	return;
}
#endif

#if defined(USE_CTIOT_CMD_EXCUTE)
CTIOT_STATUS ctiot_execute_cmd_cnf_validation(CTIOT_MQTT_EXECUTE_CMD_CNF *ptrPara)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ptrPara->resultCode != 0 && ptrPara->resultCode != 1 && ptrPara->resultCode != 2 && ptrPara->resultCode != 3 && ptrPara->resultCode != 4)
	{
		return CTIOT_CMD_CNF_INVALIDE_RESULT;
	}
	if (ptrPara->resultCode == 0 || ptrPara->resultCode == 1)
	{
		if (ptrPara->u.compact.payload != NULL || ptrPara->u.json.payload != NULL)
		{
			if (ptrPara->payloadType == 0)
			{
				if (ptrPara->u.compact.payload == NULL || ptrPara->u.compact.payloadLen == 0)
				{
					ret = CTIOT_CMD_CNF_INVALIDE_PAYLOAD;
#ifdef ERR_LEVEL_LOG_COMPILE
					log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE,
							  "ctiot_execute_cmd_cnf_validation compact cnf data is error!\n");
#endif
					ctiot_set_last_error(&globalLastError, CTIOT_CMD_CNF_INVALIDE_PAYLOAD);
					goto exit;
				}
			}
			else if (ptrPara->payloadType == 2)
			{
				if (ptrPara->u.json.payload == NULL || strlen(ptrPara->u.json.payload) == 0 )
				{
					ret = CTIOT_CMD_CNF_INVALIDE_PAYLOAD;
#ifdef ERR_LEVEL_LOG_COMPILE
					log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE,
							  "ctiot_execute_cmd_cnf_validation json cnf data is error!\n");
#endif
					ctiot_set_last_error(&globalLastError, CTIOT_CMD_CNF_INVALIDE_PAYLOAD);
					goto exit;
				}
			}
			else
			{
				ret = CTIOT_CMD_CNF_INVALIDE_PAYLOADTYPE;
#ifdef ERR_LEVEL_LOG_COMPILE
				log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE,
						  "ctiot_execute_cmd_cnf_validation cnf payload type is error!\n");
#endif
				ctiot_set_last_error(&globalLastError, CTIOT_CMD_CNF_INVALIDE_PAYLOADTYPE);
				goto exit;
			}
		}
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_execute_cmd_cnf_response(CTIOT_MQTT_EXECUTE_CMD_CNF *ptrPara, SDK_U32 *msgID)
{
	CTIOT_STATUS result = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		result = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return result;
	}
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;
	//CTIOT_MQTT_MSG_EXECUTE_CMD_CNF cmdCnf = {0};
	//1.validation
	result = ctiot_execute_cmd_cnf_validation(ptrPara);
	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}

	//2.encode
	//  result = ctiot_encode_execute_cmd_cnf(&cmdCnf, &stream, &len);
	CTIOT_PARAMS updata_params;
	SDK_U32 updata_sn = ctiot_generate_packet_sn();
	if (ptrPara->payloadType == COMPACT_MODE)
	{
		if (ptrPara->u.compact.payload == NULL)
		{
			updata_params = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
			result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_EXECUTE_CMD_CNF, ptrPara->cmdSN, ptrPara->resultCode);
		}
		else
		{
			updata_params = (CTIOT_PARAMS){7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, ptrPara->u.compact.payloadLen}}};
			result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_EXECUTE_CMD_CNF, ptrPara->cmdSN, ptrPara->resultCode, 0, ptrPara->u.compact.datasetID, ptrPara->u.compact.payload);
		}
	}
	else if (ptrPara->payloadType == JSON_MODE)
	{
		if (ptrPara->u.json.payload == NULL)
		{
			updata_params = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
			result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_EXECUTE_CMD_CNF, ptrPara->cmdSN, ptrPara->resultCode);
		}
		else
		{
			updata_params = (CTIOT_PARAMS){7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, strlen(ptrPara->u.json.payload)}}};
			result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_EXECUTE_CMD_CNF, ptrPara->cmdSN, ptrPara->resultCode, 2, ptrPara->u.json.u.datasetID, ptrPara->u.json.payload);
		}
	}
	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Encode execute cmd data,length:%u\n", len);
	log_print_array(stream, len);
	log_print_mark_end();
#endif
	result = ctiot_tlink_publish_request(len, stream, TOPIC_EXECUTE_CMD_CNF, ptrPara->qos, msgID);
	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
	}
exit:
	OS_PUT_MEM(stream);
	return result;
}

CTIOT_STATUS ctiot_send_execute_cmd_cnf(SDK_U8 payloadType, SDK_U32 cmdSN, SDK_U8 resultCode, SDK_U16 datasetID,
										SDK_U8 *payload, SDK_U16 payloadLen, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_EXECUTE_CMD_CNF cnf = {0};
	cnf.qos = QOS_EXECUTE_CMD_CNF;
	cnf.cmdSN = cmdSN;
	cnf.resultCode = resultCode;
	cnf.payloadType = payloadType;
	if (payloadType == 0)
	{
		cnf.u.compact.datasetID = datasetID;
		cnf.u.compact.payloadLen = payloadLen;
		cnf.u.compact.payload = payload;
	}
	else
	{
		cnf.u.json.u.datasetID = datasetID;
		cnf.u.json.payload = payload;
	}
	ret = ctiot_execute_cmd_cnf_response(&cnf, msgID);
	return ret;
}

//**************************************************
//
//! @brief  指令下发回调
//!
//! @param MessageData* ptrMd,下发的数据
//! @retval none
//
//**************************************************
void ctiot_execute_cmd_arrived(MessageData *ptrMd)
{
	CTIOT_MQTT_EXECUTE_CMD_MSG exeCmd = {0};
	CTIOT_MQTT_EXECUTE_CMD_REQUEST appItf = {0};
	//1.validation
	CTIOT_STATUS result = ctiot_validate_mqtt_message(ptrMd);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE,
				  "ctiot_execute_cmd_arrived: validate message error!\n:result=%d\n", result);
#endif
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	MQTTMessage *m = ptrMd->message;
#ifdef ID_LEVEL_LOG_COMPILE
	log_print(INFO_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "\n");
	log_print_mark_begin();
	log_print_plain_text("SDK receive ctiot_execute_cmd_arrived,Length:%u\n", m->payloadlen);
	log_print_array(m->payload, m->payloadlen);
	log_print_mark_end();
	log_print(INFO_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "\n");
#endif
	//2.validation and decode
	result = ctiot_decode_execute_cmd_request(&exeCmd, m->payload, m->payloadlen);
	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	ctiot_print_execute_cmd_request(&exeCmd);
	log_print_mark_end();
#endif
	if (ctiot_execute_cmd_callback != NULL)
	{
		appItf.cmdSN = exeCmd.cmdSN;
		appItf.payloadType = exeCmd.payloadType;
		if (appItf.payloadType == 0)
		{
			appItf.u.compact.datasetID = exeCmd.u.compact.datasetID;
			appItf.u.compact.payloadLen = exeCmd.u.compact.payloadLen;
			appItf.u.compact.payload = exeCmd.u.compact.payload;
		}
		else
		{
			appItf.u.json.u.datasetID = exeCmd.u.json.u.datasetID;
			appItf.u.json.payload = exeCmd.u.json.payload;
		}
		ctiot_execute_cmd_callback(&appItf);
	}
	else
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "callback ctiot_execute_cmd_arrived is NULL\n");
#endif
	}
exit:
	ctiot_destruct_exe_cmd_request(&exeCmd);
	return;
}
#endif


#if defined(USE_CTIOT_RETRIEVEDATA)
CTIOT_STATUS send_retrieve_data_cnf(SDK_U32 gdsn, SDK_U8 resultCode, SDK_U16 payloadType, SDK_U16 datasetID, SDK_U16 dataCollectResultLen, SDK_U8 *dataCollectResult, SDK_U16 payloadLen, SDK_U8 *payload, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		ret = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return ret;
	}
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;
	int i;
	SDK_U32 upDataSn = ctiot_generate_packet_sn();
	SDK_U8 cmdType = CMD_ID_RETRIEVE_DATA_CNF;
	SDK_U8 qos = QOS_RETRIEVE_DATA_CNF;
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("cmdType:%hhu\n", cmdType);
	log_print_plain_text("gdsn:%u\n", gdsn);
	log_print_plain_text("resultCode:%hhu\n", resultCode);
	if (resultCode == 0)
	{
		log_print_plain_text("payloadType:%d\n", payloadType);
		log_print_plain_text("payloadLen:%hu\n", payloadLen);
		if (payloadType == 0)
		{
			log_print_plain_text("payload:");
			for (i = 0; i < payloadLen; i++)
				log_print_plain_text("%02x", payload[i]);
			log_print_plain_text("\n");
		}
		else if (payloadType == 1)
		{
			log_print_plain_text("payloadType:%d\n", payloadType);
			log_print_plain_text("dataCollectResultLen:%hu\n", dataCollectResultLen);
			log_print_plain_text("dataCollectResult:");
			for (i = 0; i < dataCollectResultLen; i++)
				log_print_plain_text("%02x", dataCollectResult[i]);
			log_print_plain_text("\n");

			log_print_plain_text("payloadLen:%hu\n", payloadLen);
			log_print_plain_text("payload:");
			for (i = 0; i < payloadLen; i++)
				log_print_plain_text("%02x", payload[i]);
			log_print_plain_text("\n");
		}
		else
		{
			log_print_plain_text("payload:%s\n", payload);
		}
	}
#endif
	//1.validate data
	CTIOT_STATUS result = ctiot_validate_retrieve_data_cnf_para(gdsn, resultCode, payloadType, datasetID, dataCollectResultLen, dataCollectResult, payloadLen, payload);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "send_retrieve_data_cnf:ctiot_validate_retrieve_data_cnf_para:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	//2.encode data
	CTIOT_PARAMS retrieveDataParams;
	if (resultCode == 0)
	{
		if (payloadType == 0)
		{
			retrieveDataParams = (CTIOT_PARAMS){7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, payloadLen}}};
			result = ctiot_encode(&stream, &len, retrieveDataParams, upDataSn, CMD_ID_RETRIEVE_DATA_CNF, gdsn, resultCode, payloadType, datasetID, payload);
		}
		if (payloadType == 1)
		{
			retrieveDataParams = (CTIOT_PARAMS){8, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, dataCollectResultLen}, {CTIOT_PARAM_TYPE_BINARY, payloadLen}}};
			result = ctiot_encode(&stream, &len, retrieveDataParams, upDataSn, CMD_ID_RETRIEVE_DATA_CNF, gdsn, resultCode, payloadType, datasetID, dataCollectResult, payload);
		}
		else
		{
			retrieveDataParams = (CTIOT_PARAMS){7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_TEXT, payloadLen}}};
			result = ctiot_encode(&stream, &len, retrieveDataParams, upDataSn, CMD_ID_RETRIEVE_DATA_CNF, gdsn, resultCode, payloadType, datasetID, payload);
		}
	}
	else
	{
		retrieveDataParams = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
		result = ctiot_encode(&stream, &len, retrieveDataParams, upDataSn, CMD_ID_RETRIEVE_DATA_CNF, gdsn, resultCode);
	}
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "send_retrieve_data_cnf:ctiot_encode:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("send_retrieve_data_cnf data,length:%u\n", len);
	log_print_array(stream, len);
	log_print_mark_end();
#endif
	//3.publish upload data
	result = ctiot_tlink_publish_request(len, stream, TOPIC_RETRIEVE_DATA_CNF, qos, msgID);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "send_retrieve_data_cnf:ctiot_tlink_publish_request:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
exit:
	OS_PUT_MEM(stream);
	return ret;
}

CTIOT_STATUS ctiot_validate_retrieve_data_cnf_para(SDK_U32 gdsn, SDK_U8 resultCode, SDK_U16 payloadType, SDK_U16 datasetID, SDK_U16 dataCollectResultLen, SDK_U8 *dataCollectResult, SDK_U16 payloadLen, SDK_U8 *payload)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (!(resultCode == 0 || resultCode == 1 || resultCode == 2 || resultCode == 3))
	{
		ret = CTIOT_RETRIEVE_DATA_INVALIDE_RESULTCODE;
		goto exit;
	}
	if (!(payloadType == 0 || payloadType == 1 || payloadType == 2) && resultCode == 0)
	{
		ret = CTIOT_RETRIEVE_DATA_INVALIDE_PAYLOADTYPE;
		goto exit;
	}
	if (resultCode == 0)
	{
		if (payloadType == 1)
		{
			if (dataCollectResult == NULL || dataCollectResultLen <= 0)
			{
				ret = CTIOT_RETRIEVE_DATA_INVALIDE_RESULT;
				goto exit;
			}
		}
		if (payloadLen <= 0 || payload == NULL)
		{
			ret = CTIOT_RETRIEVE_DATA_INVALIDE_PAYLOAD;
			goto exit;
		}
	}
exit:
	return ret;
}
#endif

#if defined(USE_CTIOT_TRANSPARENT_DATA_UL)

CTIOT_STATUS ctiot_validate_transparent_data_para(CTIOT_MQTT_TRANSPARENT_DATA_REQUEST *ptrTransparentRequestParameter)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ptrTransparentRequestParameter->payload == NULL || ptrTransparentRequestParameter->payloadLen == 0)
	{
		ret = CTIOT_TRANSPARENT_DATA_UL_INVALIDE_PAYLOAD;
		goto exit;
	}
	if(!(ptrTransparentRequestParameter->qos == QOS0 || ptrTransparentRequestParameter->qos == QOS1) )
	{
		ret = CTIOT_TRANSPARENT_DATA_UL_INVALIDE_QOS;
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_send_transparent_data_request(CTIOT_MQTT_TRANSPARENT_DATA_REQUEST *ptrTransparentRequestParameter, SDK_U32 *msgID) /*refer to 8.3 UL*/
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		ret = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return ret;
	}
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;
	// CTIOT_MQTT_MSG_SEND_TRANSPARENT_DATA_REQUEST transparentDataRequest = {0};
	//1.validate transparent data
	CTIOT_STATUS result = ctiot_validate_transparent_data_para(ptrTransparentRequestParameter);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_send_transparent_data_request:ctiot_validate_transparent_data_para:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}

	//2.construct transparent data
	/*result = ctiot_construct_transparent_data_request(&transparentDataRequest,ptrTransparentRequestParameter);

	if(result!=CTIOT_SUCCESS)
    {
        #ifdef ERR_LEVEL_LOG_COMPILE
        log_print(ERROR_LEVEL , LOG_FILE , LOG_FUNC , LOG_LINE , "ctiot_send_transparent_data_request:ctiot_construct_transparent_data_request:result=%d\n" , result);
	    #endif
		ret=result;
		ctiot_set_last_error(&globalLastError,result);
		goto exit;
    }

	#ifdef ID_LEVEL_LOG_COMPILE 
	log_print_mark_begin();
    log_print_plain_text("Transparent data,Length:%u\n",len);
	ctiot_print_send_transparent_data_request(&transparentDataRequest);
	log_print_mark_end();
	#endif*/

	//3.encode transparent data
	//result=ctiot_encode_uplink_transparent_data_request(&transparentDataRequest, &stream, &len);
	CTIOT_PARAMS updata_params;
	SDK_U32 updata_sn = ctiot_generate_packet_sn();
	updata_params = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_BINARY, ptrTransparentRequestParameter->payloadLen}}};
	result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_UL_TR_DATA_REQ, ptrTransparentRequestParameter->upTpDataSN, ptrTransparentRequestParameter->payload);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_send_transparent_data_request:ctiot_encode_uplink_transparent_data_request:result=%d\n", result);
#endif
		//ctiot_destruct_transparent_data_request(&transparentDataRequest);
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Encode transparent data,Length:%u\n", len);
	log_print_array(stream, len);
	log_print_mark_end();
#endif
	//4.publish transparent data
	//SDK_U32 msgID = 0;
	result = ctiot_tlink_publish_request(len, stream, TOPIC_UL_TR_DATA_REQ, ptrTransparentRequestParameter->qos, msgID);	
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_send_transparent_data_request:ctiot_tlink_publish_request:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
	}
	//5.destruct transparent data
	//ctiot_destruct_transparent_data_request(&transparentDataRequest);
exit:
	OS_PUT_MEM(stream);
	return ret;
}

CTIOT_STATUS ctiot_send_tr_data(SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_TRANSPARENT_DATA_REQUEST req = {0};
	req.qos = qos;
	req.payloadLen = payloadLen;
	req.payload = payload;
	ret = ctiot_send_transparent_data_request(&req, msgID);
	return ret;
}
CTIOT_STATUS ctiot_send_transparent_data(SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos,SDK_U32 upTpDataSN, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_TRANSPARENT_DATA_REQUEST req = {0};
	req.qos = qos;
	req.upTpDataSN = upTpDataSN;
	req.payloadLen = payloadLen;
	req.payload = payload;
	ret = ctiot_send_transparent_data_request(&req, msgID);
	return ret;
}
#endif


T_SDK_BOOL ctiot_tlink_pub_queue()
{
	T_SDK_BOOL ret = SDK_TRUE;
	T_RDAP_MSG *msg = NULL;
	SDK_S8 rc = 0;
	T_RDAP_SUBSCRIBE_EVENT_REQ *subEvent = NULL;
	T_RDAP_UNSUBSCRIBE_EVENT_REQ *unsubEvent = NULL;
	T_RDAP_PUBLISH_EVENT_REQ *pubEvent = NULL;
	/*set pubmsg*/
	//pubmsg;
	SDK_U8 msgCount = 0;
	while (msgCount < globalMaxProcessMessageNum && tlink_get_msg(&tlinkQueue, &msg) == SDK_TRUE)
	{
		msgCount++;
		switch (msg->msgType)
		{
		case RDAP_SUBSCRIBE_EVENT_REQ:
			subEvent = (T_RDAP_SUBSCRIBE_EVENT_REQ *)(msg->ptrMsg);
			rc = MQTTSubscribe(&c, subEvent->topic, subEvent->qos, subEvent->cb);
			break;
		case RDAP_UNSUBSCRIBE_EVENT_REQ:
			unsubEvent = (T_RDAP_UNSUBSCRIBE_EVENT_REQ *)(msg->ptrMsg);
			rc = MQTTUnsubscribe(&c, unsubEvent->topic);
			break;
		case RDAP_PUBLISH_EVENT_REQ:
			pubEvent = (T_RDAP_PUBLISH_EVENT_REQ *)msg->ptrMsg;
			if (msg->status == TLINK_QUEUE_WAIT_FOR_SEND || (TimerIsExpired(&(msg->time)) && msg->retrans > 0))
			{
				pubmsg.payload = pubEvent->payload;
				pubmsg.payloadlen = pubEvent->len;
				pubmsg.qos = pubEvent->qos;
				pubmsg.retained = 0;
				pubmsg.dup = 0;

				rc = ctiot_tlink_publishwithnonblock(&c, pubEvent->topic, &pubmsg);
				if (rc == MQTT_SUCCESS && (pubmsg.qos == 1 || pubmsg.qos == 2) && pubmsg.id != 0)
				{
					pubEvent->mqttPacketID = pubmsg.id;
					TimerInit(&(msg->time));
					TimerCountdownMS(&(msg->time), globalQOSMsgRetransTimeout);
					msg->status = TLINK_QUEUE_WAIT_FOR_ACK;
#ifdef ID_LEVEL_LOG_COMPILE
					log_print_plain_text("ctiot_tlink_pub_queue msgID: %d, packetID: %d\n", msg->msgID, pubEvent->mqttPacketID);
#endif
					msg->retrans--;
				}

				if (rc == BUFFER_OVERFLOW)
				{
#ifdef ERR_LEVEL_LOG_COMPILE
					log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_tlink_pub_queue:MQTTPublish:BUFFER_OVERFLOW\n");
#endif
					ctiot_set_last_error(&globalLastError, CTIOT_MQTT_BUFFER_OVERFLOW);
				}
				else if (rc == MQTT_FAILURE)
				{
#ifdef ERR_LEVEL_LOG_COMPILE
					log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_tlink_pub_queue:MQTTPublish:MQTT_FAILURE\n");
#endif
					ret = SDK_FALSE;
					ctiot_set_last_error(&globalLastError, CTIOT_MQTT_PUBLISH_FAIL);
				}
				else
				{
					ctiot_set_last_error(&globalLastError, CTIOT_SUCCESS);
				}
			}
			else
			{
				if ((pubEvent->qos == 1 || pubEvent->qos == 2) && TimerIsExpired(&(msg->time)) && msg->retrans <= 0 && ctiot_msg_status_callback != NULL)
				{
					// callback
					ctiot_msg_status_callback(msg->msgID, TLINK_QUEUE_FAILURE);
					tlink_remove_msg_by_msgid(&tlinkQueue, msg->msgID);
					msg = NULL;
				}
			}
			break;
		default:
			break;
		}
		if (msg != NULL && msg->ptrMsg != NULL)
		{
			if (msg->msgType == RDAP_SUBSCRIBE_EVENT_REQ)
			{
				OS_PUT_MEM(subEvent->topic);
				OS_PUT_MEM(msg->ptrMsg);
				OS_PUT_MEM(msg);
			}
			if (msg->msgType == RDAP_UNSUBSCRIBE_EVENT_REQ)
			{
				OS_PUT_MEM(unsubEvent->topic);
				OS_PUT_MEM(msg->ptrMsg);
				OS_PUT_MEM(msg);
			}
			if (msg->msgType == RDAP_PUBLISH_EVENT_REQ && pubEvent->qos == 0)
			{
				OS_PUT_MEM(pubEvent->payload);
				OS_PUT_MEM(pubEvent->topic);
				OS_PUT_MEM(msg->ptrMsg);
				OS_PUT_MEM(msg);
			}
		}
	}
	return ret;
}

T_SDK_BOOL ctiot_tlink_loop(void *arg)
{
	int rc;
	T_SDK_BOOL ret = SDK_TRUE;
	int runThread = 1;
	while (runThread)
	{
#ifdef OS_FREERTOS_CT
		OS_SLEEP(50);
#endif //OS_FREERTOS_CT
		if(ctiot_get_status() == RDAP_STATE_ERROR)
		{
			ctiot_close_session();
			tastCreateEnd = CLIENT_IDLE;
		}
		switch (tastCreateEnd)
		{
		case CLIENT_IDLE:
		{
			OS_SLEEP(OS_SLEEP_TIME);
		}
		break;
		case LINK_SETUP:
		{
			tlink_create_queue(&tlinkQueue, globalMaxQueueLen);
			tastCreateEnd = IN_WORK;
		}
		break;
		case IN_WORK:
		{
			if (ctiot_get_status() != RDAP_STATE_LOGINED && ctiot_get_status() != RDAP_STATE_BEFORE_LOGIN)
			{
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("ctiot_tlink_loop:ctiot_tlink_loop exit!\n");
#endif
				tastCreateEnd = QUIT_WORK;
			}

			if (ctiot_get_status() == RDAP_STATE_LOGINED && !MQTTIsConnected(&c))
			{
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("ctiot_tlink_loop:MQTT connection disconnect!\n");
#endif
				ctiot_set_last_error(&globalLastError, CTIOT_MQTT_NOT_CONNECTED);
				OS_SLEEP(1000);
				continue;
			}

			if (globalRunThread > 0)
			{
				if (ctiot_tlink_receivedata(&c, ctiot_get_read_socket_period()) != 0)
				{
#ifdef ID_LEVEL_LOG_COMPILE
					log_print_plain_text("ctiot_tlink_loop:Lost connect with MQTT server!\n");
#endif
					ctiot_set_last_error(&globalLastError, CTIOT_MQTT_YIELD_FAIL);
					tastCreateEnd = QUIT_WORK;
				}
			}
			if (ctiot_get_status() == RDAP_STATE_LOGINED && ctiot_tlink_pub_queue() == SDK_FALSE)
			{
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("ctiot_tlink_loop:publish message has error\n");
#endif
				tastCreateEnd = QUIT_WORK;
			}
		}
		break;
		case QUIT_WORK:
		{
			tastCreateEnd = CLIENT_IDLE;
#ifdef ID_LEVEL_LOG_COMPILE
			log_print_plain_text("ctiot_tlink_loop:Lost connect with MQTT server globalLastError=%d!\n", ctiot_get_last_error());
#endif
		}
		break;
		}
	}
	return ret;
}

#if defined(USE_CTIOT_RETRIEVEDATA)
//**************************************************
//
//! @brief  数据获取报文解析功能
//!
//! @param MessageData* ptrMd,注册入参，见@ref MessageData
//!
//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_retrieve_data_arrived(MessageData *ptrMd)
{
	CTIOT_MQTT_RETRIEVE_DATA_REQ appItf = {0};
	CTIOT_STATUS result = ctiot_validate_mqtt_message(ptrMd);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_retrieve_data_arrived: validate message error!\n:result=%d\n", result);
#endif
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	MQTTMessage *m = ptrMd->message;
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("ctiot retrieve data arrived!\n");
	log_print_array(m->payload, m->payloadlen);
	log_print_mark_end();
#endif
	/*Parase message*/
	CTIOT_DECODE_PARAMS decodeParam = {5, {{CTIOT_PARAM_TYPE_DIGIT, 4, 0}, {CTIOT_PARAM_TYPE_DIGIT, 1, 0}, {CTIOT_PARAM_TYPE_DIGIT, 4, 0}, {CTIOT_PARAM_TYPE_DIGIT, 1, 0}, {CTIOT_PARAM_TYPE_DIGIT, 2, 0}}};
	result = ctiot_decode(m->payload, m->payloadlen, &decodeParam, 0);
	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("DnPacketSN:%u\n", decodeParam.ctiot_decode_params[0].u.ctiot_u32value);
	log_print_plain_text("CMDType:%hhu\n", decodeParam.ctiot_decode_params[1].u.ctiot_u8value);
	log_print_plain_text("GDSN:%u\n", decodeParam.ctiot_decode_params[2].u.ctiot_u32value);
	log_print_plain_text("PayloadType:%u\n", decodeParam.ctiot_decode_params[3].u.ctiot_u8value);
	log_print_plain_text("DatasetID:%hu\n", decodeParam.ctiot_decode_params[4].u.ctiot_u16value);
	log_print_mark_end();
#endif
	if (ctiot_retrieve_data_callback != NULL)
	{
		appItf.gdsn = decodeParam.ctiot_decode_params[2].u.ctiot_u32value;
		appItf.payloadType = decodeParam.ctiot_decode_params[3].u.ctiot_u8value;
		appItf.datasetID = decodeParam.ctiot_decode_params[4].u.ctiot_u16value;
		ctiot_retrieve_data_callback(&appItf);
	}
	else
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot remote control callback is null\n");
#endif
	}
exit:
	ctiot_release_decode_buffer(decodeParam);
}
#endif

#if defined(USE_CTIOT_REMOTECTRL_EXCUTE) || defined(USE_CTIOT_ENQUIREPARA_EXCUTE) || defined(USE_CTIOT_SETPARA_EXCUTE)
//**************************************************
//
//! @brief  远程控制报文解析功能
//!
//! @param MessageData* ptrMd,注册入参，见@ref MessageData
//!
//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_remote_ctrl_arrived(MessageData *ptrMd)
{
	CTIOT_MQTT_REMOTE_CTRL_REQ appItf = {0};
	CTIOT_MQTT_PARA_ENQUIRE_REQ paraEnquire = {0};
	CTIOT_MQTT_SET_PARA_REQ setPara = {0};
	//CTIOT_MQTT_MSG_REMOTE_CTRL_REQ ctrlReq = {0};
	int i = 0;

	CTIOT_STATUS result = ctiot_validate_mqtt_message(ptrMd);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_remote_ctrl_arrived: validate message error!\n:result=%d\n", result);
#endif
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	MQTTMessage *m = ptrMd->message;
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("ctiot remote_ctrl/enquire_param/set_param  arrived!\n");
	log_print_array(m->payload, m->payloadlen);
	log_print_mark_end();
#endif

#if 0
   result = ctiot_decode_remote_control_request(&ctrlReq, m->payload,m->payloadlen);
#else
	CTIOT_DECODE_PARAMS decodeParam = {3, {{CTIOT_PARAM_TYPE_DIGIT, 4, 0}, {CTIOT_PARAM_TYPE_DIGIT, 1, 0}, {CTIOT_PARAM_TYPE_DIGIT, 4, 0}}};
	result = ctiot_decode(m->payload, m->payloadlen, &decodeParam, 0);
#endif
	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("cmdType=%d\n", decodeParam.ctiot_decode_params[1].u.ctiot_u8value);
	log_print_plain_text("dnPacketSN=%d\n", decodeParam.ctiot_decode_params[0].u.ctiot_u32value);
	log_print_plain_text("dmsn=%d\n", decodeParam.ctiot_decode_params[2].u.ctiot_u32value);
#endif
	CTIOT_DECODE_PARAMS decodeParam1, decodeParam2;
	switch (decodeParam.ctiot_decode_params[1].u.ctiot_u8value)
	{
#if defined(USE_CTIOT_REMOTECTRL_EXCUTE)
	case 0x0a:
	{
		if (ctiot_remote_control_callback != NULL)
		{
			appItf.dmsn = decodeParam.ctiot_decode_params[2].u.ctiot_u32value;
			decodeParam2 = (CTIOT_DECODE_PARAMS){2, {{CTIOT_PARAM_TYPE_DIGIT, 2, 0}, {CTIOT_PARAM_TYPE_BINARY, 0, 0}}};
			result = ctiot_decode(m->payload, m->payloadlen, &decodeParam2, 9);
			if (result != CTIOT_SUCCESS)
			{
				ctiot_set_last_error(&globalLastError, result);
				//printf("ctiot_remote_ctrl decode error\n");
				goto exit;
			}
			appItf.controlType = decodeParam2.ctiot_decode_params[0].u.ctiot_u16value;
			appItf.additionalInfo = decodeParam2.ctiot_decode_params[1].u.ctiot_content;
			appItf.additionalInfoLen = decodeParam2.ctiot_decode_params[1].ctiot_param_len;
//software upgrade
#ifdef ID_LEVEL_LOG_COMPILE
			log_print_plain_text("controlType=%d\n", appItf.controlType);
			log_print_plain_text("additionalInfoLen=%d\n", appItf.additionalInfoLen);
			log_print_plain_text("additionalInfo:");
			for (i = 0; i < appItf.additionalInfoLen; i++)
			{
				log_print_plain_text("%02x", appItf.additionalInfo[i]);
			}
			log_print_plain_text("\n");
#endif
			if (appItf.controlType == CTRL_UPGRADE)
			{
				decodeParam1 = (CTIOT_DECODE_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 1, 0}, {CTIOT_PARAM_TYPE_BINARY_STATIC, 16, 0}, {CTIOT_PARAM_TYPE_DIGIT, 1, 0}, {CTIOT_PARAM_TYPE_TEXT, 0, 0}, {CTIOT_PARAM_TYPE_TEXT, 0, 0}, {CTIOT_PARAM_TYPE_TEXT, 0, 0}}};
				result = ctiot_decode(m->payload, m->payloadlen, &decodeParam1, 13 + appItf.additionalInfoLen);
				if (result != CTIOT_SUCCESS)
				{
					ctiot_set_last_error(&globalLastError, result);
					//printf("ctiot_remote_ctrl decode error\n");
					goto exit;
				}
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("upgradeID=%d\n", decodeParam1.ctiot_decode_params[0].u.ctiot_u8value);
				log_print_plain_text("fileChecksum=%s\n", decodeParam1.ctiot_decode_params[1].u.ctiot_content);
				log_print_plain_text("upgradeType=%d\n", decodeParam1.ctiot_decode_params[2].u.ctiot_u8value);
				log_print_plain_text("upgradeVersion=%s\n", decodeParam1.ctiot_decode_params[3].u.ctiot_content);
				log_print_plain_text("upgradeURL=%s\n", decodeParam1.ctiot_decode_params[4].u.ctiot_content);
				log_print_plain_text("token=%s\n", decodeParam1.ctiot_decode_params[5].u.ctiot_content);
#endif
				appItf.upgradeInfo.upgradeID = decodeParam1.ctiot_decode_params[0].u.ctiot_u8value;
				memcpy(appItf.upgradeInfo.fileChecksum, decodeParam1.ctiot_decode_params[1].u.ctiot_content, decodeParam1.ctiot_decode_params[1].ctiot_param_len);
				appItf.upgradeInfo.upgradeType = decodeParam1.ctiot_decode_params[2].u.ctiot_u8value;
				appItf.upgradeInfo.upgradeVersion = decodeParam1.ctiot_decode_params[3].u.ctiot_content;
				appItf.upgradeInfo.upgradeURL = decodeParam1.ctiot_decode_params[4].u.ctiot_content;
				appItf.upgradeInfo.token = decodeParam1.ctiot_decode_params[5].u.ctiot_content;
			}
			ctiot_remote_control_callback(&appItf);
#if 1
			if (appItf.controlType == CTRL_UPGRADE)
			{
				ctiot_release_decode_buffer(decodeParam1);
			}
#endif
		}
		else
		{
#ifdef ERR_LEVEL_LOG_COMPILE
			log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot remote control callback is null\n");
#endif
		}
		break;
	}
#endif
#if defined(USE_CTIOT_ENQUIREPARA_EXCUTE)
	case 0x08:
	{
		if (ctiot_para_enquire_request_callback != NULL)
		{
			paraEnquire.dmsn = decodeParam.ctiot_decode_params[2].u.ctiot_u32value;
			decodeParam2 = (CTIOT_DECODE_PARAMS){1, {{CTIOT_PARAM_TYPE_DIGIT, 1, 0}}};
			result = ctiot_decode(m->payload, m->payloadlen, &decodeParam2, 9);
			if (result != CTIOT_SUCCESS)
			{
				ctiot_set_last_error(&globalLastError, result);
				goto exit;
			}
			paraEnquire.payloadType = decodeParam2.ctiot_decode_params[0].u.ctiot_u8value;
#ifdef ID_LEVEL_LOG_COMPILE
			log_print_plain_text("payloadType=%d\n", paraEnquire.payloadType);
#endif
			if (paraEnquire.payloadType == 0)
			{
				decodeParam1 = (CTIOT_DECODE_PARAMS){1, {{CTIOT_PARAM_TYPE_DIGIT, 2, 0}}};
				result = ctiot_decode(m->payload, m->payloadlen, &decodeParam1, 10);
				if (result != CTIOT_SUCCESS)
				{
					ctiot_set_last_error(&globalLastError, result);
					//printf("ctiot para enquire decode error\n");
					goto exit;
				}
				paraEnquire.u.datasetID = decodeParam1.ctiot_decode_params[0].u.ctiot_u16value;
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("datasetID=%d\n", paraEnquire.u.datasetID);
#endif
				//printf("datasetID:%d\n",paraEnquire.u.datasetID);
			}
			else if (paraEnquire.payloadType == 2)
			{
				decodeParam1 = (CTIOT_DECODE_PARAMS){1, {{CTIOT_PARAM_TYPE_TEXT, 0, 0}}};
				result = ctiot_decode(m->payload, m->payloadlen, &decodeParam1, 10);
				if (result != CTIOT_SUCCESS)
				{
					ctiot_set_last_error(&globalLastError, result);
					//printf("ctiot para enquire decode error\n");
					goto exit;
				}
				paraEnquire.u.content = decodeParam1.ctiot_decode_params[0].u.ctiot_content;
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("payload=%s\n", paraEnquire.u.content);
#endif
				//printf("content:%s\n",paraEnquire.u.content);
			}
			else
			{
#ifdef ERR_LEVEL_LOG_COMPILE
				log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot para enquire decode error\n");
#endif
				//ctiot_release_decode_buffer(decodeParam1);
				result = CTIOT_INVALID_PARAM_VALUE;
				ctiot_set_last_error(&globalLastError, result);
				//printf("invalid ctiot para enquire params\n");
				goto exit;
			}
			ctiot_para_enquire_request_callback(&paraEnquire);
#if 1
			ctiot_release_decode_buffer(decodeParam1);
#endif
		}
		else
		{
#ifdef ERR_LEVEL_LOG_COMPILE
			log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot para enquire callback is null\n");
#endif
		}
		break;
	}
#endif
#if defined(USE_CTIOT_SETPARA_EXCUTE)
	case 0x09:
	{
		if (ctiot_set_para_request_callback != NULL)
		{
			setPara.dmsn = decodeParam.ctiot_decode_params[2].u.ctiot_u32value;
			decodeParam2 = (CTIOT_DECODE_PARAMS){1, {{CTIOT_PARAM_TYPE_DIGIT, 1, 0}}};
			result = ctiot_decode(m->payload, m->payloadlen, &decodeParam2, 9);
			if (result != CTIOT_SUCCESS)
			{
				ctiot_set_last_error(&globalLastError, result);
				//printf("ctiot set para decode error\n");
				goto exit;
			}
			setPara.payloadType = decodeParam2.ctiot_decode_params[0].u.ctiot_u8value;
#ifdef ID_LEVEL_LOG_COMPILE
			log_print_plain_text("payloadType=%d\n", setPara.payloadType);
#endif
			if (setPara.payloadType == 0)
			{
				decodeParam1 = (CTIOT_DECODE_PARAMS){2, {{CTIOT_PARAM_TYPE_DIGIT, 2, 0}, {CTIOT_PARAM_TYPE_BINARY, 0, 0}}};
				result = ctiot_decode(m->payload, m->payloadlen, &decodeParam1, 10);
				if (result != CTIOT_SUCCESS)
				{
					ctiot_set_last_error(&globalLastError, result);
					//printf("ctiot para enquire decode error\n");
					goto exit;
				}
				setPara.u.compact.datasetID = decodeParam1.ctiot_decode_params[0].u.ctiot_u16value;
				setPara.u.compact.payloadLen = decodeParam1.ctiot_decode_params[1].ctiot_param_len;
				setPara.u.compact.payload = decodeParam1.ctiot_decode_params[1].u.ctiot_content;
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("datasetID=%d\n", setPara.u.compact.datasetID);
				log_print_array(setPara.u.compact.payload, setPara.u.compact.payloadLen);
#endif
			}
			else if (setPara.payloadType == 2)
			{
				//printf("set para  payloadtype=2\n");
				decodeParam1 = (CTIOT_DECODE_PARAMS){1, {{CTIOT_PARAM_TYPE_TEXT, 0, 0}}};
				result = ctiot_decode(m->payload, m->payloadlen, &decodeParam1, 10);
				if (result != CTIOT_SUCCESS)
				{
					ctiot_set_last_error(&globalLastError, result);
					//printf("ctiot set para  decode error\n");
					goto exit;
				}
				setPara.u.json.payload = decodeParam1.ctiot_decode_params[0].u.ctiot_content;
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("payload=%s\n", setPara.u.json.payload);
#endif
			}
			else
			{
#ifdef ERR_LEVEL_LOG_COMPILE
				log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot para enquire decode error\n");
#endif
				//ctiot_release_decode_buffer(decodeParam1);
				result = CTIOT_INVALID_PARAM_VALUE;
				ctiot_set_last_error(&globalLastError, result);
				//printf("invalid ctiot set para params\n");
				goto exit;
			}
			//printf("set para  callback\n");
			ctiot_set_para_request_callback(&setPara);
//printf("set para callback ended\n");
#if 1
			ctiot_release_decode_buffer(decodeParam1);
#endif
			//printf("set para release buffer\n");
		}
		else
		{
#ifdef ERR_LEVEL_LOG_COMPILE
			log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot set para callback is null\n");
#endif
		}
		break;
	}
#endif
	default:
		result = CTIOT_INVALID_CMDTYPE;
	}
exit:
	ctiot_release_decode_buffer(decodeParam);
	return;
}
#endif

//**************************************************
//
//! @brief  登录回复信息解析功能
//!
//! @param MessageData* ptrMd,注册入参，见@ref MessageData
//!
//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_login_confirm_arrived(MessageData *ptrMd)
{
	if (ptrMd == NULL)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_confirm_arrived:CTIOT_OS_NULL_POINTER\n");
#endif
		finish = CTIOT_OS_NULL_POINTER;
		return;
	}
	CTIOT_STATUS result = ctiot_validate_mqtt_message(ptrMd);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_confirm_arrived:ctiot_validate_mqtt_message:result=%d\n", result);
#endif
		finish = result;
		return;
	}
	int rc = 0;
	MQTTMessage *m = ptrMd->message;
	CTIOT_MQTT_MSG_LOGIN_CNF loginCnf = {0};
	SDK_U8 *p = m->payload;
	if (ctiot_get_status() == RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_confirm_arrived:CTIOT_LOGIN_ALREADY_LOGIN\n");
#endif
		finish = CTIOT_LOGIN_ALREADY_LOGIN;
		return;
	}
	if (p[4] == CMD_ID_LOGIN_CNF)
	{
		CTIOT_STATUS result = ctiot_decode_login_confirm(&loginCnf, m->payload, m->payloadlen);
		if (result != CTIOT_SUCCESS)
		{
#ifdef ERR_LEVEL_LOG_COMPILE
			log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_confirm_arrived:ctiot_decode_login_confirm:result=%d\n", result);
#endif
			finish = result;
			return;
		}
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_mark_begin();
		log_print_plain_text("ctiot_login_confirm_arrived:Receive LOGIN CNF:\n");
		log_print_array(m->payload, m->payloadlen);
		ctiot_print_login_confirm(&loginCnf);
		log_print_mark_end();
#endif
		if (loginCnf.resultCode == RDAP_RESULT_SUCC)
		{
			memset(globalRedirectIP, 0, sizeof(globalRedirectIP));
			memcpy(globalRedirectIP, loginCnf.redirectServerIP, strlen(loginCnf.redirectServerIP));
			globalPlatformTimestamp = loginCnf.platformTimeStamp;
			globalHbtLength = loginCnf.heartBeatTimer;
			ctiot_update_mqtt_heartbeat_time(&c, globalHbtLength);
			MQTTSetMessageHandler(&c, TOPIC_REG_CNF, NULL);

			//login 成功，设置报文处理程序
#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
			MQTTSetMessageHandler(&c, TOPIC_DL_TR_DATA, ctiot_downlink_transparent_data_arrived);
#endif
#if defined(USE_CTIOT_CMD_EXCUTE)
			MQTTSetMessageHandler(&c, TOPIC_EXECUTE_CMD, ctiot_execute_cmd_arrived);
#endif
#if defined(USE_CTIOT_REMOTECTRL_EXCUTE) || defined(USE_CTIOT_ENQUIREPARA_EXCUTE) || defined(USE_CTIOT_SETPARA_EXCUTE)
			MQTTSetMessageHandler(&c, TOPIC_REMOTE_CTRL, ctiot_remote_ctrl_arrived);
#endif
#if defined(USE_CTIOT_RETRIEVEDATA)
			MQTTSetMessageHandler(&c, TOPIC_RETRIEVE_DATA, ctiot_retrieve_data_arrived);
#endif
#if defined(USE_CTIOT_FILE_UPLOAD)
			MQTTSetMessageHandler(&c, TOPIC_FILE_UPLOAD, ctiot_file_upload_cof_arrived);
#endif
			ctiot_set_status(RDAP_STATE_LOGINED);
			finish = CTIOT_SUCCESS;
		}
		else
		{
			if(loginCnf.resultCode > 4)
			{
				finish = CTIOT_LOGIN_OTHER_REASON;
			}
			else
			{
				finish = loginCnf.resultCode + CTIOT_LOGIN_OTHER_REASON - 1;
			}	
#ifdef ERR_LEVEL_LOG_COMPILE
			log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_confirm_arrived:Login Cnf fail!result=%d\n", finish);
#endif
		}
		ctiot_dc_destruct_login_confirm(&loginCnf);
	}
}

//**************************************************
//
//! @brief  备份登录参数
//!
//! @param [in]CTIOT_MQTT_MSG_LOGIN_REQ* ptrLoginReq,登录报文内容，见@ref CTIOT_MQTT_MSG_LOGIN_REQ
//!
//! @retval  T_SDK_BOOL 成功0，失败1
//
//**************************************************
CTIOT_STATUS ctiot_backup_login_para(CTIOT_MQTT_LOGIN_REQ *ptrPara)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (loginPara.deviceNo == NULL)
	{
		memcpy(&loginPara, ptrPara, sizeof(CTIOT_MQTT_LOGIN_REQ));
		//deviceNo
		OS_GET_MEM(loginPara.deviceNo, char, strlen(ptrPara->deviceNo) + 1);
		if (loginPara.deviceNo == NULL)
		{
			ret = CTIOT_OS_NOT_ENOUGH_MEM;
			goto exit;
		}
		memcpy(loginPara.deviceNo, ptrPara->deviceNo, strlen(ptrPara->deviceNo));
		loginPara.deviceNo[strlen(ptrPara->deviceNo)] = 0;
		//SoftwareVersion
		OS_GET_MEM(loginPara.softwareVersion, char, strlen(ptrPara->softwareVersion) + 1);
		if (loginPara.softwareVersion == NULL)
		{
			OS_PUT_MEM(loginPara.deviceNo);
			ret = CTIOT_OS_NOT_ENOUGH_MEM;
			goto exit;
		}
		memcpy(loginPara.softwareVersion, ptrPara->softwareVersion, strlen(ptrPara->softwareVersion));
		loginPara.softwareVersion[strlen(ptrPara->softwareVersion)] = 0;
		//Deviceinfo
		if (ptrPara->deviceType != NULL)
		{
			OS_GET_MEM(loginPara.deviceType, char, strlen(ptrPara->deviceType) + 1);
			if (loginPara.deviceType == NULL)
			{
				OS_PUT_MEM(loginPara.deviceNo);
				OS_PUT_MEM(loginPara.softwareVersion);
				ret = CTIOT_OS_NOT_ENOUGH_MEM;
				goto exit;
			}
			memcpy(loginPara.deviceType, ptrPara->deviceType, strlen(ptrPara->deviceType));
			loginPara.deviceType[strlen(ptrPara->deviceType)] = 0;
		}
		else
		{
			loginPara.deviceType = NULL;
		}
		//Identity
		OS_GET_MEM(loginPara.identity.identity, SDK_U8, ptrPara->identity.identityLength);
		if (loginPara.identity.identity == NULL)
		{
			OS_PUT_MEM(loginPara.deviceNo);
			OS_PUT_MEM(loginPara.softwareVersion);
			if (loginPara.deviceType != NULL)
			{
				OS_PUT_MEM(loginPara.deviceType);
			}
			ret = CTIOT_OS_NOT_ENOUGH_MEM;
			goto exit;
		}
		memcpy(loginPara.identity.identity,
			   ptrPara->identity.identity,
			   ptrPara->identity.identityLength);
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_login_request(CTIOT_MQTT_LOGIN_REQ *ptrLoginRequestPara, CTIOT_MQTT_LOGIN_CNF *ptrLoginCnf)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	SDK_U16 DeviceTypeLen = 0;
	globalDeviceId[strlen(ptrLoginRequestPara->deviceNo)] = 0;
	memcpy(globalDeviceId, ptrLoginRequestPara->deviceNo, strlen(ptrLoginRequestPara->deviceNo));
	if (ptrLoginRequestPara == NULL || ptrLoginCnf == NULL)
	{
		ret = CTIOT_OS_NULL_POINTER;
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_OS_NULL_POINTER\n");
#endif
		goto exit;
	}
	CTIOT_STATUS result = ctiot_validate_login_para(ptrLoginRequestPara);
	if (result != CTIOT_SUCCESS)
	{
		ret = result;
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:ctiot_validate_login_para:result=%d\n", result);
#endif
		goto exit;
	}
	SDK_U8 *ptrCodeStream = NULL;
	SDK_U16 Len = 0;
	CTIOT_MQTT_MSG_LOGIN_REQ loginReq = {0};
	int rc = 0;
	SDK_U16 count;
	char *base64Reg = NULL;
	char *base64Did = NULL;
	SDK_U16 base64RegLen = 0;
	SDK_U16 base64Len;
	static char taskCreateMark = 1;
	if (ctiot_get_status() == RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_LOGIN_ALREADY_LOGIN\n");
#endif
		ret = CTIOT_LOGIN_ALREADY_LOGIN;
		goto exit;
	}
	if (ctiot_get_status() == RDAP_STATE_DETACHED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_INIT\n");
#endif
		ret = CTIOT_NOT_INIT;
		goto exit;
	}
	if (ctiot_get_status() == RDAP_STATE_BEFORE_LOGIN)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_LOGIN_ALREADY_LOGIN\n");
#endif
		ret = CTIOT_LOGIN_ALREADY_LOGIN;
		goto exit;
	}
	if (ctiot_get_status() == RDAP_STATE_ERROR)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:status is RDAP_STATE_ERROR, can not login !\n");
#endif
		ret = CTIOT_LOGIN_ALREADY_LOGIN;
		goto exit;
	}
	result = ctiot_backup_login_para(ptrLoginRequestPara);
	if (result != CTIOT_SUCCESS)
	{
		ret = result;
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:ctiot_backup_login_para:result=%d\n", result);
#endif
		goto exit;
	}

	CTIOT_PARAMS updata_params;
	SDK_U32 updata_sn = ctiot_generate_packet_sn();
	SDK_U16 dasn = ctiot_generate_dasn_sn();
	SDK_U8 sdkVersion[3];
	sdkVersion[0] = STANDARD_PROTOCOL;
	sdkVersion[1] = PRIMARY_VERSION;
	sdkVersion[2] = SECONDARY_VERSION;
	if (ptrLoginRequestPara->deviceType == NULL)
	{
		DeviceTypeLen = 0;
	}
	else
	{
		DeviceTypeLen = strlen(ptrLoginRequestPara->deviceType);
	}
	updata_params = (CTIOT_PARAMS){11, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 8}, {CTIOT_PARAM_TYPE_TEXT_STATIC, 6}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY_STATIC, 3}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_TEXT, strlen(ptrLoginRequestPara->softwareVersion)}, {CTIOT_PARAM_TYPE_TEXT, DeviceTypeLen}}};
	result = ctiot_encode(&ptrCodeStream, &Len, updata_params, updata_sn, CMD_ID_LOGIN_REQ, dasn, ptrLoginRequestPara->timeStamp, ptrLoginRequestPara->utcOffset, ptrLoginRequestPara->networkType, ptrLoginRequestPara->heartBeatLen, sdkVersion, SDK_MODE, ptrLoginRequestPara->softwareVersion, ptrLoginRequestPara->deviceType);
	if (result != CTIOT_SUCCESS)
	{
		ret = result;
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:ctiot_encode_login_request:result=%d\n", result);
#endif
		goto exit;
	}
	base64RegLen = (Len / 3 + 1) * 4;
	OS_GET_MEM(base64Reg, char, base64RegLen + 1);
	if (base64Reg == NULL)
	{
		OS_PUT_MEM(ptrCodeStream);
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:base64Login:CTIOT_OS_NOT_ENOUGH_MEM\n");
#endif
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		goto exit;
	}
	base64Len = ctiot_base64_encode(ptrCodeStream, base64Reg, Len);
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("ctiot_login_request:base64Login:%s\n", base64Reg);
#endif
	OS_PUT_MEM(ptrCodeStream);
	if (ptrLoginRequestPara->identity.identityMode == 2)
	{
		ptrLoginRequestPara->identity.identityLength = 0;
	}
	CTIOT_PARAMS password_params = {2, {{CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_BINARY, ptrLoginRequestPara->identity.identityLength}}};
	result = ctiot_encode(&ptrCodeStream, &Len, password_params, ptrLoginRequestPara->identity.identityMode, ptrLoginRequestPara->identity.identity);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:ctiot_encode_device_id:result=%d\n", result);
#endif
		OS_PUT_MEM(ptrCodeStream);
		OS_PUT_MEM(base64Reg);
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		goto exit;
	}
	base64RegLen = (Len / 3 + 1) * 4;
	OS_GET_MEM(base64Did, char, base64RegLen + 1);
	if (base64Did == NULL)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:base64Did:CTIOT_OS_NOT_ENOUGH_MEM\n");
#endif
		OS_PUT_MEM(ptrCodeStream);
		OS_PUT_MEM(base64Reg);
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		goto exit;
	}
	base64Len = ctiot_base64_encode(ptrCodeStream, base64Did, Len);
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("ctiot_login_request:base64Login:base64Did:%s\n", base64Did);
#endif
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("SDK send LOGIN REQ,len:%u\n", Len);
	log_print_array(ptrCodeStream, Len);
	log_print_mark_end();
#endif
Relogin:
	ctiot_set_status(RDAP_STATE_BEFORE_LOGIN);
	result = ctiot_mqtt_connection(ptrLoginRequestPara->deviceNo, base64Reg, base64Did);
	if (result == CTIOT_SUCCESS)
	{
		finish = CTIOT_UNKNOWN;
		globalRunThread = 0;
		rc = MQTTSetMessageHandler(&c, TOPIC_REG_CNF, ctiot_login_confirm_arrived);
#ifndef OS_FREERTOS_CT
		if (taskCreateMark == 1)
		{
			if (OS_CREATE_THREAD(&globalLoopTid, NULL, (void *)ctiot_tlink_loop, NULL) != 0)
			{
#ifdef ERR_LEVEL_LOG_COMPILE
				log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "task ctiot_tlink_loop create failure!\n");
#endif
				ret = CTIOT_OS_THREAD_OPEN_FAIL;
				goto exit1;
			}
			else
			{
				taskCreateMark = 0;
				tastCreateEnd = LINK_SETUP;
			}
		}
		else
		{
			tastCreateEnd = LINK_SETUP;
		}
#else
		if (taskCreateMark == 1)
		{
			if (OS_CREATE_THREAD(ctiot_tlink_loop, "mqtt_client", (portSTACK_TYPE *)ClientTaskStk, CLIENT_TASK_STACKSZ, CLIENT_TASK_PRIO) != pdPASS)
			{
#ifdef ERR_LEVEL_LOG_COMPILE
				log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "task ctiot_tlink_loop create failure!\n");
#endif
				ret = CTIOT_OS_THREAD_OPEN_FAIL;
				goto exit1;
			}
			else
			{
				tastCreateEnd = LINK_SETUP;
				taskCreateMark = 0;
			}
		}
		else
		{
			tastCreateEnd = LINK_SETUP;
		}
#endif
		count = (ctiot_get_register_login_duration() / ctiot_get_read_socket_period()) + 1;
		while (1)
		{
			count--;
			if (finish != CTIOT_UNKNOWN)
			{
				if (finish == CTIOT_SUCCESS)
				{
					globalRunThread = 1;
				}
				break;
			}
			if (count == 0)
			{
				finish = CTIOT_LOGIN_WAIT_PUBLISH_TIMEOUT;
				globalRunThread = 0;
				ret = CTIOT_LOGIN_WAIT_PUBLISH_TIMEOUT;
#ifdef ID_LEVEL_LOG_COMPILE
				log_print_plain_text("ctiot_login_request:wait for register confirm timeout\n");
#endif
				break;
			}
			MQTTYield(&c, /*SOCKET_READ_TIMEOUT_MS*/ ctiot_get_read_socket_period());
		}
	}
	else
	{
		ret = result;
		goto exit1;
	}
	if (ctiot_get_status() == RDAP_STATE_LOGINED)
	{
		if (ptrLoginCnf->redirectServerIP == NULL)
		{
			OS_GET_MEM(ptrLoginCnf->redirectServerIP, char, strlen(globalRedirectIP) + 1);
			if (ptrLoginCnf->redirectServerIP == NULL)
			{
				ret = CTIOT_OS_NOT_ENOUGH_MEM;
				goto exit1;
			}
			if (globalRedirectIP != NULL && strcmp(globalRedirectIP, ptrLoginCnf->redirectServerIP) != 0)
			{
				memcpy(ptrLoginCnf->redirectServerIP, globalRedirectIP, strlen(globalRedirectIP));
				ptrLoginCnf->redirectServerIP[strlen(globalRedirectIP)] = 0;
			}
		}
		ptrLoginCnf->platformTimeStamp = globalPlatformTimestamp;
		ptrLoginCnf->heartBeatLen = globalHbtLength;
		if (strcmp(globalHostIP, globalRedirectIP) != 0)
		{
			ctiot_logout_request();
			memset(globalHostIP, 0, 20 * sizeof(char));
			memcpy(globalHostIP, globalRedirectIP, strlen(globalRedirectIP));
			goto Relogin;
		}

		ret = CTIOT_SUCCESS;
	}
	else
	{
		ptrLoginCnf->resultCode = finish;
		ret = finish;
	}

exit1:
	OS_PUT_MEM(base64Reg);
	OS_PUT_MEM(base64Did);
	OS_PUT_MEM(ptrCodeStream);
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
		ctiot_close_session();
	}
exit:
	return ret;
}
T_SDK_BOOL ctiot_close_session()
{
	int rc = 0;
	T_SDK_BOOL ret = SDK_TRUE;
	tlink_clean_queue(&tlinkQueue);
	rc = MQTTDisconnect(&c);
	NetworkDisconnect(&n);
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("ctiot_logout_request:disconnect from mqtt server,result:%d\n", rc);
#endif
	ctiot_set_status(RDAP_STATE_LOGOUTED);
	return ret;
}

T_SDK_BOOL ctiot_logout_request()
{
	if (ctiot_get_status() != RDAP_STATE_LOGINED && ctiot_get_status() != RDAP_STATE_BEFORE_LOGIN && ctiot_get_status() != RDAP_STATE_ERROR)
	{
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_plain_text("Waring:Logout when sdk is in state %u\n", ctiot_get_status());
		log_print_plain_text("Client has not logined yet,No need to logout!\n");
#endif
		return SDK_TRUE;
	}
	globalRunThread = 0;
	OS_SLEEP(ctiot_get_read_socket_period());
	tastCreateEnd = CLIENT_IDLE;
	return ctiot_close_session();
}

#if defined(USE_CTIOT_SEND_DATA)
CTIOT_STATUS ctiot_send_data_request(CTIOT_MQTT_DATA_REQ *ptrDataRequest, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		ret = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return ret;
	}
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;
	CTIOT_STATUS result = ctiot_validate_send_data_para(ptrDataRequest);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_send_data_request:ctiot_validate_send_data_para:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}

	CTIOT_PARAMS updata_params;
	SDK_U32 updata_sn = ctiot_generate_packet_sn();
	if (ptrDataRequest->payloadType == COMPACT_WITH_RLT_MODE)
	{
		updata_params = (CTIOT_PARAMS){7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, ptrDataRequest->u.compactWithRslt.resultLen}, {CTIOT_PARAM_TYPE_BINARY, ptrDataRequest->u.compactWithRslt.payloadLen}}};
		result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_UL_DATA_REQ, ptrDataRequest->upDataSN, 1, ptrDataRequest->u.compactWithRslt.datasetID, ptrDataRequest->u.compactWithRslt.result, ptrDataRequest->u.compactWithRslt.payload);
	}
	else if (ptrDataRequest->payloadType == COMPACT_MODE)
	{
		updata_params = (CTIOT_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, ptrDataRequest->u.compact.payloadLen}}};
		result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_UL_DATA_REQ, ptrDataRequest->upDataSN, 0, ptrDataRequest->u.compact.datasetID, ptrDataRequest->u.compact.payload);
	}
	else
	{
		updata_params = (CTIOT_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, strlen(ptrDataRequest->u.json.payload)}}};
		result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_UL_DATA_REQ, ptrDataRequest->upDataSN, 2, ptrDataRequest->u.json.u.datasetID, ptrDataRequest->u.json.payload);
	}
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_send_data_request:ctiot_encode_upload_data_request:result=%d\n", result);
#endif
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Encode upload data ,Length:%u\n", len);
	log_print_array(stream, len);
	log_print_mark_end();
#endif
	result = ctiot_tlink_publish_request(len, stream, TOPIC_UL_DATA_REQ, ptrDataRequest->qos, msgID);

	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_send_data_request:ctiot_tlink_publish_request:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
	}
exit:
	OS_PUT_MEM(stream);
	return ret;
}

CTIOT_STATUS ctiot_send_compact_mode_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
										  SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_DATA_REQ req = {0};
	req.qos = qos;
	req.payloadType = payloadType;
	req.u.compact.datasetID = dataSetID;
	req.u.compact.payloadLen = payloadLen;
	req.u.compact.payload = payload;
	ret = ctiot_send_data_request(&req, msgID);
	return ret;
}

CTIOT_STATUS ctiot_send_compact_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
										  SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos,SDK_U32 upDataSN, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_DATA_REQ req = {0};
	req.qos = qos;
	req.upDataSN = upDataSN;
	req.payloadType = payloadType;
	req.u.compact.datasetID = dataSetID;
	req.u.compact.payloadLen = payloadLen;
	req.u.compact.payload = payload;
	ret = ctiot_send_data_request(&req, msgID);
	return ret;
}

CTIOT_STATUS ctiot_send_compact_with_rlt_mode_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
												   SDK_U16 payloadLen, SDK_U8 *payload, SDK_U16 resultLen, SDK_U8 *result, SDK_U8 qos, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_DATA_REQ req = {0};
	req.qos = qos;
	req.payloadType = payloadType;
	req.u.compactWithRslt.datasetID = dataSetID;
	req.u.compactWithRslt.resultLen = resultLen;
	req.u.compactWithRslt.result = result;
	req.u.compactWithRslt.payloadLen = payloadLen;
	req.u.compactWithRslt.payload = payload;
	ret = ctiot_send_data_request(&req, msgID);
	return ret;
}

CTIOT_STATUS ctiot_send_compact_with_rlt_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID,
												   SDK_U16 payloadLen, SDK_U8 *payload, SDK_U16 resultLen, SDK_U8 *result, SDK_U8 qos,SDK_U32 upDataSN, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_DATA_REQ req = {0};
	req.qos = qos;
	req.upDataSN = upDataSN;
	req.payloadType = payloadType;
	req.u.compactWithRslt.datasetID = dataSetID;
	req.u.compactWithRslt.resultLen = resultLen;
	req.u.compactWithRslt.result = result;
	req.u.compactWithRslt.payloadLen = payloadLen;
	req.u.compactWithRslt.payload = payload;
	ret = ctiot_send_data_request(&req, msgID);
	return ret;
}

CTIOT_STATUS ctiot_send_json_mode_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_DATA_REQ req = {0};
	req.qos = qos;
	req.payloadType = payloadType;
	req.u.json.u.datasetID = dataSetID;
	req.u.json.payload = payload;
	ret = ctiot_send_data_request(&req, msgID);
	return ret;
}

CTIOT_STATUS ctiot_send_json_data(CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 dataSetID, SDK_U8 *payload, SDK_U8 qos,SDK_U32 upDataSN, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_DATA_REQ req = {0};
	req.qos = qos;
	req.upDataSN = upDataSN;
	req.payloadType = payloadType;
	req.u.json.u.datasetID = dataSetID;
	req.u.json.payload = payload;
	ret = ctiot_send_data_request(&req, msgID);
	return ret;
}

CTIOT_STATUS ctiot_validate_send_data_para(CTIOT_MQTT_DATA_REQ *ptrDataRequest)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if(!(ptrDataRequest->qos == QOS0 || ptrDataRequest->qos == QOS1))
	{
		ret = CTIOT_SEND_DATA_INVALIDE_QOS;
		goto exit;
	}
	if (ptrDataRequest->payloadType == COMPACT_MODE)
	{
		if ( ptrDataRequest->u.compact.payload == NULL || ptrDataRequest->u.compact.payloadLen == 0)
		{
			ret = CTIOT_SEND_DATA_INVALIDE_PAYLOAD;
			goto exit;
		}
	}
	else if (ptrDataRequest->payloadType == COMPACT_WITH_RLT_MODE)
	{
		if ( ptrDataRequest->u.compactWithRslt.payload == NULL || ptrDataRequest->u.compactWithRslt.payloadLen == 0 )
		{
			ret = CTIOT_SEND_DATA_INVALIDE_PAYLOAD;
			goto exit;
		}
		if( ptrDataRequest->u.compactWithRslt.result == NULL || ptrDataRequest->u.compactWithRslt.resultLen == 0)
		{
			ret = CTIOT_SEND_DATA_INVALIDE_RESULT;
			goto exit;
		}
	}
	else if (ptrDataRequest->payloadType == JSON_MODE)
	{
		if (ptrDataRequest->u.json.payload == NULL || strlen(ptrDataRequest->u.json.payload) == 0)
		{
			ret = CTIOT_SEND_DATA_INVALIDE_PAYLOAD;
			goto exit;
		}
	}
	else
	{
		ret = CTIOT_SEND_DATA_INVALIDE_PAYLOADTYPE;
	}
exit:
	return ret;
}

#endif

#if defined(USE_CTIOT_REMOTECTRL_EXCUTE)
CTIOT_STATUS ctiot_remote_ctrl_cnf_validation(CTIOT_MQTT_REMOTE_CTRL_CNF *ptrCnf)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ptrCnf->additionalInfo == NULL && ptrCnf->additionalInfoLen != 0)
	{
		return CTIOT_REMOTECTRL_INVALIDE_ADDITIONAL_INFO;
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_remote_ctrl_confirm(CTIOT_MQTT_REMOTE_CTRL_CNF *ptrCnf, SDK_U32 *msgID)
{
	CTIOT_STATUS result = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		result = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return result;
	}
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;
	result = ctiot_remote_ctrl_cnf_validation(ptrCnf);
	if (result != CTIOT_SUCCESS)
	{
		goto exit;
	}

	//1.encode remote ctrl data
	CTIOT_PARAMS updata_params;
	SDK_U32 updata_sn = ctiot_generate_packet_sn();
	updata_params = (CTIOT_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_BINARY, ptrCnf->additionalInfoLen}}};
	result = ctiot_encode(&stream, &len, updata_params, updata_sn, CMD_ID_REMOTE_CTRL_CNF, ptrCnf->dmsn, ptrCnf->controlType, ptrCnf->resultCode, ptrCnf->additionalInfo);
	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Encode remote ctrl cnf data,length:%u\n", len);
	log_print_array(stream, len);
	log_print_mark_end();
#endif
	//2.publish remote ctrl data
	result = ctiot_tlink_publish_request(len, stream, TOPIC_REMOTE_CTRL_CNF, ptrCnf->qos, msgID);
exit:
	OS_PUT_MEM(stream);
	return result;
}

CTIOT_STATUS ctiot_send_remote_ctrl_cnf(SDK_U32 dmsn, SDK_U16 controlType, SDK_U8 resultCode, SDK_U16 additionalInfoLen, SDK_U8 *additionalInfo, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_MQTT_REMOTE_CTRL_CNF cnf;
	cnf.qos = QOS_REMOTE_CTRL_CNF;
	cnf.dmsn = dmsn;
	cnf.controlType = controlType;
	cnf.resultCode = resultCode;
	cnf.additionalInfo = additionalInfo;
	cnf.additionalInfoLen = additionalInfoLen;
	ret = ctiot_remote_ctrl_confirm(&cnf, msgID);
	return ret;
}
#endif

CTIOT_STATUS ctiot_get_last_error()
{
	return globalLastError;
}
void ctiot_set_last_error(CTIOT_STATUS *ptrStatus, CTIOT_STATUS status)
{
	*ptrStatus = status;
	if (status == CTIOT_MQTT_YIELD_FAIL || status == CTIOT_MQTT_PUBLISH_FAIL || status == CTIOT_MQTT_NOT_CONNECTED || (ctiot_get_status() == RDAP_STATE_BEFORE_LOGIN && ((status == CTIOT_MQTT_CONNECT_FAIL) || (status == CTIOT_OS_SOCK_CONNECT_FAIL) || (status == CTIOT_TLS_ROOT_CERTIFICATE_ERROR) || (status == CTIOT_TLS_CLIENT_CERTIFICATE_ERROR) || (status == CTIOT_TLS_CLIENT_KEY_ERROR) || (status == CTIOT_TLS_HANDSHAKE_ERROR))) || status == CTIOT_OS_NOT_ENOUGH_MEM)
	{
		if(ctiot_lost_connection_ind_callback != NULL && ( status == CTIOT_MQTT_YIELD_FAIL || status == CTIOT_MQTT_PUBLISH_FAIL || status == CTIOT_MQTT_NOT_CONNECTED || status == CTIOT_OS_NOT_ENOUGH_MEM) )
		{
			ctiot_lost_connection_ind_callback(status);
		}
		ctiot_set_status(RDAP_STATE_ERROR);
	}
}
void ctiot_clear_error()
{
	globalLastError = CTIOT_SUCCESS;
}
#if 1
CTIOT_STATUS ctiot_validate_login_para(CTIOT_MQTT_LOGIN_REQ *ptrLoginRequestPara)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (!(ptrLoginRequestPara->utcOffset[0] == '+' || ptrLoginRequestPara->utcOffset[0] == '-') || ptrLoginRequestPara->utcOffset[3] != ':')
	{
		ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
		goto exit;
	}
	else
	{
		if(ptrLoginRequestPara->utcOffset[0] == '+')
		{
			if(ptrLoginRequestPara->utcOffset[1] > '1' || ptrLoginRequestPara->utcOffset[1] < '0')
			{
				ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
				goto exit;
			}
			if(ptrLoginRequestPara->utcOffset[1] == '1' &&  (ptrLoginRequestPara->utcOffset[2] < '0' || ptrLoginRequestPara->utcOffset[2] > '2'))
			{
				ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
				goto exit;	
			}
			if(ptrLoginRequestPara->utcOffset[1] == '0' &&  (ptrLoginRequestPara->utcOffset[2] < '0' || ptrLoginRequestPara->utcOffset[2] > '9'))
			{
				ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
				goto exit;
			}
		}
		if(ptrLoginRequestPara->utcOffset[0] == '-')
		{
			if(ptrLoginRequestPara->utcOffset[1] > '1' || ptrLoginRequestPara->utcOffset[1] < '0')
			{
				ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
				goto exit;
			}
			if(ptrLoginRequestPara->utcOffset[1] == '1' &&  (ptrLoginRequestPara->utcOffset[2] < '0' || ptrLoginRequestPara->utcOffset[2] > '4'))
			{
				ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
				goto exit;	
			}
			if(ptrLoginRequestPara->utcOffset[1] == '0' &&  (ptrLoginRequestPara->utcOffset[2] < '0' || ptrLoginRequestPara->utcOffset[2] > '9'))
			{
				ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
				goto exit;
			}
		}
		if(ptrLoginRequestPara->utcOffset[4] > '5' || ptrLoginRequestPara->utcOffset[4] < '0' || ptrLoginRequestPara->utcOffset[5] > '9' || ptrLoginRequestPara->utcOffset[5] < '0')
		{
			ret = CTIOT_LOGIN_INVALID_UTCOFFSET;
			goto exit;
		}
	}
	
	if ((ptrLoginRequestPara->identity.identityMode == 2 && n.connect_mode != 3) || (ptrLoginRequestPara->identity.identityMode != 2 && n.connect_mode == 3))
	{
		ret = CTIOT_LOGIN_INVALID_IDENTITYMODE;
		goto exit;
	}

	if (ptrLoginRequestPara->identity.identityMode == 1 || ptrLoginRequestPara->identity.identityMode == 3)
	{
		if (ptrLoginRequestPara->identity.identityLength == 0 || ptrLoginRequestPara->identity.identity == NULL)
		{
			ret = CTIOT_LOGIN_INVALID_IDENTITYVALUE;
			goto exit;
		}
	}

	int softwareVersionLen = strlen(ptrLoginRequestPara->softwareVersion);
	if (softwareVersionLen == 0 || softwareVersionLen > 64)
	{
		ret = CTIOT_LOGIN_INVALID_SOFTWAREVERSION;
		goto exit;
	}

	if (ptrLoginRequestPara->deviceType != NULL)
	{
		int deviceInfoLen = strlen(ptrLoginRequestPara->deviceType);
		if (deviceInfoLen == 0 || deviceInfoLen > 64)
		{
			ret = CTIOT_LOGIN_INVALID_DEVICEINFO;
			goto exit;
		}
	}

	if(ptrLoginRequestPara->deviceNo == NULL || strlen(ptrLoginRequestPara->deviceNo) == 0)
	{
		ret = CTIOT_LOGIN_INVALID_DEVICENO; 
		goto exit;
	}

	int deviceIdLen = strlen(ptrLoginRequestPara->deviceNo);
	if (deviceIdLen == 0 || deviceIdLen > 64)
	{
		ret = CTIOT_LOGIN_INVALID_DEVICENO;
	}
exit:
	return ret;
}
#endif

CTIOT_STATUS ctiot_validate_mqtt_message(MessageData *ptrMsgdata)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ptrMsgdata == NULL)
	{
		ret = CTIOT_OS_NULL_POINTER;
		goto exit;
	}
	if (ptrMsgdata->message == NULL)
	{
		ret = CTIOT_MQTT_PAYLOAD_BLANK;
		goto exit;
	}
	if (ptrMsgdata->message->payloadlen > MAX_PAYLOAD_LEN)
	{
		ret = CTIOT_MQTT_PAYLOAD_OVERFLOW;
		goto exit;
	}
	if (ptrMsgdata->message->payloadlen == 0 || ptrMsgdata->message->payload == NULL)
	{
		ret = CTIOT_MQTT_PAYLOAD_BLANK;
		goto exit;
	}
	if (ptrMsgdata->topicName == NULL)
	{
		ret = CTIOT_MQTT_TOPIC_BLANK;
		goto exit;
	}
	if (ptrMsgdata->topicName->cstring != NULL)
	{
		if (strlen(ptrMsgdata->topicName->cstring) == 0)
		{
			ret = CTIOT_MQTT_TOPIC_BLANK;
			goto exit;
		}
	}
	else
	{
		if (ptrMsgdata->topicName->lenstring.len == 0)
		{
			ret = CTIOT_MQTT_TOPIC_BLANK;
			goto exit;
		}
		if (ptrMsgdata->topicName->lenstring.data == NULL)
		{
			ret = CTIOT_MQTT_TOPIC_BLANK;
			goto exit;
		}
	}
exit:
	return ret;
}

#if defined(USE_CTIOT_EVENT_REPORT)

CTIOT_STATUS ctiot_validate_event_report_para(SDK_U32 eventSn, SDK_U16 eventID, SDK_U64 eventTime, SDK_U8 eventType,
											  CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 payloadLen, SDK_U8 *payload,SDK_U8 qos)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (!(eventType == 0 || eventType == 1 || eventType == 2 || eventType == 3))
	{
		ret = CTIOT_EVENT_REPORT_INVALIDE_EVENTTYPE;
		goto exit;
	}
	if (payload != NULL && !(payloadType == COMPACT_MODE || payloadType == JSON_MODE))
	{
		ret = CTIOT_EVENT_REPORT_INVALIDE_PAYLOADTYPE;
		goto exit;
	}
	if(payload != NULL && payloadLen <= 0)
	{
		ret = CTIOT_EVENT_REPORT_INVALIDE_PAYLOAD ;
		goto exit;
	}
	if(!(qos == QOS0 || qos == QOS1))
	{
		ret = CTIOT_EVENT_REPORT_INVALIDE_QOS;
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_event_report(SDK_U32 eventSn, SDK_U16 eventID, SDK_U64 eventTime, SDK_U8 eventType,
								CTIOT_MQTT_PAYLOAD_TYPE payloadType, SDK_U16 payloadLen, SDK_U8 *payload, SDK_U8 qos, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		ret = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return ret;
	}
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;
	SDK_U32 upDataSn = ctiot_generate_packet_sn();
	SDK_U8 cmdType = CMD_ID_EVENT_REPORT;
	int i;

	//1.validate data
	CTIOT_STATUS result = ctiot_validate_event_report_para(eventSn, eventID, eventTime, eventType, payloadType, payloadLen, payload,qos);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_event_report:ctiot_validate_event_report_para:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}

#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("cmdType:%hhu\n", cmdType);
	log_print_plain_text("eventSn:%u\n", eventSn);
	log_print_plain_text("eventID:%hu\n", eventID);
	log_print_plain_text("eventTime:%llu\n", eventTime);
	log_print_plain_text("eventType:%hhu\n", eventType);
	log_print_plain_text("payloadType:%d\n", payloadType);
	log_print_plain_text("payloadLen:%hu\n", payloadLen);
	if (payloadType == 0 && payload != NULL)
	{
		log_print_plain_text("payload:");
		for (i = 0; i < payloadLen; i++)
			log_print_plain_text("%02x", payload[i]);
		log_print_plain_text("\n");
	}
	else if (payloadType == 2 && payload != NULL)
	{
		log_print_plain_text("payloadLen:%s\n", payload);
	}
#endif
	
	//2.encode data
	CTIOT_PARAMS eventReportParams;
	if (payload == NULL)
	{
		eventReportParams = (CTIOT_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 8}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
		result = ctiot_encode(&stream, &len, eventReportParams, upDataSn, CMD_ID_EVENT_REPORT, eventSn, eventID, eventTime, eventType);
	}
	else if (payloadType == 0)
	{
		eventReportParams = (CTIOT_PARAMS){8, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 8}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_BINARY, payloadLen}}};
		result = ctiot_encode(&stream, &len, eventReportParams, upDataSn, CMD_ID_EVENT_REPORT, eventSn, eventID, eventTime, eventType, payloadType, payload);
	}
	else if (payloadType == 2)
	{
		eventReportParams = (CTIOT_PARAMS){8, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 8}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_TEXT, payloadLen}}};
		result = ctiot_encode(&stream, &len, eventReportParams, upDataSn, CMD_ID_EVENT_REPORT, eventSn, eventID, eventTime, eventType, payloadType, payload);
	}
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_event_report:ctiot_encode:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Encode event report data,length:%u\n", len);
	log_print_array(stream, len);
	log_print_mark_end();
#endif
	//3.publish upload data
	result = ctiot_tlink_publish_request(len, stream, TOPIC_EVENT_REPORT, qos, msgID);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_event_report:ctiot_tlink_publish_request:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
exit:
	OS_PUT_MEM(stream);
	return ret;
}
#endif

SDK_U16 ctiot_get_command_timeout()
{
	return (globalCommandTimeout == 0 ? MQTT_CMD_TIMEOUT_MS : globalCommandTimeout);
}

void ctiot_set_command_timeout(SDK_U16 commandTimeout)
{
	if (commandTimeout == 0)
	{
		globalCommandTimeout = MQTT_CMD_TIMEOUT_MS;
	}
	else
	{
		globalCommandTimeout = commandTimeout;
	}
}
SDK_U16 ctiot_get_read_socket_period()
{
	return (globalRreadSocketPeriod == 0 ? SOCKET_READ_TIMEOUT_MS : globalRreadSocketPeriod);
}

void ctiot_set_read_socket_period(SDK_U16 readSocketPeriod)
{
	if (readSocketPeriod == 0)
	{
		globalRreadSocketPeriod = SOCKET_READ_TIMEOUT_MS;
	}
	else
	{
		globalRreadSocketPeriod = readSocketPeriod;
	}
}

SDK_U16 ctiot_get_register_login_duration()
{
	return (globalRegLoginDuration == 0 ? MAX_LOGIN_DURATION : globalRegLoginDuration);
}

void ctiot_set_register_login_duration(SDK_U16 regLoginDuration)
{
	if (regLoginDuration == 0)
	{
		globalRegLoginDuration = MAX_LOGIN_DURATION;
	}
	else
	{
		globalRegLoginDuration = regLoginDuration;
	}
}

SDK_U16 ctiot_get_max_pdu_len_sent()
{
	return (globalMaxPduLenSent >= SDK_MIN_SEND_BUFFER_LEN ? globalMaxPduLenSent : SDK_MIN_SEND_BUFFER_LEN);
}

void ctiot_set_max_pdu_len_sent(SDK_U16 maxPduLenSent)
{
	if (maxPduLenSent < SDK_MIN_SEND_BUFFER_LEN)
	{
		globalRegLoginDuration = SDK_MIN_SEND_BUFFER_LEN;
	}
	else
	{
		globalRegLoginDuration = maxPduLenSent;
	}
}

SDK_U16 ctiot_get_max_pdu_len_recv()
{
	return (globalMaxPduLenRecv >= SDK_MIN_RECV_BUFFER_LEN ? globalMaxPduLenRecv : SDK_MIN_RECV_BUFFER_LEN);
}

void ctiot_set_max_pdu_len_recv(SDK_U16 maxPduLenRecv)
{
	if (maxPduLenRecv < SDK_MIN_RECV_BUFFER_LEN)
	{
		globalMaxPduLenRecv = SDK_MIN_RECV_BUFFER_LEN;
	}
	else
	{
		globalRegLoginDuration = maxPduLenRecv;
	}
}

CTIOT_STATUS ctiot_create_socket_buff()
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if( writebuf == NULL)
	{
		OS_GET_MEM(writebuf, SDK_U8, (globalMaxPduLenSent) > SDK_MIN_SEND_BUFFER_LEN ? globalMaxPduLenSent : SDK_MIN_SEND_BUFFER_LEN);
	}
	if (writebuf == NULL)
	{
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		goto exit;
	}
	if( readbuf == NULL )
	{
		OS_GET_MEM(readbuf, SDK_U8, (globalMaxPduLenRecv) > SDK_MIN_RECV_BUFFER_LEN ? globalMaxPduLenRecv : SDK_MIN_RECV_BUFFER_LEN);
	}
	if (readbuf == NULL)
	{
		OS_PUT_MEM(writebuf);
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
	}
exit:
	return ret;
}

void ctiot_release_socket_buff()
{
	OS_PUT_MEM(writebuf);
	OS_PUT_MEM(readbuf);
}

CTIOT_STATUS ctiot_realloc_socket_buff()
{
	ctiot_release_socket_buff();
	return ctiot_create_socket_buff();
}

CTIOT_STATUS ctiot_process_network_errors()
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	CTIOT_STATUS status = ctiot_get_last_error();
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_plain_text("ctiot_process_network_errors:ctiot_get_last_error:%d!\n", status);
#endif
	if (ctiot_get_status() != RDAP_STATE_LOGINED && ctiot_get_status() != RDAP_STATE_ERROR)
	{
		return ret;
	}
	if (status == CTIOT_MQTT_YIELD_FAIL || status == CTIOT_MQTT_PUBLISH_FAIL || status == CTIOT_MQTT_NOT_CONNECTED)
	{
		T_SDK_BOOL result = ctiot_close_session();
		if (result == SDK_TRUE)
		{
			ctiot_set_last_error(&globalLastError, CTIOT_SUCCESS);
		}
	}
	return ret;
}

#if defined(USE_CTIOT_ENQUIREPARA_EXCUTE)
CTIOT_STATUS ctiot_validate_enquire_para_confirm(CTIOT_MQTT_ENQUIRE_PARA_CNF *ptrConfirm)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ptrConfirm->resultCode < 0 || ptrConfirm->resultCode > 6)
	{
		ret = CTIOT_ENQUIREPARA_INVALIDE_RESULTCODE;
		goto exit;
	}
	if (ptrConfirm->resultCode == 0)
	{
		if (ptrConfirm->payloadType < 0 || ptrConfirm->payloadType > 2)
		{
			ret = CTIOT_ENQUIREPARA_INVALIDE_PAYLOADTYPE;
			goto exit;
		}
		if (ptrConfirm->payloadType == 0)
		{
			if (ptrConfirm->u.succ.compact.payload == NULL || ptrConfirm->u.succ.compact.payloadLen == 0)
			{
				ret = CTIOT_ENQUIREPARA_INVALIDE_PAYLOAD;
				goto exit;
			}
		}
		else if (ptrConfirm->payloadType == 1)
		{
			if (ptrConfirm->u.succ.compactWithRslt.payload == NULL || ptrConfirm->u.succ.compactWithRslt.payloadLen == 0)
			{
				ret = CTIOT_ENQUIREPARA_INVALIDE_PAYLOAD;
				goto exit;
			}
			if (ptrConfirm->u.succ.compactWithRslt.result == NULL || ptrConfirm->u.succ.compactWithRslt.resultLen == 0)
			{
				ret = CTIOT_ENQUIREPARA_INVALIDE_RESULT;
				goto exit;
			}
		}
		else if (ptrConfirm->payloadType == 2)
		{
			if (ptrConfirm->u.succ.json.payload == NULL || strlen(ptrConfirm->u.succ.json.payload) == 0)
			{
				ret = CTIOT_ENQUIREPARA_INVALIDE_PAYLOAD;
				goto exit;
			}
		}
		else
		{
			ret = CTIOT_ENQUIREPARA_INVALIDE_PAYLOADTYPE;
			goto exit;
		}
	}
	else if (ptrConfirm->resultCode == 4 && ptrConfirm->u.invalidData.json.payload != NULL) //无效参数内容
	{
		if (strlen(ptrConfirm->u.invalidData.json.payload) == 0)
		{
			ret = CTIOT_ENQUIREPARA_INVALIDE_PAYLOAD;
			goto exit;
		}
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_enquire_para_confirm(CTIOT_MQTT_ENQUIRE_PARA_CNF *ptrConfirm, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		ret = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return ret;
	}
	SDK_U8 *ptrStream = NULL;
	int len = 0;
	CTIOT_PARAMS params;
	SDK_U32 uppack_sn = ctiot_generate_packet_sn();
	SDK_U8 cmdType = CMD_ID_ENQUIRE_PARA_CNF; //0x88
	ret = ctiot_validate_enquire_para_confirm(ptrConfirm);
	if (ret != CTIOT_SUCCESS)
	{
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_plain_text("ctiot_enquire_para_confirm:ctiot_validate_enquire_para_confirm:%d!\n", ret);
#endif
		goto exit;
	}
	if (ptrConfirm->resultCode == 0)
	{
		if (ptrConfirm->payloadType == 0)
		{
			params = (CTIOT_PARAMS){7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, ptrConfirm->u.succ.compact.payloadLen}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode, ptrConfirm->payloadType, ptrConfirm->u.succ.compact.datasetID, ptrConfirm->u.succ.compact.payload);
		}
		else if (ptrConfirm->payloadType == 1)
		{
			params = (CTIOT_PARAMS){8, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, ptrConfirm->u.succ.compactWithRslt.resultLen}, {CTIOT_PARAM_TYPE_BINARY, ptrConfirm->u.succ.compactWithRslt.payloadLen}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode, ptrConfirm->payloadType, ptrConfirm->u.succ.compactWithRslt.datasetID, ptrConfirm->u.succ.compactWithRslt.result, ptrConfirm->u.succ.compactWithRslt.payload);
		}
		else if (ptrConfirm->payloadType == 2)
		{
			int len1 = strlen(ptrConfirm->u.succ.json.payload);
			params = (CTIOT_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_TEXT, len1}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode, ptrConfirm->payloadType, ptrConfirm->u.succ.json.payload);
		}
	}
	else if (ptrConfirm->resultCode == 4)
	{
		if (ptrConfirm->u.invalidData.json.payload == NULL)
		{
			params = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode);
		}
		else
		{
			int strle = strlen(ptrConfirm->u.invalidData.json.payload);
			params = (CTIOT_PARAMS){5, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_TEXT, strle}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode, ptrConfirm->u.invalidData.json.payload);
		}
	}
	else
	{
		params = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
		ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode);
	}
	if (ret != CTIOT_SUCCESS)
	{
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_plain_text("ctiot_enquire_para_confirm:ctiot_encode:%d!\n", ret);
#endif
		ctiot_set_last_error(&globalLastError, ret);
		goto exit;
	}
	ret = ctiot_tlink_publish_request(len, ptrStream, TOPIC_ENQUIRE_PARA_CNF, ptrConfirm->qos, msgID);
	if (ret != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, ret);
	}
exit:
	if (ptrStream != NULL)
		OS_PUT_MEM(ptrStream);
	return ret;
}
CTIOT_STATUS ctiot_enquire_para_conf(SDK_U32 dmsn,SDK_U8 resultCode,SDK_U8 payloadType,SDK_U16 datasetID,
					SDK_U16 payloadLen,SDK_U8 *payload,SDK_U16 resultLen,SDK_U8 *result,SDK_U32 *msgID)
{
	CTIOT_MQTT_ENQUIRE_PARA_CNF cnf = {0};
	cnf.dmsn = dmsn;
	cnf.resultCode = resultCode;
	cnf.payloadType = payloadType;
	cnf.qos = QOS_ENQUIRE_PARA_CNF;
	if(resultCode == 0)
	{
		if(payloadType == 0)
		{
			cnf.u.succ.compact.datasetID = datasetID;
			cnf.u.succ.compact.payloadLen = payloadLen;
			cnf.u.succ.compact.payload = payload;
		}
		else if(payloadType == 1)
		{
			cnf.u.succ.compactWithRslt.datasetID = datasetID;
			cnf.u.succ.compactWithRslt.payloadLen = payloadLen;
			cnf.u.succ.compactWithRslt.payload = payload;
			cnf.u.succ.compactWithRslt.resultLen = resultLen;
			cnf.u.succ.compactWithRslt.result = result;
		}
		else if(payloadType == 2)
		{
			cnf.u.succ.json.payload = payload; 
		}
	}
	else if(resultCode == 4)
	{	
		cnf.u.invalidData.json.payload = payload;
	}
	return ctiot_enquire_para_confirm(&cnf, msgID);
}

#endif

#if defined(USE_CTIOT_SETPARA_EXCUTE)
CTIOT_STATUS ctiot_validate_set_para_confirm(CTIOT_MQTT_SET_PARA_CNF *ptrConfirm)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ptrConfirm->resultCode < 0 || ptrConfirm->resultCode > 7)
	{
		ret = CTIOT_SETPARA_INVALID_RESULTCODE;
		goto exit;
	}
	if (ptrConfirm->resultCode == 1 || ptrConfirm->resultCode == 2 || ptrConfirm->resultCode == 5)
	{
		if (ptrConfirm->u.compact.payload != NULL || ptrConfirm->u.json.payload != NULL)
		{
			if (ptrConfirm->payloadType != 1 && ptrConfirm->payloadType != 2)
			{
				ret = CTIOT_SETPARA_INVALID_PAYLOADTYPE;
			}
			if (ptrConfirm->payloadType == 1)
			{
				if (ptrConfirm->u.compact.payload == NULL || ptrConfirm->u.compact.payloadLen == 0)
				{
					ret = CTIOT_SETPARA_INVALIDE_RESULT;
					goto exit;
				}
			}
			if (ptrConfirm->payloadType == 2)
			{
				if (ptrConfirm->u.json.payload == NULL || strlen(ptrConfirm->u.json.payload) == 0)
				{
					ret = CTIOT_SETPARA_INVALIDE_PAYLOAD;
					goto exit;
				}
			}
		}
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_set_para_confirm(CTIOT_MQTT_SET_PARA_CNF *ptrConfirm, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		ret = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		return ret;
	}
	SDK_U8 *ptrStream = NULL;
	int len = 0;
	CTIOT_PARAMS params;
	SDK_U32 uppack_sn = ctiot_generate_packet_sn();
	SDK_U8 cmdType = CMD_ID_SET_PARA_CNF; //0x89
	ret = ctiot_validate_set_para_confirm(ptrConfirm);
	if (ret != CTIOT_SUCCESS)
	{
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_plain_text("ctiot_enquire_para_confirm:ctiot_validate_enquire_para_confirm:%d!\n", ret);
#endif
		goto exit;
	}
	if (ptrConfirm->resultCode == 1 || ptrConfirm->resultCode == 2 || ptrConfirm->resultCode == 5)
	{
		if (ptrConfirm->u.compact.payload == NULL && ptrConfirm->u.json.payload == NULL)
		{
			params = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode);
		}
		else if (ptrConfirm->payloadType == 1)
		{
			params = (CTIOT_PARAMS){7, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, ptrConfirm->u.compact.payloadLen}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode, ptrConfirm->payloadType, ptrConfirm->u.compact.datasetID, ptrConfirm->u.compact.payload);
		}
		else if (ptrConfirm->payloadType == 2)
		{
			int len1 = strlen(ptrConfirm->u.json.payload);
			params = (CTIOT_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_TEXT, len1}}};
			ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode, ptrConfirm->payloadType, ptrConfirm->u.json.payload);
		}
	}
	else
	{
		params = (CTIOT_PARAMS){4, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}}};
		ret = ctiot_encode(&ptrStream, &len, params, uppack_sn, cmdType, ptrConfirm->dmsn, ptrConfirm->resultCode);
	}
	if (ret != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, ret);
		goto exit;
	}

	ret = ctiot_tlink_publish_request(len, ptrStream, TOPIC_ENQUIRE_PARA_CNF, ptrConfirm->qos, msgID);
	if (ret != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, ret);
	}
exit:
	if (ptrStream != NULL)
		OS_PUT_MEM(ptrStream);
	return ret;
}

CTIOT_STATUS ctiot_set_para_conf(SDK_U32 dmsn,SDK_U8 resultCode,SDK_U8 payloadType,SDK_U16 datasetID,
								SDK_U16 payloadLen,SDK_U8* payload,SDK_U32 *msgID)
{
	CTIOT_MQTT_SET_PARA_CNF ptrConfirm = {0};
	ptrConfirm.dmsn = dmsn;
	ptrConfirm.resultCode = resultCode;
	ptrConfirm.qos = QOS_SET_PARA_CNF;
	ptrConfirm.payloadType = payloadType;
	if(payloadType == 1)
	{
		ptrConfirm.u.compact.datasetID = datasetID;
		ptrConfirm.u.compact.payloadLen = payloadLen;
		ptrConfirm.u.compact.payload = payload;
	}
	else if(payloadType == 2)
	{
		ptrConfirm.u.json.payload = payload;
	}
	else if (payload != NULL)
	{
		return CTIOT_SETPARA_INVALID_PAYLOADTYPE;
	}
	return ctiot_set_para_confirm(&ptrConfirm,msgID);
}

#endif

CTIOT_STATUS ctiot_tlink_publish_request(SDK_U16 len, SDK_U8 *ptrPayload, char *ptrTopic, SDK_U8 qos, SDK_U32 *msgID) //id
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ptrTopic == NULL || strlen(ptrTopic) <= 0)
	{
		ret = CTIOT_MQTT_PUBLISH_WRONGTOPIC;
		goto exit;
	}
	if ( len > (globalMaxPduLenSent - 2 - 8 - 2 - 10)) //2为MQTT头，8位TOPIC，2为报文序列号，10作为额外保护
	{
		ret = CTIOT_MQTT_BUFFER_OVERFLOW;
		goto exit;
	}
	if (len <= 0 || ptrPayload == NULL)
	{
		ret = CTIOT_MQTT_PUBLISH_WRONGPAYLOAD;
		goto exit;
	}
	T_RDAP_MSG *ptrMsg = NULL;
	T_RDAP_PUBLISH_EVENT_REQ *ptrEvent = NULL;

	OS_GET_MEM(ptrMsg, T_RDAP_MSG, sizeof(T_RDAP_MSG));
	if (ptrMsg == NULL)
	{
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		ctiot_set_last_error(&globalLastError, CTIOT_OS_NOT_ENOUGH_MEM);
		goto exit;
	}
	OS_GET_MEM(ptrEvent, T_RDAP_PUBLISH_EVENT_REQ, sizeof(T_RDAP_PUBLISH_EVENT_REQ));
	if (ptrEvent == NULL)
	{
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		ctiot_set_last_error(&globalLastError, CTIOT_OS_NOT_ENOUGH_MEM);
		OS_PUT_MEM(ptrMsg);
		goto exit;
	}
	ptrEvent->len = len;
	OS_GET_MEM(ptrEvent->payload, SDK_U8, len);
	if (ptrEvent->payload == NULL)
	{
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		OS_PUT_MEM(ptrMsg);
		OS_PUT_MEM(ptrEvent);
		ctiot_set_last_error(&globalLastError, CTIOT_OS_NOT_ENOUGH_MEM);
		goto exit;
	}
	memcpy(ptrEvent->payload, ptrPayload, len);

	OS_GET_MEM(ptrEvent->topic, char, strlen(ptrTopic) + 1);
	if (ptrEvent->topic == NULL)
	{
		ret = CTIOT_OS_NOT_ENOUGH_MEM;
		ctiot_set_last_error(&globalLastError, CTIOT_OS_NOT_ENOUGH_MEM);
		OS_PUT_MEM(ptrMsg);
		OS_PUT_MEM(ptrEvent->payload);
		OS_PUT_MEM(ptrEvent);

		goto exit;
	}
	memcpy(ptrEvent->topic, ptrTopic, strlen(ptrTopic) + 1);
	ptrEvent->qos = qos;
	ptrMsg->msgType = RDAP_PUBLISH_EVENT_REQ;
	ptrMsg->ptrMsg = (SDK_U8 *)ptrEvent;
	ptrMsg->msgID = ctiot_tlink_getnextmid(&tlinkClient);
	ptrMsg->retrans = globalQOSMaxRetrans;
	ptrMsg->status = TLINK_QUEUE_WAIT_FOR_SEND;
	(*msgID) = ptrMsg->msgID;
	ret = tlink_add_msg(&tlinkQueue, ptrMsg);

	if (ret != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, CTIOT_QUEUE_OUT_BORDER);
		if (ret == CTIOT_QUEUE_OUT_BORDER)
		{
#ifdef ERR_LEVEL_LOG_COMPILE
			log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_tlink_publish_request:tlink_add_msg:result=%d\n", ret);
#endif
		}
		OS_PUT_MEM(ptrEvent->payload);
		OS_PUT_MEM(ptrEvent->topic);
		OS_PUT_MEM(ptrEvent);
		OS_PUT_MEM(ptrMsg);
	}
	else
	{
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_plain_text("ctiot_tlink_publish_request:tlink_add_msg success msgID: %d\n", ptrMsg->msgID);
#endif
	}

exit:
	return ret;
}

static SDK_U32 ctiot_tlink_getnextmid(TLINK_CLIENT *tlink)
{
	return tlink->nextMID = (tlink->nextMID == MAX_PACKET_ID) ? 1 : tlink->nextMID + 1;
}

//Write the function of handling PUBACK msg
void ctiot_tlink_handlemessage(unsigned short myPacketid)
{
	T_SDK_BOOL rc;
	SDK_U32 msgID = 0;
	rc = tlink_remove_msg_by_packetid(&tlinkQueue, myPacketid, &msgID);
	if (rc == SDK_TRUE)
	{
#ifdef ID_LEVEL_LOG_COMPILE
		log_print_plain_text("ctiot_tlink_handlemessage msgID: %d, packetID: %d\n", msgID, myPacketid);
#endif
		if (ctiot_msg_status_callback != NULL)
		{
			ctiot_msg_status_callback(msgID, TLINK_QUEUE_SUCCESS);
		}
	}
	else
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(INFO_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_tlink_handlemessage no matching packetID = %d! \n", myPacketid);
#endif
	}
}

#if defined(USE_CTIOT_FILE_UPLOAD)
CTIOT_STATUS ctiot_file_upload_request(SDK_U32 upSmallFileSN, SDK_U32 fileNameLen, SDK_U8 *fileName, SDK_U32 fileSize, SDK_U16 blockNum, SDK_U16 blockSize, SDK_U8 *checksum, SDK_U32 *msgID)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (ctiot_get_status() != RDAP_STATE_LOGINED)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_login_request:CTIOT_NOT_LOGINED\n");
#endif
		ret = CTIOT_NOT_LOGINED;
		ctiot_set_last_error(&globalLastError, CTIOT_NOT_LOGINED);
		goto exit;
	}
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;

	//1.validate transparent data
	CTIOT_STATUS result = ctiot_validate_file_upload_para(upSmallFileSN, fileNameLen, fileName, fileSize, blockNum, blockSize, checksum);

	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_file_upload_request:ctiot_validate_file_upload_para:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	//2.construct transparent data
	CTIOT_PARAMS file_upload_params;
	file_upload_params = (CTIOT_PARAMS){8, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_TEXT, fileNameLen}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY_STATIC, 16}}};

	//3.encode transparent data
	SDK_U32 upPacketsn = ctiot_generate_packet_sn();
	result = ctiot_encode(&stream, &len, file_upload_params, upPacketsn, CMD_ID_FILE_UPLOAD_REQ, upSmallFileSN, fileName, fileSize, blockNum, blockSize, checksum);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_file_upload_request:ctiot_encode_file_upload_request:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}

#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Encode transparent data,Length:%u\n", len);
	log_print_mark_end();
#endif

	//4.publish transparent data
	result = ctiot_tlink_publish_request(len, stream, TOPIC_FILE_UPLOAD_REQ, 1, msgID);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_file_upload_request:ctiot_tlink_publish_request:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
	}
	//5.destruct transparent data
exit:
	OS_PUT_MEM(stream);
	return ret;
}

CTIOT_STATUS ctiot_validate_file_upload_para(SDK_U32 upSmallFileSN, SDK_U32 fileNameLen, SDK_U8 *fileName, SDK_U32 fileSize, SDK_U16 blockNum, SDK_U16 blockSize, SDK_U8 *checksum)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (blockNum > 1000)
	{
		ret = CTIOT_FILE_UPLOAD_INVALID_BLOCK_NUM;
		goto exit;
	}
	if (fileName == NULL)
	{
		ret = CTIOT_FILE_UPLOAD_INVALIDE_FILENAME;
		goto exit;
	}
	if (fileNameLen == 0)
	{
		ret = CTIOT_FILE_UPLOAD_INVALIDE_FILENAME_LEN;
		goto exit;
	}
	if (checksum == NULL)
	{
		ret = CTIOT_FILE_UPLOAD_INVALIDE_CHECKSUM;
		goto exit;
	}
exit:
	return ret;
}

CTIOT_STATUS ctiot_file_content_upload_request(SDK_U32 upSmallFileSN, SDK_U8 isLastBlock, SDK_U16 blockSeq, SDK_U32 blockContentLen, SDK_U8 *blockContent)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	SDK_U8 *stream = NULL;
	SDK_U16 len = 0;
	//1.validate transparent data
	CTIOT_STATUS result = ctiot_validate_file_content_upload_para(upSmallFileSN, isLastBlock, blockSeq, blockContentLen, blockContent);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_file_content_upload_request:ctiot_validate_file_content_upload_para:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	//2.construct transparent data
	CTIOT_PARAMS file_content_upload_params;
	file_content_upload_params = (CTIOT_PARAMS){6, {{CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 4}, {CTIOT_PARAM_TYPE_DIGIT, 1}, {CTIOT_PARAM_TYPE_DIGIT, 2}, {CTIOT_PARAM_TYPE_BINARY, blockContentLen}}};
	//3.encode transparent data
	SDK_U32 upPacketsn = ctiot_generate_packet_sn();
	result = ctiot_encode(&stream, &len, file_content_upload_params, upPacketsn, CMD_ID_FILE_CONTENT_UPLOAD_REQ, upSmallFileSN, isLastBlock, blockSeq, blockContent);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_file_upload_request:ctiot_validate_file_content_upload_para:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}

#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("Encode ctiot_file_content_upload_request data,Length:%u\n", len);
	log_print_mark_end();
#endif
	SDK_U32 msgID = 0;
	//4.publish transparent data
	result = ctiot_tlink_publish_request(len, stream, TOPIC_FILE_UPLOAD_REQ, 0, &msgID);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_file_content_upload_request:ctiot_tlink_publish_request:result=%d\n", result);
#endif
		ret = result;
		ctiot_set_last_error(&globalLastError, result);
	}
exit:
	OS_PUT_MEM(stream);
	return ret;
}

CTIOT_STATUS ctiot_validate_file_content_upload_para(SDK_U32 upSmallFileSN, SDK_U8 isLastBlock, SDK_U16 blockSeq, SDK_U32 blockContentLen, SDK_U8 *blockContent)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	if (blockContent == NULL)
	{
		ret = CTIOT_FILE_UPLOAD_INVALID_BLOCKCONTENT;
		goto exit;
	}
exit:
	return ret;
}

//**************************************************
//
//! @brief  小文件上传（下行）解析功能
//!
//! @param MessageData* ptrMd,入参，见@ref MessageData
//!
//! @retval  无
//! @note   提示，可选
//
//**************************************************
void ctiot_file_upload_cof_arrived(MessageData *ptrMd)
{
	CTIOT_TLINK_FILE_UPLOAD_REQ appItf = {0};

	CTIOT_STATUS result = ctiot_validate_mqtt_message(ptrMd);
	if (result != CTIOT_SUCCESS)
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot_file_upload_cof_arrived: validate message error!\n:result=%d\n", result);
#endif
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
	MQTTMessage *m = ptrMd->message;
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("ctiot retrieve data arrived!\n");
	log_print_array(m->payload, m->payloadlen);
	log_print_mark_end();
#endif
	/*Parase message*/
	CTIOT_DECODE_PARAMS decodeParam = {4, {{CTIOT_PARAM_TYPE_DIGIT, 4, 0}, {CTIOT_PARAM_TYPE_DIGIT, 1, 0}, {CTIOT_PARAM_TYPE_DIGIT, 4, 0}, {CTIOT_PARAM_TYPE_DIGIT, 1, 0}}};
	result = ctiot_decode(m->payload, m->payloadlen, &decodeParam, 0);

	if (result != CTIOT_SUCCESS)
	{
		ctiot_set_last_error(&globalLastError, result);
		goto exit;
	}
#ifdef ID_LEVEL_LOG_COMPILE
	log_print_mark_begin();
	log_print_plain_text("DnPacketSN:%u\n", decodeParam.ctiot_decode_params[0].u.ctiot_u32value);
	log_print_plain_text("CMDType:%hhu\n", decodeParam.ctiot_decode_params[1].u.ctiot_u8value);
	log_print_plain_text("UpSmallFileSN:%u\n", decodeParam.ctiot_decode_params[2].u.ctiot_u32value);
	log_print_plain_text("ResultCode:%u\n", decodeParam.ctiot_decode_params[3].u.ctiot_u8value);
	log_print_mark_end();
#endif
	if (ctiot_file_upload_callback != NULL)
	{
		appItf.upSmallFileSN = decodeParam.ctiot_decode_params[2].u.ctiot_u32value;
		appItf.resultCode = decodeParam.ctiot_decode_params[3].u.ctiot_u8value;
		ctiot_file_upload_callback(&appItf);
	}
	else
	{
#ifdef ERR_LEVEL_LOG_COMPILE
		log_print(ERROR_LEVEL, LOG_FILE, LOG_FUNC, LOG_LINE, "ctiot file upload callback is null\n");
#endif
	}
exit:
	ctiot_release_decode_buffer(decodeParam);
}

CTIOT_STATUS ctiot_get_tlink_and_sdk_ver(TLINK_SDK_VER* tlinkSdkVer)
{
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	sprintf(tlinkSdkVer->ctiotTlinkVer,"V%d.%d",TLINKVER_1,TLINKVER_2);
	sprintf(tlinkSdkVer->ctiotModuleSDKVer,"%d.%d.%d",STANDARD_PROTOCOL,PRIMARY_VERSION,SECONDARY_VERSION);
	return ret;
}

#endif
