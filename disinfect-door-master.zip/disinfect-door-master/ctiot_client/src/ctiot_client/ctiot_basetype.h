/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#ifndef __CTIOT_BASETYPE_H
#define __CTIOT_BASETYPE_H

typedef   signed char  SDK_S8;
typedef unsigned char  SDK_U8;

typedef     short int  SDK_S16;
typedef unsigned short SDK_U16;

typedef   signed int   SDK_S32;
typedef unsigned int   SDK_U32;

typedef unsigned long long SDK_U64;

#define MAX_PAYLOAD_LEN 0xffff

typedef enum
{
	SDK_TRUE,
	SDK_FALSE
}T_SDK_BOOL;

#ifdef DEBUG

#define PRINT_STRING printf
#define PRINT_ARRAY(ARR,LEN)\
{\
    SDK_U16 cursor = 0;\
    SDK_U8* ptr = (SDK_U8*)ARR;\
    for(;cursor<LEN;cursor++)\
    {\
        printf("%02x",ptr[cursor]);\
    }\
    PRINT_STRING("\n");\
}
#define PRINT_MARK_BEGIN() {SDK_U8 cursor = 0; printf("\n");for(;cursor < 100;cursor++) printf("^"); printf("\n");}
#define PRINT_MARK_END() {SDK_U8 cursor = 0; printf("\n");for(;cursor < 100;cursor++) printf("v"); printf("\n");}
#else
#define PRINT_STRING(STR,...)
#define PRINT_ARRAY(ARR,LEN)
#define PRINT_MARK_BEGIN()
#define PRINT_MARK_END()
#endif

typedef enum
{
    CTIOT_PARAM_TYPE_DIGIT,
	CTIOT_PARAM_TYPE_TEXT,
	CTIOT_PARAM_TYPE_BINARY,
	CTIOT_PARAM_TYPE_TEXT_STATIC,
	CTIOT_PARAM_TYPE_BINARY_STATIC
}PARAM_TYPE;

typedef struct
{
	SDK_U8 ctiotTlinkVer[8];
	SDK_U8 ctiotModuleSDKVer[8];
}TLINK_SDK_VER;

typedef struct
{
    SDK_U8 ctiot_param_type;
	SDK_U16 ctiot_param_len;
}CTIOT_PARAM_ITEM;

typedef struct
{
	SDK_U8 ctiot_param_type;
	SDK_U16 ctiot_param_len;
	union 
	{
		SDK_U8 ctiot_u8value;
		SDK_U16 ctiot_u16value;
		SDK_U32 ctiot_u32value;
		SDK_U64 ctiot_u64value;
		SDK_U8* ctiot_content;
	}u;
}CTIOT_DECODE_PARAM_ITEM;

typedef struct
{
	SDK_U8  ctiot_param_type;
	SDK_U16 ctiot_param_len;
	SDK_U64 ctiot_min_value_or_len;
	SDK_U64 ctiot_max_value_or_len;
}CTIOT_VALIDATE_PARAM_ITEM;

typedef struct
{
    SDK_U8 ctiot_param_counts;
	CTIOT_PARAM_ITEM ctiot_params[11];
}CTIOT_PARAMS;

typedef struct{
	SDK_U8 ctiot_param_counts;
	CTIOT_DECODE_PARAM_ITEM ctiot_decode_params[10];
}CTIOT_DECODE_PARAMS;

typedef struct
{
    SDK_U8 ctiot_validate_param_count;
	CTIOT_VALIDATE_PARAM_ITEM ctiot_validate_params[7];
}CTIOT_VALIDATE_PARAMS;

typedef enum
{
	CTIOT_SUCCESS=0,
	CTIOT_UNKNOWN=999,							   //!< 未知异常
	CTIOT_BUFFER_OVERFLOW=998,					   //!< 缓存异常
	CTIOT_QUEUE_OUT_BORDER=997,                    //!< 队列数目越界
	CTIOT_NOT_LOGINED=996,                         //!< 用户未登录
	CTIOT_INVALID_PARAM_VALUE=995,                 //!< 非法值
	CTIOT_INVALID_PARAM_LEN=994,                   //!< 非法参数长度
	CTIOT_INVALID_NULL_PARAM=993,                  //!< 非法空指针参数
	CTIOT_INVALID_CMDTYPE=992,                     //!< 非法命令类型
	CTIOT_INIT_FAIL = 991,                         //!< 初始化失败
	CTIOT_NOT_INIT = 990,						   //!< 终端未初始化

	//系统状态异常
	CTIOT_OS_NULL_POINTER=201,                     //!< 空指针
	CTIOT_OS_SOCK_CONNECT_FAIL=202,                //!< SOCKET连接失败
	CTIOT_OS_FILE_OPEN_FAIL=203,                   //!< 文件打开异常（sample程序使用）
	CTIOT_DNS_ERROR=204,                           //!< dns解析出错（sample程序使用）
	CTIOT_TLS_ROOT_CERTIFICATE_ERROR = 205,        //!< TLS根证书加载失败
	CTIOT_TLS_CLIENT_CERTIFICATE_ERROR = 206,      //!< TLS终端证书加载失败
	CTIOT_TLS_CLIENT_KEY_ERROR = 207,              //!< TLS终端私钥加载失败
	CTIOT_TLS_HANDSHAKE_ERROR = 208,               //!< TLS HANDSHAKE失败
	CTIOT_OS_THREAD_OPEN_FAIL=209,                 //!< 线程打开异常
	CTIOT_OS_MUTEX_ERROR=210,                      //!< 线程互斥量出错
	CTIOT_OS_NOT_ENOUGH_MEM=211,                   //!< 内存不足

	//MQTT状态异常
	CTIOT_MQTT_BUFFER_OVERFLOW=301,                //!< buffer越界
	CTIOT_MQTT_PUBLISH_FAIL=302,                   //!< Publish失败
	CTIOT_MQTT_PUBLISH_WRONGTOPIC=303,             //!< Publish失败，错误的Topic
	CTIOT_MQTT_PUBLISH_WRONGPAYLOAD=304,           //!< Publish失败，Payload异常
	CTIOT_MQTT_PAYLOAD_BLANK=305,                  //!< 空的Payload
	CTIOT_MQTT_TOPIC_BLANK=306,                    //!< 空的topic
	CTIOT_MQTT_YIELD_FAIL=307,                     //!< MQTT循环错
	CTIOT_MQTT_PAYLOAD_OVERFLOW=308,               //!< payload长度越界
	CTIOT_MQTT_NOT_CONNECTED=309,                  //!< MQTT未连接
	CTIOT_MQTT_CONNECT_FAIL=310,                   //!< MQTT连接失败
	
	//MQTT连接异常
	CTIOT_SERVER_INVALID_CLIENTID=401,             //!< 连接失败，不合格的客户端标识符
	CTIOT_SERVER_NOT_USABLE=402,                   //!< 连接失败，服务端不可用
	CTIOT_SERVER_INVALID_MESSAGE_FORMAT=403,       //!< 连接失败，协议报文格式错误（无效的用户名或密码）
	CTIOT_SERVER_ILLEAGLE_TERMINAL=404,            //!< 连接失败，非法终端（连接已拒绝，未授权）
	CTIOT_SERVER_MQTT_VERSION_NOT_SUPPORTED=405,   //!< 连接失败，MQTT协议版本不支持

	//终端登录异常
	CTIOT_LOGIN_OTHER_REASON=440,                  //!< 登录失败，其它原因 
	CTIOT_LOGIN_SUBSCRIBE_FAIL=441,                //!< 登录失败，订阅失败
	CTIOT_LOGIN_AUTHORIZE_FAIL=442,                //!< 登录失败，终端鉴权失败
	CTIOT_LOGIN_UPLOAD_MODE_NOT_MATCH=443,         //!< 终端上报方式和平台记录不匹配

	CTIOT_LOGIN_INVALID_IDENTITYMODE=444,          //!< 登录失败，非法IdentityMode
	CTIOT_LOGIN_DECODE_ERROR=445,                  //!< 登录失败，解码失败
	CTIOT_LOGIN_ALREADY_LOGIN=446,                 //!< 登录失败，已经登录或正在登录
	CTIOT_LOGIN_INVALID_IDENTITYVALUE=447,         //!< 登录失败，非法Identity值
	CTIOT_LOGIN_INVALID_SOFTWAREVERSION=448,       //!< 登录失败，非法softwareVersion
	CTIOT_LOGIN_INVALID_DEVICEINFO=449,            //!< 登录失败，非法deviceInfo
	CTIOT_LOGIN_INVALID_DEVICENO=450,              //!< 登录失败，非法deviceNo
	CTIOT_LOGIN_WAIT_PUBLISH_TIMEOUT=451,          //!< 登录失败，等待PUBLISH报文超时
	CTIOT_LOGIN_INVALID_UTCOFFSET=452,             //!< 登录失败，utcOffset不正确

	//参数查询异常
	CTIOT_ENQUIREPARA_INVALIDE_PAYLOAD=501,        //!< 参数查询，无效参数内容（针对自定义文件模式和普通JSON模式）
	CTIOT_ENQUIREPARA_INVALIDE_PAYLOADTYPE=502,    //!< 参数查询，无效PayloadType参数内容
	CTIOT_ENQUIREPARA_INVALIDE_RESULTCODE=503,     //!< 参数查询，无效ResultCode参数内容
	CTIOT_ENQUIREPARA_INVALIDE_RESULT=504,         //!< 参数查询，无效ResultContent参数内容

	//参数设置异常
	CTIOT_SETPARA_INVALIDE_PAYLOAD=520,            //!< 参数配置，无效数据集内容（无法识别的配置参数（JSON），或参数值Value出错（JSON或紧凑二进制格式），或无法识别的配置文件）
	CTIOT_SETPARA_INVALID_RESULTCODE=521,          //!< 参数配置，无效resultcode参数内容
	CTIOT_SETPARA_INVALID_PAYLOADTYPE=522,         //!< 参数配置，无效PayloadType参数内容
	CTIOT_SETPARA_INVALIDE_RESULT=523,             //!< 参数配置，无效的DataSetResult
	
	//远程控制异常
	CTIOT_REMOTECTRL_INVALIDE_ADDITIONAL_INFO = 540,

	//数据上报异常
	CTIOT_SEND_DATA_INVALIDE_PAYLOAD=560,          //!< 数据上报，非法payload值
	CTIOT_SEND_DATA_INVALIDE_PAYLOADTYPE=561,      //!< 数据上报，无效数据类型
	CTIOT_SEND_DATA_INVALIDE_QOS=562,              //!< 数据上报，无效的QOS
	CTIOT_SEND_DATA_INVALIDE_RESULT=563,           //!< 数据上报，无效的DataCollectResult

	//事件上报异常
	CTIOT_EVENT_REPORT_INVALIDE_EVENTTYPE=580,     //!< 事件上报，eventType不合法
	CTIOT_EVENT_REPORT_INVALIDE_PAYLOADTYPE=581,   //!< 事件上报，payloadType不合法
	CTIOT_EVENT_REPORT_INVALIDE_PAYLOAD=582,       //!< 事件上报，payload为空
	CTIOT_EVENT_REPORT_INVALIDE_QOS=583,           //!< 事件上报，无效的QOS


	//透明传输上报异常
	CTIOT_TRANSPARENT_DATA_UL_INVALIDE_QOS=601,    //!< 透明数据上报，无效的QOS
	CTIOT_TRANSPARENT_DATA_UL_INVALIDE_PAYLOAD=602,//!< 透明数据上报，无效数据集类型

	//透明传输下行异常
	CTIOT_TRANSPARENT_DATA_DL_DECODE_ERROR=610,    //!<  透明数据下发，数据长度不够或者越界导致解码失败

	//数据获取异常
	CTIOT_RETRIEVEDATA_INVALIDE_DATASETTYPE=620,   //!< 数据获取，无效数据集类型
	CTIOT_RETRIEVEDATA_INVALIDE_DATASETID=621,     //!< 数据获取，无效数据集标识（终端无法识别的DatasetID）

	//数据获取回应异常
	CTIOT_RETRIEVE_DATA_INVALIDE_RESULTCODE = 630, //!< 数据获取返回报文，resultCode不合法
	CTIOT_RETRIEVE_DATA_INVALIDE_PAYLOADTYPE = 631,//!< 数据获取返回报文，payloadType不合法
	CTIOT_RETRIEVE_DATA_INVALIDE_RESULT = 632,     //!< 数据获取返回报文，dataCollectResult不合法
	CTIOT_RETRIEVE_DATA_INVALIDE_PAYLOAD = 633,    //!< 数据获取返回报文，payload不合法

	//小文件上传异常
	CTIOT_FILE_UPLOAD_INVALID_BLOCK_NUM = 634,	   //!< 小文件上传,文件分块数不合法
	CTIOT_FILE_UPLOAD_INVALID_BLOCKCONTENT = 635,  //!< 小文件上传,分块文件内容不合法
	CTIOT_FILE_UPLOAD_INVALIDE_FILENAME = 636,     //!< 小文件上传,文件名不合法
	CTIOT_FILE_UPLOAD_INVALIDE_FILENAME_LEN = 637, //!< 小文件上传,文件名长度不合法
	CTIOT_FILE_UPLOAD_INVALIDE_CHECKSUM = 638,     //!< 小文件上传,文件校验和不合法

	//指令下发异常
	CTIOT_CMD_DECODE_ERROR=651,                    //!< 指令下发，消息解码出错
	CTIOT_CMD_CMDTYPE_REQ_ERROR=652,
	CTIOT_CMD_DECODE_REQ_PAYLOAD_LEN_ERROR=653,
	CTIOT_CMD_DECODE_PLAYLOAD_TYPE_ERROR=654,

	CTIOT_CMD_CNF_INVALIDE_PAYLOAD=655,
	CTIOT_CMD_CNF_INVALIDE_PAYLOADTYPE=656,
	CTIOT_CMD_CNF_INVALIDE_RESULT=657
}CTIOT_STATUS;

typedef enum{
	MQTT_PROTOCOL,                                //!< 0–	MQTT公开协议
	STANDARD_PROTOCOL,                            //!< 1–	标准协议
	COAP_PROTOCOL                                 //!< 2–	CoAP/LWM2M协议
}CTIOT_PROTOCOLS;

#endif

