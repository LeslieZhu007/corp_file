/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include <stdio.h>
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_msg_handler.h"
#include "ctiot_tlink_client.h"
#include "ctiot_log.h"

int       loop_res;
pthread_t loop_tid;

int       async_res;
pthread_t async_tid;

void main()
{
	char command;
	//初始化返回值
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	//初始化操作
	ret = ctiot_test_init_req();
    printf("Input command please!\n");
	printf("Input \'h\' for help!\n");
    while(1)
	{
		scanf("%c",&command,1);
		switch(command)
		{
			case 'h':
			case 'H':
				printf("l:Login\n");
			#if defined(USE_CTIOT_SEND_DATA)
				printf("c:ctiot_send_compact_mode_data_req\n");
				printf("r:ctiot_send_compact_with_rlt_mode_data_req\n");
				printf("j:ctiot_send_json_mode_data_req\n");
			#endif
			#if defined(USE_CTIOT_TRANSPARENT_DATA_UL)
				printf("t:ctiot_send_tr_data_req\n");
			#endif
			#if defined(USE_CTIOT_EVENT_REPORT)
				printf("e:test_EventReportReq\n");
			#endif
			#if defined(USE_CTIOT_FILE_UPLOAD)
				printf("f:test_file_upload\n");
			#endif
				printf("o:logout\n");
				break;
		//终端登录
			case 'l':
			case 'L':
			ret = ctiot_test_login_req();
			if(ret != CTIOT_SUCCESS)
			{
			log_print_plain_text ("登录失败！\n");
			return;
			}
			break;
		#if defined(USE_CTIOT_SEND_DATA)
		//紧凑二进制数据上报
			case 'c': 
			case 'C':
			ret = ctiot_send_compact_mode_data_req();
			if(ret == CTIOT_SUCCESS)
			{
				printf ("紧凑二进制上报成功！\n");
			}
			else
			{
				printf ("紧凑二进制上报失败，错误码：%d！\n",ret);
			}
			break;	
		//带结果反馈的紧凑二进制数据上报
			case 'r': 
			case 'R':
			ret = ctiot_send_compact_with_rlt_mode_data_req();
			if(ret == CTIOT_SUCCESS){
				printf ("带结果反馈的紧凑二进制数据上报成功！\n");
			}else{
				printf ("带结果反馈的紧凑二进制数据上报失败，错误码：%d！\n",ret);
			}
			break;
		//Json数据上报
			case 'j':
			case 'J':
			ret = ctiot_send_json_mode_data_req();
			if(ret == CTIOT_SUCCESS){
				printf ("Json数据上报成功！\n");
			}else{
				printf ("Json数据上报失败，错误码：%d！\n",ret);
			}
			break;
		#endif
		#if defined(USE_CTIOT_TRANSPARENT_DATA_UL)
		//透明传输上行
			case 't':
			case 'T':
			ret = ctiot_send_tr_data_req();
			if(ret == CTIOT_SUCCESS){
				printf ("透明传输上行成功！\n");
			}else{
				printf ("透明传输上行失败，错误码：%d！\n",ret);
			}
			break;
		#endif
		#if defined(USE_CTIOT_EVENT_REPORT)
		//事件上报
			case 'e':
			case 'E':
			ret = test_EventReportReq();
			if(ret == CTIOT_SUCCESS){
				printf ("事件上报成功！\n");
			}else{
				printf ("事件上报失败，错误码：%d！\n",ret);
			}
			break;
		#endif
	/*	
			//检测系统状态
			T_SDK_STATE state = ctiot_get_status();
			if(state == RDAP_STATE_ERROR){
				log_print_plain_text ("终端异常！\n");
				//释放资源并重新登录
				ctiot_process_network_errors();
				//系统等待1秒
				OS_SLEEP(1000);
				goto login;
			}
	*/
			case 'o':
			case 'O':
		//终端登出
			ret = ctiot_test_logout_req();
			break;
		#if defined(USE_CTIOT_FILE_UPLOAD)
		//小文件上传
			case 'f':
			case 'F':
			test_file_upload();
			break;
		#endif
		}
	}
}
