#include "tlink_pthread_handle.h"


void tlink_main(void)
{
    /* 设备初始化 */
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	//初始化操作
	ret = ctiot_test_init_req();

    if(ret != CTIOT_SUCCESS)
    {
        printf("Error Code: %d Tlink init fail!! ", ret);
        return;
    }

    /* 设备准备开始登录 */
    ret = ctiot_test_login_req();
    if(ret != CTIOT_SUCCESS)
    {
        log_print_plain_text ("登录失败！\n");
        return;
    }

    while(1)
    {
        ret = ctiot_send_compact_mode_data_req();
        if(ret == CTIOT_SUCCESS)
        {
            printf ("紧凑二进制上报成功！\n");
        }
        else
        {
            printf ("紧凑二进制上报失败，错误码：%d！\n",ret);
        }
    }


}