#include "tlink_pthread_handle.h"

extern int flags;
extern struct sendmsg smsg;

static void Tlink_Error_Handle(CTIOT_STATUS Status);

void tlink_main(char *id, char *code)
{
    /* 设备初始化 */
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	//初始化操作
	ret = ctiot_test_init_req();

    if(ret != CTIOT_SUCCESS)
    {
        printf("Error Code: %d Tlink init fail!! ", ret);
        Tlink_Error_Handle(ret);
    }

    /* 设备准备开始登录 */
    ret = ctiot_test_login_req(id, code);
    if(ret != CTIOT_SUCCESS)
    {
        log_print_plain_text ("登录失败！\n");
        Tlink_Error_Handle(ret);
    }

    while(1)
    {
        if(flags != 0)
        {
            ret = ctiot_send_compact_mode_data_req(&smsg);
            if(ret == CTIOT_SUCCESS)
            {
                printf ("紧凑二进制上报成功！\n");
            }
            else
            {
                printf ("紧凑二进制上报失败，错误码：%d!\n",ret);
                
            }

            Tlink_Error_Handle(ret);
            flags--;
        }
        sleep(10);
    }

// Error:
//     printf("出现错误,退出线程!\r\n");
//     ctiot_test_logout_req();

}

static void Tlink_Error_Handle(CTIOT_STATUS Status)
{
    
    switch (Status)
    {
    case CTIOT_SUCCESS:
        break;
    case CTIOT_INIT_FAIL:
    case CTIOT_NOT_INIT:
        ctiot_test_init_req();
        break;

    case CTIOT_QUEUE_OUT_BORDER:
        sleep(10);
        ctiot_send_compact_mode_data_req(&smsg);
        break;
    
    default:
        ctiot_test_init_req();
        sleep(10);
        ctiot_test_logout_req();
        sleep(10);
        ctiot_test_login_req();
        break;
    }
}
