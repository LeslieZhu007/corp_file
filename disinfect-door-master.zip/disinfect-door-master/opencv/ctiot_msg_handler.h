/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
// #include "ctiot_tlink_client.h"
#ifndef __MSG_HANDLER_H
#define __MSG_HANDLER_H

CTIOT_STATUS ctiot_test_init_req();
CTIOT_STATUS ctiot_test_login_req();
CTIOT_STATUS ctiot_test_logout_req();

//紧凑二进制数据上报函数
CTIOT_STATUS ctiot_send_compact_mode_data_req();


#endif
