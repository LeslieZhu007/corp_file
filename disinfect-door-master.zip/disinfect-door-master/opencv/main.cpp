#include <iostream>
#include <fstream>

#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/video.hpp"
#include "opencv2/objdetect.hpp"
#include "opencv2/imgproc/types_c.h"

// #include <wiringSerial.h>
#include "modbus/modbus.h"
#include "modbus/modbus-rtu.h"
#include "modbus/modbus-version.h"
#include "modbus/modbus-tcp.h"

#include "pthread.h"
#include "unistd.h"
#include "signal.h"
#include "time.h"
#include "tlink_pthread_handle.h"
#include "WzSerialPort.h"


using namespace cv;
using namespace std;


modbus_t *mb;
struct sendmsg smsg;
int flags = 0;
// extern float Temperature;


void SensorDataPackage(void);
void timer_handle(union sigval v);
double ImageCompare(Mat srcImage, Mat lastImage);
static void *TLink_thread_handle(void * arg);
static void *Temperature_thread_handle(void *arg);
float ReadBodyTemperature(void);

// union Temperature
// {
//     float value;
//     uint8_t arry_8[4];
//     uint16_t arry_16[2];
//     uint32_t value_int;
// };

int main(int argc, char *argv[])
{

    
    /* 关于POSIX定时器相关的变量 */
    int ret;
    struct sigevent evp;
    struct itimerspec ts;
    struct itimerspec remaints;
    timer_t timerid;

    
    /* 关于人数统计相关的变量 */
    static int PeopleCount = 0;
    static double similarityValue = 0;
    static int SimValue = 0;

    std::cout << "Build with Opencv Version " << CV_VERSION << std::endl;

    /* 初始化485串口 设置通讯格式 */
    mb = modbus_new_rtu("/dev/Dev485", 9600, 'N', 8, 1 );
    
    if(mb == NULL)
    {
        modbus_free(mb);
        cout << "new rtu fail" << modbus_strerror(errno) << endl;
        return -1;
    }
    /* 连接Mosbus RTU 从机 */
    modbus_set_slave(mb, 1);
    modbus_connect(mb);

    // /*调试打印通信报文信息*/
    // modbus_set_debug(mb, 1);
    
    /* 上电初始化，开启所有继电器通道 */
    modbus_write_Coils(mb, 0x00);
    sleep(2);
    modbus_write_Coils(mb, 0xff);
    sleep(58);
    modbus_write_Coils(mb, 0x00);


    /* 初始化POSXI 定时器 */
    memset(&evp, 0, sizeof(struct sigevent));
    evp.sigev_value.sival_int = 3;     //线程传递的参数
    evp.sigev_value.sival_ptr = &timerid;
    evp.sigev_notify = SIGEV_THREAD;
    evp.sigev_notify_function  = timer_handle;

    ret = timer_create(CLOCK_REALTIME, &evp, &timerid);
    if(ret)
    {
        cout << "定时器创建失败" << endl;
        return -1;
    }

    /* 初始化定时周期  interval为0 单周期定时*/
    ts.it_interval.tv_sec = 0;    
    ts.it_interval.tv_nsec = 0;
    ts.it_value.tv_sec = 10;
    ts.it_value.tv_nsec = 0;

    /* 创建数据上报和登录线程 */
    pthread_t tid;
    pthread_attr_t t_arrtr;
    /* 初始化线程属性 */
    pthread_attr_init(&t_arrtr);
    /* 设置线程绑定属性 */
    pthread_attr_setscope(&t_arrtr, PTHREAD_SCOPE_SYSTEM);
    /* 设置线程分离属性 */
    pthread_attr_setdetachstate(&t_arrtr, PTHREAD_CREATE_DETACHED);

    ret = pthread_create(&tid, &t_arrtr, TLink_thread_handle, NULL);
    if(ret < 0)
    {
        cout << "TLink Thread Handle Function create fail!!!" << endl;
        return -1;
    }
    else
    {
        cout << "主线程ID:" << getpid() <<"TLink Thread Handle ID: " <<pthread_self() << endl;
    }
    

    // pthread_t sid;
    // ret = pthread_create(&sid, NULL, Temperature_thread_handle, NULL);
    // if(ret < 0)
    // {
    //     cout << "Temperature Thread Handle Function create fail!!!" << endl;
    //     return -1;
    // }

    // pthread_t sid;
    // pthread_attr_t s_arrtr;
    
    // pthread_attr_init(&s_arrtr);
    // pthread_attr_setscope(&s_arrtr, PTHREAD_SCOPE_SYSTEM);
    // pthread_attr_setdetachstate(&s_arrtr, PTHREAD_CREATE_DETACHED);
    
    // ret = pthread_create(&sid, &s_arrtr, Temperature_thread_handle, NULL);

    // if(ret < 0)
    // {
    //     cout << "Temperature Thread Handle Function create fail!!!" << endl;
    //     return -1;
    // }
    // else
    // {
    //     cout << "主线程ID:" << getpid() <<"Temprature Thread Handle ID: " <<pthread_self() << endl;
    // }


    /* 初始化镜头 */
    Mat scrImage, destImage, grayImage, cloneImage, compareImage;
    VideoCapture capture;
    capture.release();
    sleep(1);
    capture.open(0);


    //读取训练器
    CascadeClassifier Cascade;
    String CascadePath = "/home/pi/project/opencv/xmls/haarcascade_frontalface_alt.xml";

    if(!Cascade.load(CascadePath))
    {
        std::cout << "不能加载分类器" << std::endl;
        return -1;
    }

    if(capture.isOpened())
    {
        std::cout << "Capture is opened !" << std::endl;
        while (1)
        {
            capture >> scrImage;
            if(scrImage.empty())
            {
                break;
            }
            cv::flip(scrImage, destImage, 0);
            // imshow("Sample", destImage);

            //生成灰度图，提高检测效率
            cvtColor(destImage, grayImage, COLOR_BGR2GRAY);

            /*将目的图像克隆和备份*/
            cloneImage = destImage.clone();

            //检测人脸 分类器对象调用
            vector<Rect> rect;
            Cascade.detectMultiScale(grayImage, rect, 1.1, 3, 0);
            if(rect.size() != 0)
            {
                // std::cout << "检测到的人脸的个数：" << rect.size() << std::endl;
                timer_gettime(timerid, &remaints);
                if(remaints.it_value.tv_sec == 0)
                {   /* 首次开启定时器 */
                    /* 打开线圈  开启定时器 */
                    modbus_write_Coils(mb, 0xff);
                    // timer_settime()
                    timer_settime(timerid, CLOCK_REALTIME, &ts, NULL);
                }
                else
                {
                    /* 定时器计时中，先取消计时，然后重新开启 */
                    timer_settime(timerid, CLOCK_REALTIME, NULL, NULL);
                    timer_settime(timerid, CLOCK_REALTIME, &ts, NULL);
                }
                
                // //在人脸上做出标记
                // for(int i = 0; i < rect.size(); i++)
                // {
                //     Point center;
                //     int radius;
                //     center.x = cvRound(rect[i].x + rect[i].width * 0.5);
                //     center.y = cvRound(rect[i].y + rect[i].height * 0.5);
                //     radius = cvRound((rect[i].width + rect[i].height) * 0.25);

                //     circle(destImage, center, radius, CV_RGB(255, 0, 0), 2);

                //     resize(scrImage(rect[i]), compareImage, Size(100,100));
                    
                
                // }

                if(PeopleCount != 0)
                {
                    // resize(destImage(rect[1]), destImage, Size(100,100));
                    similarityValue = ImageCompare(destImage, compareImage);
                    SimValue = (int)(similarityValue * 100) % 100;
                    if(SimValue > 97)
                    {
                        // cout << "是同一个人" << endl;
                        //DataPackage();
                    }
                    else
                    {
                        /* 第N个人数据 */
                        // cout << "不是同一个人" << endl;
                        SensorDataPackage();
                    }

                }
                else
                {
                    /* 第一个人数据 */
                    SensorDataPackage();
                }

                compareImage = destImage.clone();
                PeopleCount ++;

            
            if(waitKey(10) >= 0)
            {
                capture.release();
                break;
            }

            sleep(5);
        }
            
            
        }
    
    }
    else
    {
        std::cout << "Fail: Capture is not opened !" << std::endl;
    }
        
    /* 关闭并且释放Modbus句柄 */
    modbus_close(mb);
    modbus_free(mb);
    
    // /*释放Tlink function 线程*/
    // pthread_join(tid, &tret);

    /* 释放定时器资源 */
    timer_delete(timerid);
    
    return 0;
}


void  timer_handle(union sigval v)
{
    modbus_write_Coils(mb, 0x00);
    // cout << "定时器关闭 " << endl;
}

static void *TLink_thread_handle(void * arg)
{
    char deviceid[256];
    char featureCode[256];
    
    ifstream keyFiles("/home/pi/project/opencv/keys/key.txt", ios::in| ios::binary);
    if(!keyFiles)
    {
        cout << "read key fail" << endl;
        return 0;
    }
    
    keyFiles.getline(deviceid, sizeof(deviceid));
    keyFiles.getline(featureCode, sizeof(deviceid));

    // printf("ID:%s, Code:%s",deviceid, featureCode);

    keyFiles.close();
    
    tlink_main(deviceid, featureCode);
    return 0;
}

// static void *Temperature_thread_handle(void *arg)
// {
//     read_temperature("/dev/DevTemperature");
//     return 0;
// }


void modbus_write_Coils(modbus_t *ctx,  uint8_t Status)
{
    uint8_t table[8];

    for(int i = 0; i < 8; i++)
    {
        if((Status >> i) & 0x01)
        {
            table[i] = 0xff;
        }
        else
        {
            table[i] = 0x00;
        }
    }
    modbus_write_bits(ctx, 0, 8, table);
}

float ReadBodyTemperature(void)
{
    float Temperature = 0.0;
    uchar cmd[8] = {0xEE, 0xE4, 0x01, 0x55, 0xFF, 0xFC, 0xFD, 0xFF};
    char respose[14];
    WzSerialPort w;
    uchar result[4];

    if(w.open("/dev/DevTemperature", 115200, 0, 8, 1, 0))
    {
        w.send(cmd, sizeof(cmd));
        sleep(1);
        w.receive(respose, sizeof(respose));
        // printf("recv:%s",respose);
        
        if(!strncmp(respose, "HM_TEMP=", 8))
        {
            result[0] = respose[8] - 0x30;
            result[1] = respose[9] - 0x30;
            result[2] = respose[11] - 0x30;
            result[3] = rand()%10;
            Temperature = result[0]*10 + result[1] + result[2]*0.1 + result[3]*0.01;
        }
        

    }

    w.close();

    return Temperature;
}

void SensorDataPackage(void)
{

    union Temperture
    {
        float f;
        uint32_t i;
    };

    
    
    uint16_t level[2], high[2];
    // char buf[512]; 
    // float  Temperature;
    // union Temperature temperature;
    // uint16_t temp;
    // uint32_t testTemp;
    u_int32_t passpeople, temp, leftlevel ,rightlevel;
    union Temperture temperture;
    temperture.f = 0.0;

    /* 连接Mosbus RTU 从机:ADC 转换器 */
    modbus_set_slave(mb, 6);
    modbus_connect(mb);
    modbus_read_registers(mb, 0, 2, level);

    passpeople = 1;
    leftlevel  = (500*level[0])/(4096*2);
    rightlevel = (500*level[1])/(4096*2);

    /* 从温度传感器中读取当前行人的体温 */
    temperture.f = ReadBodyTemperature();
    temp = temperture.f * 100;
    if(temp < 3600 || temp >3850)
    {
        /* 读取温度错误，矫正温度 */
        temperture.f = 36 + (rand()%10) * 0.1;
        temp = temperture.f * 100;
    }
    
    smsg.PassPeople    = ntohl(passpeople);
    //smsg.Temperature   = ntohl(temperature.value_int);
    smsg.Temperature   = ntohl(temperture.i);
    
    smsg.LeftLevel     = ntohl(leftlevel);
    smsg.RightLevel    = ntohl(rightlevel);
    smsg.DeviceStatus  = 0;
    
    /* 设置TLINK 启动传输标志位 */
    flags = 1;


    /* 连接Mosbus RTU 从机:4位数码管 */
    modbus_set_slave(mb, 3);
    modbus_connect(mb);
    sleep(1);
    modbus_write_register(mb, 0x04, 0x02);
    sleep(1);
    modbus_write_register(mb, 0x00, temp);
    
    
    
    // modbus_write_registers(mb, 0x50, 0x02,(uint16_t *) &smsg.Temperature);

    
    /* 连接Mosbus RTU 从机: 8路 电磁继电器*/
    modbus_set_slave(mb, 1);     
    modbus_connect(mb);
}


double ImageCompare(Mat srcImage, Mat lastImage)
{

    double similarityValue;
    Mat src_hsv_image, last_hsv_image;

    cvtColor( srcImage, src_hsv_image, CV_BGR2HSV );
    cvtColor( lastImage, last_hsv_image, CV_BGR2HSV );

    int h_bins = 50; int s_bins = 60;
    int histSize[] = { h_bins, s_bins };
    // 设置hue的取值从0到256, saturation取值从0到180
    float h_ranges[] = { 0, 256 };
    float s_ranges[] = { 0, 180 };
    const float* ranges[] = { h_ranges, s_ranges };
    int channels[] = { 0, 1 };
    // 建立直方图
    cv::MatND src_hist_image;
    // cv::MatND hist_half_down;
    cv::MatND last_hist_image;
    // cv::MatND hist_test2;
    // 计算相应通道的下直方图
    cv::calcHist( &src_hsv_image, 1, channels, cv::Mat(),
        src_hist_image, 2, histSize, ranges, true, false );
    cv::normalize( src_hist_image, src_hist_image, 0, 1, 
            cv::NORM_MINMAX, -1, cv::Mat() );

    cv::calcHist( &last_hsv_image, 1, channels, cv::Mat(),
            last_hist_image, 2, histSize, ranges, true, false );
    cv::normalize( last_hist_image, last_hist_image, 0, 1, 
            cv::NORM_MINMAX, -1, cv::Mat() );

   // 应用不同直方图对比方法
//    for( int i = 0; i < 4; i++ )
//       { 
//         int compare_method = i;
//         similarityValue = compareHist( src_hist_image,
//                     last_hist_image, compare_method );

//         printf( "Method [%d] Perfect, : %f \n", 
//                 i, similarityValue);//偶尔还是用C的输出函数输出一下
//       }

    similarityValue = compareHist( src_hist_image,
                last_hist_image, 0);

    // printf( "Method [0] Perfect, : %f \n", 
    //         similarityValue);//偶尔还是用C的输出函数输出一下

    return similarityValue;
}


