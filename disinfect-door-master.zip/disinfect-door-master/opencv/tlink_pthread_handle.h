#ifndef __TLINK_PTTHREAD_HANDLE_H
#define __TLINK_PTTHREAD_HANDLE_H


#include <stdio.h>
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_msg_handler.h"
#include "ctiot_tlink_client.h"
#include "ctiot_log.h"

// #include <wiringSerial.h>
#include "modbus/modbus.h"
#include "modbus/modbus-rtu.h"
#include "modbus/modbus-version.h"
#include "modbus/modbus-tcp.h"

#ifdef __cplusplus
extern "C" {
#endif 

struct sendmsg
{
    u_int32_t PassPeople;
    u_int32_t Temperature;
    u_int32_t LeftLevel;
    u_int32_t RightLevel;
    u_int32_t DeviceStatus;
};


extern modbus_t *mb;

void tlink_main(char *id, char *code);
void modbus_write_Coils(modbus_t *ctx,  uint8_t Status);

#ifdef __cplusplus
}
#endif 




#endif /* __TLINK_PTTHREAD_HANDLE_H */