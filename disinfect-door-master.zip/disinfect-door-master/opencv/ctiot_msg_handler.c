/************************************************************************

            (c) Copyright 2018 by 中国电信上海研究院. All rights reserved.

**************************************************************************/
#include <stdio.h>
#include "ctiot_basetype.h"
#include "ctiot_os.h"
#include "ctiot_tlink_client.h"
#include "ctiot_msg_handler.h"
#include "MQTTClient.h"
#include "ctiot_tlink.h"
#include "ctiot_log.h"
#include <string.h>
#include "ctiot_md5.h"
#include "tlink_pthread_handle.h"


//演示使用的payload串
SDK_U8 testPayload[] = {0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0};
SDK_U8 testRltPayload[] = {11,12,13};

#if defined(USE_CTIOT_CMD_EXCUTE)
//指令下发的回调函数，ptrData为下行指令报文
void test_execute_cmd(CTIOT_MQTT_EXECUTE_CMD_REQUEST* ptrData)
{
	//初始化返回结果
	CTIOT_STATUS ret = CTIOT_SUCCESS;

	//构造指令下发的返回内容
	SDK_U8 resultCode = 0;
	SDK_U32 msgID = 0;

	SDK_U8 ledStatus = 0;
	SDK_U8 motorStatus = 0;
	SDK_U8 *ledStr = NULL;
	SDK_U8 *motorStr = NULL;
	ledStatus = ptrData->u.compact.payload[0];
	motorStatus = ptrData->u.compact.payload[1];
	if(ledStatus == 1)
	{
		ledStr = "绿色";
	}
	else if(ledStatus == 2)
	{
		ledStr = "红色";
	}
	else if(ledStatus == 3)
	{
		ledStr = "紫色";
	}
	else
	{
		log_print_plain_text("错误指令！\n");
		resultCode = 1;
	}
	if(motorStatus == 0)
	{
		motorStr = "关闭";
	}
	else if(motorStatus == 1)
	{
		motorStr = "启动";
	}
	else
	{
		log_print_plain_text("错误指令！\n");
		resultCode = 1;
	}
	if(resultCode == 0)
	{
		log_print_plain_text("LED状态:%s  电机状态:%s\n",ledStr,motorStr);
	}

	//返回指令下发结果并记录结果码
	ret = ctiot_send_execute_cmd_cnf(ptrData->payloadType,ptrData->cmdSN,resultCode,0,
						  NULL,0,&msgID);
	log_print_plain_text ("指令下发处理结果：%s \n",(ret==0?"成功":"失败"));
}


void door_execute_cmd(CTIOT_MQTT_EXECUTE_CMD_REQUEST* ptrData)
{
	//初始化返回结果
	CTIOT_STATUS ret = CTIOT_SUCCESS;

	//构造指令下发的返回内容
	SDK_U8 resultCode = 0;
	SDK_U32 msgID = 0;

	SDK_U8 DoorStatus = 0;
	// SDK_U8 motorStatus = 0;
	// SDK_U8 *ledStr = NULL;
	// SDK_U8 *motorStr = NULL;
	DoorStatus = ptrData->u.compact.payload[0];
	modbus_write_Coils(mb, DoorStatus);

	//返回指令下发结果并记录结果码
	ret = ctiot_send_execute_cmd_cnf(ptrData->payloadType,ptrData->cmdSN,resultCode,0,
						  NULL,0,&msgID);

	log_print_plain_text ("指令下发处理结果：%s \n",(ret==0?"成功":"失败"));

	
}


#endif

#if defined(USE_CTIOT_REMOTECTRL_EXCUTE)
//远程控制的回调函数，ptrData为下行控制报文
void test_remote_control(CTIOT_MQTT_REMOTE_CTRL_REQ* ptrData)
{
	//初始化返回结果
	CTIOT_STATUS ret = CTIOT_SUCCESS;

	//构造远程控制的返回内容
	SDK_U32 dmsn = ptrData->dmsn;
	SDK_U16 controlType = ptrData->controlType;
	SDK_U8  resultCode = 0;
	SDK_U16 additionalInfoLen = 0;
	SDK_U8* additionalInfo = NULL;
	SDK_U32 msgID;
	//返回远程控制结果并记录结果码
	ret = ctiot_send_remote_ctrl_cnf(dmsn,controlType,resultCode,additionalInfoLen,additionalInfo,&msgID);
	log_print_plain_text ("远程控制返回结果码：%d\n",ret);
}
#endif

#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
//透明传输的回调函数，ptrData为下行透传报文
void test_DlTrDataInd(CTIOT_MQTT_DL_TRANSPARENT_DATA_RECV* ptrData)
{
	log_print_plain_text ("接到透明传输的下行数据！\n");
}
#endif

#if defined(USE_CTIOT_RETRIEVEDATA)
//数据获取的回调函数，data为下行控制报文
void test_retrieve_data(CTIOT_MQTT_RETRIEVE_DATA_REQ* data)
{
	SDK_U32 gdsn = data->gdsn;
	SDK_U8 payloadType = data->payloadType;

	SDK_U8 resultCode = 0;
	SDK_U16 datasetID = 1005;
	SDK_U32 msgID = 0;
	SDK_U16 dataCollectResultLen = 2;
	char* dataCollectResult = testRltPayload;
	SDK_U16 payloadLen = 10;
	char* payload = testPayload;
	switch(payloadType)
	{
		case 0:
		{
	        send_retrieve_data_cnf(gdsn,resultCode,payloadType,datasetID,0,NULL,payloadLen,payload,&msgID);
			break;
		}
		case 1:
		{
	        send_retrieve_data_cnf(gdsn,resultCode,payloadType,datasetID,dataCollectResultLen,dataCollectResult,payloadLen,payload,&msgID);
			break;
		}
		case 2:
		{
	        send_retrieve_data_cnf(gdsn,resultCode,payloadType,datasetID,0,NULL,payloadLen,payload,&msgID);
			break;
		}
	}
}
#endif

#if defined(USE_CTIOT_ENQUIREPARA_EXCUTE)
//参数查询的回调函数，data为下行控制报文
void test_ParaEnquire(CTIOT_MQTT_PARA_ENQUIRE_REQ* data)
{
	SDK_U8 resultCode = 0;
	SDK_U8 payloadType = 0;
	SDK_U16 datasetID = 0;
	SDK_U16 payloadLen = 0;
	SDK_U8 *payload = NULL;
	SDK_U16 resultLen = 0;
	SDK_U8 *result = NULL;
	SDK_U32 msgID = 0;

	if(data->payloadType == 0){
			payloadType = 0;	
			datasetID = data->u.datasetID;
			payloadLen = 10;
			payload = testPayload;
	}
	else if(data->payloadType == 2)
	{
		payloadType = 2;
	    payload = testPayload;
		payloadLen = strlen(payload);
	}
	ctiot_enquire_para_conf(data->dmsn, resultCode, payloadType, datasetID,
					 payloadLen, payload, resultLen, result, &msgID);
}
#endif

#if defined(USE_CTIOT_SETPARA_EXCUTE)
//参数设置的回调函数,data为下行控制报文
void test_SetPara(CTIOT_MQTT_SET_PARA_REQ* data)
{
	SDK_U8 resultCode = 0;
	SDK_U32 msgID = 0;
	SDK_U8 payloadType = 0;
	SDK_U16 datasetID = 0;
	SDK_U16 payloadLen = 0;
	SDK_U8* payload = NULL;
	if(data->payloadType == 0)
	{
		payloadType = 1;
		payloadLen = 10;
		payload = testPayload;
		datasetID = 1000;
	}
	else if(data->payloadType == 2)
	{
		payloadType = 2;
		payload = testPayload;
	}
	ctiot_set_para_conf(data->dmsn, resultCode, payloadType, datasetID,
								 payloadLen, payload, &msgID);
}
#endif

//注册服务器断开连接的回调函数
void ctiot_test_lost_conn_ind()
{
    printf("Client lost conn with server!\n");
}

//qos为1时消息状态回调函数
void test_msgStatus(SDK_U32 msgID,SDK_U8 status)
{
	// printf("test_msgStatus msgID: %d , status: %d \n",msgID,status);
	// printf("test_msgStatus msgID: %d , status: %d \n",msgID,status);
}

#if defined(USE_CTIOT_FILE_UPLOAD)
//小文件上传回调函数
SDK_U8 fileUploadStatus = 0;
void test_fileUpload(CTIOT_TLINK_FILE_UPLOAD_REQ* data)
{
	printf("test_fileUpload: upSmallFileSN %d , ResultCode %d \n",data->upSmallFileSN,data->resultCode);
	if(data->resultCode != 0)
	{
		fileUploadStatus = 1;
	}
}
#endif

//终端初始化函数
CTIOT_STATUS ctiot_test_init_req()
{
	//初始化返回结果
    CTIOT_STATUS ret = CTIOT_SUCCESS;

	//初始化初始信息结构体
	CTIOT_MQTT_INIT_REQ info = {0};
	
	//设置服务器端IP地址及端口号，必选
	info.hostIp = "180.106.148.146";
	info.hostPort = 11884;

	//初始化配置全局变量，可选
	info.commandTimeout = 3000;         // 可选,报文往返最长时间
	info.readSocketPeriod = 2000;       // 可选,轮询所需接收报文单次等待时间
	info.regLoginDuration = 2000;       // 可选,登录和注册函数后的等待云端下发应答报文的超时时间
	info.maxPayloadLenRecv = 500;       // 可选,MQTT报文最大长度接收
	info.maxPayloadLenSent = 500;       // 可选,MQTT报文最大长度发送
	info.connectMode = 1;               // 可选,连接模式选择 1、明文 2、单向TLS 3、双向TLS
	info.maxQueueLen = 10;              // 可选,最大队列长度
    info.maxProcessMessageNum = 3;      // 可选, 单次处理消息数目
    info.pingTimes = 3;                 // 可选,心跳包文重发次数
    info.QOSMaxRetrans = 3;             // 可选,QOS1最大重传次数
    info.QOSMsgRetransTimeout = 3000;   // 可选,QOS1报文ACK超时时间
		
	//初始化回调函数，可根据需求相应的回调函数完成相关业务需求
	#if defined(USE_CTIOT_CMD_EXCUTE)
    info.executeCmdCallback = door_execute_cmd;    // 指令下发回调函数
	#endif
	#if defined(USE_CTIOT_TRANSPARENT_DATA_DL)
	info.downlinkTransparentDataCallback=test_DlTrDataInd;  // 下行透明传输回调函数
	#endif
	#if defined(USE_CTIOT_REMOTECTRL_EXCUTE)
	info.remoteControlCallback = test_remote_control;   // 远程控制回调函数
	#endif
	info.lostConnToServer=ctiot_test_lost_conn_ind;   // 终端断连异常回调函数
	#if defined(USE_CTIOT_RETRIEVEDATA)
	info.retrieveDataCallback = test_retrieve_data;   // 数据获取回调函数
	#endif
	#if defined(USE_CTIOT_ENQUIREPARA_EXCUTE)
	info.paraEnquireCallback=test_ParaEnquire;   // 参数查询回调函数
	#endif
	#if defined(USE_CTIOT_SETPARA_EXCUTE)
	info.setParaCallback=test_SetPara;    // 参数配置回调函数
	#endif
	info.msgStatusCallback=test_msgStatus;  // 报文发送处理状态回调函数
	#if defined(USE_CTIOT_FILE_UPLOAD)
	info.fileUploadCallback=test_fileUpload;    //小文件上传回调函数
	#endif

	//调用sdk完成终端初始化
	ret = ctiot_initial_request(&info);
 
	//返回执行结果码
    return ret;
}

//终端登录函数函数
CTIOT_STATUS ctiot_test_login_req(char *deviceID, char *featureCode)
{
    //初始化返回结果
    CTIOT_STATUS ret = CTIOT_SUCCESS;

	//初始化登录信息
	CTIOT_MQTT_LOGIN_REQ loginReq = {"15319081sfxdm01-01",0x1,"V1.0","CentOS-64",{1,43,"FfL1cS1wSNlJwGku6rEHH4o0Ky14XlUvwX3tcFapq48"}};

	//设置登录信息的终端时间戳
	time_t now;
	time(&now);
	loginReq.timeStamp = now;

	loginReq.heartBeatLen = 10;
	strcpy(loginReq.utcOffset, "+08:00");
	//登录返回结果初始化
	CTIOT_MQTT_LOGIN_CNF cnf = {0};
	//执行登录操作并获取返回值
	ret=ctiot_login_request(&loginReq,&cnf);
	if(ret==CTIOT_SUCCESS)
	{
		
		printf("登录成功\n");
	}
	else
	{
		log_print_plain_text ("错误码：%d\n",ret);
		log_print_plain_text ("登录失败\n");
	}

	//返回执行结果码
	return ret;
}

//终端登出函数
CTIOT_STATUS ctiot_test_logout_req()
{
	//初始化返回结果
    CTIOT_STATUS ret = CTIOT_SUCCESS;

	//执行登出操作并获取返回值
    ret = ctiot_logout_request();
	printf ("登出成功！\n");

	//返回执行结果码
    return ret;
}

#if defined(USE_CTIOT_SEND_DATA)
//紧凑二进制数据上报函数
CTIOT_STATUS ctiot_send_compact_mode_data_req(struct sendmsg *msg)
{	
	//初始化返回值
    CTIOT_STATUS ret = CTIOT_SUCCESS;
	//构造紧凑二进制数据，仅为演示
	SDK_U8 payload[20];
	SDK_U32 upDataSN = 1;
	CTIOT_MQTT_PAYLOAD_TYPE payloadType = 0;
	SDK_U16 dataSetID = 886;
	SDK_U16 payloadLen = 20;
	// SDK_U8 payload[] = {0x00,0x00,0x00,0x01,
	// 					0x42,0x13,0x33,0x33,
	// 					0x00,0x00,0x00,0x52,
	// 					0x00,0x00,0x00,0x56,
	// 					0x00,0x00,0x00,0x00
	// 					};  // 温度25.5度的四字节浮点为0x4CC0000 42 13 33 33 36.8
    SDK_U8  qos = QOS1;
	SDK_U32 msgID = 0;
	//发送紧凑二进制数据并获取返回值
	memcpy(payload, msg, sizeof(payload));
	ret = ctiot_send_compact_data(payloadType,dataSetID,payloadLen,payload,qos,upDataSN,&msgID);
	//返回执行结果码
    return ret;
}

//带结果反馈的紧凑二进制函数
CTIOT_STATUS ctiot_send_compact_with_rlt_mode_data_req(){
	//初始化返回值
	CTIOT_STATUS ret = CTIOT_SUCCESS;

	//构造带结果反馈的紧凑二进制数据，仅为演示
	SDK_U32 upDataSN = 1;
	CTIOT_MQTT_PAYLOAD_TYPE payloadType = 1;
	SDK_U16 dataSetID = 1001;
	SDK_U16 payloadLen = 10;
	SDK_U8* payload = testPayload;
	SDK_U16 resultLen = 3;
	SDK_U8* result = testRltPayload;
	SDK_U8  qos = QOS0;
	SDK_U32 msgID = 0;
	//发送带结果反馈的紧凑二进制数据并获取返回值
	ret = ctiot_send_compact_with_rlt_data(payloadType,dataSetID,payloadLen,payload,resultLen,result,qos,upDataSN,&msgID);

	//返回执行结果码
	return ret;
}

//Json数据上报函数
CTIOT_STATUS ctiot_send_json_mode_data_req(){
	//初始化返回值
	CTIOT_STATUS ret = CTIOT_SUCCESS;

	//构造JSON数据，仅为演示
	SDK_U32 upDataSN = 1;
	CTIOT_MQTT_PAYLOAD_TYPE payloadType = 2;
	SDK_U16 dataSetID = 1002;
	SDK_U8* payload = "{\"test\":\"test\"}";
	SDK_U8  qos = QOS1;
	SDK_U32 msgID = 0;
	//发送JSON数据并获取返回值
	ret = ctiot_send_json_data(payloadType,dataSetID,payload,qos,upDataSN,&msgID);

	//返回执行结果码
	return ret;
}
#endif

#if defined(USE_CTIOT_TRANSPARENT_DATA_UL)
//透明传输上行函数
CTIOT_STATUS ctiot_send_tr_data_req()
{
	//初始化返回值
	CTIOT_STATUS ret = CTIOT_SUCCESS;
	
	//构造透明传输数据，仅为演示
	SDK_U32 upTpDataSN = 1;
	CTIOT_MQTT_PAYLOAD_TYPE payloadType = JSON_MODE;
	SDK_U32 upDataSN = 0;
	SDK_U16 dataSetID = 1002;
	SDK_U16 payloadLen = 10;
	SDK_U8* payload = testPayload;
	SDK_U8  qos = QOS1;
	SDK_U32 msgID = 0;	
	//发送透明传输数据并获取返回值
	ret = ctiot_send_transparent_data(payloadLen,payload,qos,upTpDataSN,&msgID);
	
	//返回执行结果码
	return ret;
}
#endif

#if defined(USE_CTIOT_EVENT_REPORT)
//事件上报函数
CTIOT_STATUS test_EventReportReq()
{
	//初始化返回值
	CTIOT_STATUS ret = CTIOT_SUCCESS;

	//构造透明传输数据，仅为演示
	SDK_U32 eventSn = 1;
	SDK_U16 eventID = 2;
	time_t now;
	time(&now);
	SDK_U64 eventTime = now;
	SDK_U8 eventType = 0;
	CTIOT_MQTT_PAYLOAD_TYPE payloadType=COMPACT_MODE;
	SDK_U16 payloadLen = 10;
	char* payload = testPayload;
	SDK_U8 qos = QOS1;
	SDK_U32 msgID = 0;

	//发送透明传输数据并获取返回值
    ret = ctiot_event_report(eventSn,eventID,eventTime,eventType,payloadType,payloadLen,payload,qos,&msgID);
	
	//返回执行结果码
	return ret;
}
#endif

#if defined(USE_CTIOT_FILE_UPLOAD)
//获取文件的MD5
SDK_U8 ctiot_get_file_md5(SDK_U8 *filePath, SDK_U8* file_md5)
{
    if(filePath == NULL){
        return -1;
    }
    MD5_CTX context;
    MD5Init(&context);
    int bytes = 0;
    int i = 0;

    FILE *fp = fopen(filePath,"read");
    char* data = NULL;
    int ret = 0;

    if(fp == NULL){
        return -1;
    }
    
    OS_GET_MEM(data,SDK_U8,1024);
    if(!data){
        return -1;
    }    
    while ((bytes = fread (data, 1, 1024, fp)) != 0)  
    {  
        if(bytes == -1){
            return -1;
        }
        MD5Update (&context, data, bytes);  
    }  
    MD5Final(&context, file_md5);
    OS_PUT_MEM(data);

    return 0;
}

//小文件上传函数
// CTIOT_STATUS test_file_upload()
// {
// 	CTIOT_STATUS ret = CTIOT_SUCCESS;
// 	fileUploadStatus = 0;
// 	SDK_U32 upSmallFileSN = 1;
// 	SDK_U8* fileName = "mqtt_file.txt";
// 	SDK_U64 filesize = 0;
// 	SDK_U16 blockNum = 0; 
// 	SDK_U16 blockSize = 2000; 
// 	SDK_U8 isLastBlock = 0;
// 	SDK_U8 blockSeq = 1;
// 	SDK_U8 *data = NULL; 
// 	SDK_U32 bytes = 0;
//     struct stat statbuff;    
//     if(stat("mqtt_file.txt", &statbuff) < 0)
// 	{
// 		printf("test_file_upload:file state get failure!\n");
// 		return;
//     }else
// 	{
//         filesize = statbuff.st_size;
//     }
// 	FILE* fp = NULL;
// 	fp = fopen("mqtt_file.txt","r");
// 	if(fp == NULL)
// 	{
// 		printf("test_file_upload:fopen failure!\n");
// 		return;
// 	}
// 	blockNum = filesize/blockSize;
// 	if(filesize%blockSize != 0)
// 	{
// 		blockNum ++;
// 	}
// 	SDK_U32 msgID = 0;
// 	SDK_U8 checksum[16] = {0};
// 	ctiot_get_file_md5("mqtt_file.txt",checksum);

// 	ret = ctiot_file_upload_request(upSmallFileSN,strlen(fileName),fileName,filesize, blockNum, blockSize, checksum, &msgID);
// 	if(ret != CTIOT_SUCCESS){
// 		return ret;
// 	}

// 	OS_GET_MEM(data,SDK_U8,blockSize);
//     if(!data)
// 	{
//         return -1;
//     }    
// 	for(blockSeq = 1; blockSeq <= blockNum; blockSeq++)
// 	{
// 		OS_SLEEP(100);
// 		if(fileUploadStatus == 1){
// 			break;
// 		}
// 		upSmallFileSN++;
// 		if(blockSeq == blockNum)
// 		{
// 			isLastBlock = 1;
// 		}
// 		bytes = fread (data, 1, blockSize, fp);
// 		if( bytes <= 0 )
// 		{
// 			printf("test_file_upload read file error! \n");
// 		}
// 		ctiot_file_content_upload_request(upSmallFileSN,isLastBlock,blockSeq, bytes, data);
// 	}
// 	return ret;
// }
#endif
