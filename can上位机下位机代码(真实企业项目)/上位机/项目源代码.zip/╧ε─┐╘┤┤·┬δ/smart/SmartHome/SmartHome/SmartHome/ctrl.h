#ifndef CTRL_H
#define CTRL_H

#include <QWidget>
#include <QCameraImageCapture>
#include <QCameraViewfinder>
#include <QCamera>
#include <QLabel>
#include <QDebug>
#include<QTcpSocket>        //客户端类
#include<QMessageBox>
#include <QMetaType>

//struct cli_msg_Command
//{
//    int open_close;           // 通信的开关 1为开 0为关
//    int cmdtype;              // 通信指令类型  1为led开 0为led关  4为蜂鸣器 5为马达 6为风扇，7为温湿度
//    int speed_run;            // 运行的速度  1为1挡 2为挡 3为3挡
//    int Temperature_humidity; // 温湿度切换 1为温度，2为湿度
//    int led_switch;           // 灯的选择 1 2 3（客户端发送的参数）
//    int speed_switch_md_fs;   // 风扇、马达运行速度 1 2 3
//    int tem;                  // 温度
//    int hun;                  // 湿度
//};
//Q_DECLARE_METATYPE(cli_msg_Command);

/*typedef struct smart_home
{
    int flags;//手动 0  自动 1
    int tem;//获取的温度值
    int hun;//获取的湿度值
    int equ;
    int tem_thres;//温度阈值
    int hum_thres;//湿度阈值
}msg_t;*/

typedef struct node //客户端与服务端通信的结构体
{
    int cmdtype;    //通信指令类型  1为led1 2为led2 3为led3 4为蜂鸣器 5为马达 6为风扇 7为温湿度 9为传递值
    int open_close; //1为开 2为关
    int speed_run;  //运行的速度  1为1档  2为2档  3为3档
}msg_t;


namespace Ui {
class ctrl;
}

class ctrl : public QWidget
{
    Q_OBJECT

public:
    explicit ctrl(QWidget *parent = nullptr);
    ~ctrl();
    void swithchPage();
private slots:
    void on_backBt_clicked();

    void on_livingBt_2_clicked();

    void on_bedBt_2_clicked();

    void on_minBt_2_clicked();

    void on_setBt_3_clicked();

    void on_camera_clicked();

    void on_closeCamera_clicked();

    //void on_lineEdit_cursorPositionChanged(int arg1, int arg2);
//=========服务器使用===========


    void on_connected_slot();           //自定义处理connected的信号的槽函数

    void on_readyRead_slot();        //声明处理readyRead信号的槽函数

    //void on_sendBtn_clicked();

    void on_connectBtn_clicked();
    //=========服务器使用===========

    void on_but_led1_clicked();

    void on_but_led3_clicked();

    void on_but_led2_clicked();

    void on_baojinqi_clicked();

//    void on_baojinqi_2_clicked();

//    void on_fengshan_2_clicked();

    void on_fengshan_clicked();

    void on_mada_clicked();

    void on_but_auto_clicked();

    void on_but_hand_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_pushButton_4_clicked();

private:
    //定义客户端指针
    QTcpSocket *socket;

    //定义变量接受ui界面的用户名
    QString userName;
    Ui::ctrl *ui;
    QCamera *ca;
    QCameraViewfinder *vf;
    QCameraImageCapture *capture;
};

#endif // CTRL_H
