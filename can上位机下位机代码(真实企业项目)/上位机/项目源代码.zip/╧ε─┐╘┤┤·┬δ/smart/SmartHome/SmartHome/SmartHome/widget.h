#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QLabel>
#include <QDateTime>
#include <QTimer>
#include <QDate>
#include<QTcpSocket>        //客户端类
#include<QMessageBox>
#include <QMetaType>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    //   virtual void mousePressEvent(QMouseEvent *event);
    //    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void mouseDoubleClickEvent(QMouseEvent *event);
    //    virtual void mouseMoveEvent(QMouseEvent *event);
private slots:
    void on_loginBt_clicked_slot();
    void timertime();

    //void on_loginBt_clicked();

    //进度条
//    void getinfo();//子界面发过来的信号
//    void updateProgressBar();

    void on_loginBt_clicked();

private:
    //ctrl *m_second;//申明新的界面
    QTimer *timer;
    QLabel *showtime;
    QDate *cd;
    Ui::Widget *ui;




};
#endif // WIDGET_H
