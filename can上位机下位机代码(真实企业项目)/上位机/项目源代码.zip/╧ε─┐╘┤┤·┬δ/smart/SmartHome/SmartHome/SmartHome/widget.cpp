#include "widget.h"
#include "ui_widget.h"
#include "ctrl.h"
#include <QCursor>
#include <QMouseEvent>
#include <QPixmap>
#include <QPalette>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    //设置背景图片
    QPixmap pixmap=QPixmap(":/pics/background-1.jpg").scaled(this->size());
    QPalette pale;
    pale.setBrush(QPalette::Background,pixmap);
    this->setPalette(pale);
    //定义跳转点击按钮事件
    connect(ui->loginBt,SIGNAL(clicked()),this,SLOT(on_loginBt_clicked_slot()));
    //实例化鼠标
    QCursor cursor;
    cursor.setShape(Qt::OpenHandCursor);
    setCursor(cursor);
    //实例化QLabel控件
    showtime=new QLabel();
    //实例化QTimer控件
    timer=new QTimer();
    //timer 时间
    connect(timer,SIGNAL(timeout()),this,SLOT(timertime()));
    //执行
    timer->start(1);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::mouseDoubleClickEvent(QMouseEvent *event)
{
    //左键双击进入首页页面
    if(event->button()==Qt::LeftButton)
    {
        ctrl *ct=new ctrl;
        ct->setGeometry(this->geometry());
        ct->show();
    }

}

void Widget::on_loginBt_clicked_slot()
{
    //跳转到首页
    ctrl *ct=new ctrl;
    ct->setGeometry(this->geometry());

    ct->show();
    //qDebug("login");
}

void Widget::timertime()
{
    //获取系统时间
    QDateTime sysTime=QDateTime::currentDateTime();
    ui->timelabel->setText(sysTime.toString("hh:mm:ss"));
    QDate cd=QDate::currentDate();
    ui->datelabel->setText(cd.toString(Qt::DefaultLocaleLongDate));
}





