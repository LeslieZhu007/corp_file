#include "ctrl.h"
#include "ui_ctrl.h"
#include "widget.h"
//调用摄像头
#include <QCameraInfo>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QPixmap>
#include<QTcpSocket>
#include <QDebug>
//弹窗
#include <QMessageBox>
#include <QTextEdit>
#include <QString>
msg_t msg;

ctrl::ctrl(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ctrl)
{
    ui->setupUi(this);

    // 客厅按钮关闭
    ui->livingBt_2->setEnabled(false);

    // 卧室按钮关闭
    ui->bedBt_2->setEnabled(false);

    // 监控按钮关闭
    ui->minBt_2->setEnabled(false);

    // 自动按钮关闭
    ui->but_auto->setEnabled(false);

    // 手动按钮关闭
    ui->but_hand->setEnabled(false);

    //实例化一个客户端对象
    socket = new QTcpSocket(this);

    //将客户端发射的connected的信号与自定义的槽函数连接
    connect(socket, &QTcpSocket::connected, this, &ctrl::on_connected_slot);

    //当服务器向客户端发来消息时，该客户端就会自动发射一个readyRead的信号
    //我们可以在该信号对应的槽函数中，处理相关数据
    connect(socket, &QTcpSocket::readyRead, this, &ctrl::on_readyRead_slot);


    //当客户端断开服务器的连接后，该客户端会自动发射一个disconnected的信号
    //我们可以在该信号对应的槽函数中处理相关逻辑
    connect(socket, &QTcpSocket::disconnected, [&](){
        QMessageBox::information(this, "消息", "断开成功");
    });
}

ctrl::~ctrl()
{
    delete ui;
}
void ctrl::swithchPage()
{
    QPushButton *button = qobject_cast<QPushButton*>(sender());
       if(button==ui->livingBt_2)
           ui->stackedWidget->setCurrentIndex(0);
       else if(button==ui->bedBt_2)
           ui->stackedWidget->setCurrentIndex(1);
       else if(button==ui->minBt_2)
           ui->stackedWidget->setCurrentIndex(2);
       else if(button==ui->setBt_3)
           ui->stackedWidget->setCurrentIndex(3);
       int i = 0;
       ui->stackedWidget->widget(i);

}
void ctrl::on_backBt_clicked()
{
    this->close();
}

void ctrl::on_livingBt_2_clicked()
{
    swithchPage();
}

void ctrl::on_bedBt_2_clicked()
{
    swithchPage();
//    QTimer *time=new QTimer;

//    connect(time,&QTimer::timeout,[=]()
//    {
//       socket->write() //发送消息
//    });
//    time->start(1000);
}

void ctrl::on_minBt_2_clicked()
{
    swithchPage();
}

void ctrl::on_setBt_3_clicked()
{
     swithchPage();
}

void ctrl::on_camera_clicked()
{
    swithchPage();
    //获取可用摄像头设备并输出在控制台
    QList<QCameraInfo> infos = QCameraInfo::availableCameras();
    qDebug() << infos.value(0).deviceName() << ":" <<infos.value(0).description();
    QString camera = infos.value(0).deviceName();
    qDebug() << camera;
    //显示摄像头
    ca =new QCamera(camera.toUtf8() ,this );
    ui->stackedWidget->widget(2)->show();
    QCameraViewfinder *v2 = new QCameraViewfinder(ui->stackedWidget->widget(2));
        v2->resize(ui->stackedWidget->widget(2)->size());
        ca->setViewfinder(v2);
        v2->show();
        ca->start();
}

void ctrl::on_closeCamera_clicked()
{
   //关闭摄像头
  ca->stop();
  //隐藏页面
  ui->stackedWidget->widget(2)->hide();
}


void ctrl::on_connectBtn_clicked()
{
    //获取ui界面上的数据
    //userName = ui->lineEdit->text();        //获取用户名
    QString ip = ui->lineEdit->text();             //获取主机地址
    quint16 port = ui->lineEdit_4->text().toUInt();   //获取端口号

    if(ui->connectBtn->text() == "连接服务器")
    {
        //连接功能
        socket->connectToHost(ip, port);
        //void connectToHost(const QString &hostName, quint16 port, OpenMode mode = ReadWrite);
        //功能：客户端连接到服务器
        //参数1：指定服务器的主机地址
        //参数2：指定服务器的端口号
        //参数3：打开模式，默认为读写模式
        //返回值：无

        //当客户端成功连接服务器后，该客户端就会自动发射一个connected的信号，我们可以在该信号对应的槽函数中处理相关逻辑
        //但是，该连接只需连接一次即可，所以要放在构造函数中进行连接

        //将按钮文本改成断开服务器
        ui->connectBtn->setText("断开服务器");
    }else if(ui->connectBtn->text() == "断开服务器")
    {
//        //告诉服务器，我走了
//        QString msg = userName +": 离开聊天室";
//        socket->write(msg.toLocal8Bit());


        //断开功能
        socket->disconnectFromHost();
        //功能断开客户端和服务器的连接

        //将按钮文本内容改成连接服务器
        ui->connectBtn->setText("连接服务器");

        // 客厅按钮关闭
        ui->livingBt_2->setEnabled(false);

        // 卧室按钮关闭
        ui->bedBt_2->setEnabled(false);

        // 监控按钮关闭
        ui->minBt_2->setEnabled(false);

        // 自动按钮关闭
        ui->but_auto->setEnabled(false);

        // 手动按钮关闭
        ui->but_hand->setEnabled(false);
    }
}

//处理connected信号的槽函数
void ctrl::on_connected_slot()
{
    QMessageBox::information(this,"信息", "成功连接服务器");

    // 客厅按钮启用
    ui->livingBt_2->setEnabled(true);

    // 卧室按钮启用
    ui->bedBt_2->setEnabled(true);

    // 监控按钮启用
    ui->minBt_2->setEnabled(true);

    // 自动按钮启用
    ui->but_auto->setEnabled(true);

    // 手动按钮启用
    ui->but_hand->setEnabled(true);

//    //给服务器发送一个数据，直接启动温湿度传感器
//    cli_msg.Temperature_humidity = 1;
//    QByteArray m_data;
//    m_data.resize(sizeof(cli_msg));
//    memcpy(m_data.data(), &cli_msg, sizeof(cli_msg));
//    //将该消息 发送给服务器
//    socket->write(m_data);

}

//处理readyRead信号的槽函数
void ctrl::on_readyRead_slot()
{
//    //获取套接字中的数据
//    socket->read((char *)&cli_msg, sizeof(cli_msg));

//    //将数据展示到ui界面
//    ui->lcd_tem->display(cli_msg.tem);
//    ui->lcd_hum->display(cli_msg.hun);

    qDebug()<<"1";
    //获取温湿度到数码管
    msg_t msg_lcd;
    socket->read((char*)&msg_lcd,sizeof(msg_lcd));
    ui->lcd_tem->display(msg_lcd.cmdtype);
    ui->lcd_hum->display(msg_lcd.open_close);

}

//void ctrl::on_lineEdit_cursorPositionChanged(int arg1, int arg2)
//{

//}

//LED1
void ctrl::on_but_led1_clicked()
{
//    //按钮开
//    if(ui->but_led1->text()=="1")
//    {
//        cli_msg.cmdtype = 1;
//        cli_msg.open_close = 1;
//        QByteArray m_data;
//        m_data.resize(sizeof(cli_msg));
//        memcpy(m_data.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data);
//        ui->but_led1->setText("0");//按钮关
//    }
//    else
//    {
//        cli_msg.cmdtype = 1;
//        cli_msg.open_close = 0;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(cli_msg));
//        memcpy(m_data1.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data1);
//        ui->but_led1->setText("1");//按钮开
//    }

    //按钮开
    if(ui->but_led1->text()=="1")
    {

        //msg.equ=0;
         msg.cmdtype=1;
        msg.open_close=1;
        QByteArray m_data;
        m_data.resize(sizeof(msg_t));
        memcpy(m_data.data(),&msg,sizeof(msg_t));
        socket->write(m_data);
        ui->but_led1->setText("0");//按钮关
    }
    else
    {
        //msg.equ=1;
         msg.cmdtype=1;
        msg.open_close=0;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->but_led1->setText("1");//按钮开
    }

}

//LED2
void ctrl::on_but_led3_clicked()
{
//    //按钮开
//    if(ui->but_led2->text()=="1")
//    {
//        cli_msg.cmdtype = 2;
//        cli_msg.open_close = 1;
//        QByteArray m_data;
//        m_data.resize(sizeof(cli_msg));
//        memcpy(m_data.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data);
//        ui->but_led2->setText("0");//按钮关
//    }
//    else
//    {
//        cli_msg.cmdtype = 2;
//        cli_msg.open_close = 0;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(cli_msg));
//        memcpy(m_data1.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data1);
//        ui->but_led2->setText("0");//按钮开
//    }

    //按钮开
    if(ui->but_led2->text()=="1")
    {
        //msg.equ=2;
        msg.cmdtype=2;
        msg.open_close=1;
        QByteArray m_data;
        m_data.resize(sizeof(msg_t));
        memcpy(m_data.data(),&msg,sizeof(msg_t));
        socket->write(m_data);
        ui->but_led2->setText("0");//按钮关
    }
    else
    {
        //msg.equ=3;
         msg.cmdtype=2;
        msg.open_close=0;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->but_led2->setText("1");//按钮开
    }

}

//LED3
void ctrl::on_but_led2_clicked()
{
//    //按钮开
//    if(ui->but_led3->text()=="1")
//    {
//        cli_msg.cmdtype = 3;
//        cli_msg.open_close = 1;
//        QByteArray m_data;
//        m_data.resize(sizeof(cli_msg));
//        memcpy(m_data.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data);
//        ui->but_led3->setText("0");//按钮关
//    }
//    else
//    {
//        cli_msg.cmdtype = 3;
//        cli_msg.open_close = 0;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(cli_msg));
//        memcpy(m_data1.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data1);
//        ui->but_led3->setText("0");//按钮开
//    }

    //按钮开
    if(ui->but_led3->text()=="1")
    {
        //msg.equ=4;
         msg.cmdtype=3;
        msg.open_close=1;
        QByteArray m_data;
        m_data.resize(sizeof(msg_t));
        memcpy(m_data.data(),&msg,sizeof(msg_t));
        socket->write(m_data);
        ui->but_led3->setText("0");//按钮关
    }
    else
    {
        //msg.equ=5;
         msg.cmdtype=3;
        msg.open_close=0;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->but_led3->setText("1");//按钮开
    }
}

//蜂鸣器
void ctrl::on_baojinqi_clicked()
{
//    //按钮开
//    if(ui->baojinqi->text()=="1")
//    {
//        cli_msg.cmdtype = 4;
//        cli_msg.open_close = 1;
//        QByteArray m_data;
//        m_data.resize(sizeof(cli_msg));
//        memcpy(m_data.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data);
//        ui->baojinqi->setText("0");//按钮关
//    }
//    else
//    {
//        cli_msg.cmdtype = 4;
//        cli_msg.open_close = 0;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(cli_msg));
//        memcpy(m_data1.data(),&cli_msg,sizeof(cli_msg));
//        socket->write(m_data1);
//        ui->baojinqi->setText("0");//按钮开
//    }

    //按钮开
    if(ui->baojinqi->text()=="1")
    {

        //msg.equ=10;
        msg.cmdtype=4;
        msg.open_close=1;
        QByteArray m_data;
        m_data.resize(sizeof(msg_t));
        memcpy(m_data.data(),&msg,sizeof(msg_t));
        socket->write(m_data);
        ui->baojinqi->setText("0");//按钮关
    }
    else
    {
        //msg.equ=11;
        msg.cmdtype=4;
        msg.open_close=0;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->baojinqi->setText("1");//按钮开
    }
}

////风扇
//void ctrl::on_baojinqi_2_clicked()
//{
//    //按钮开
//    if(ui->fengshan->text()=="1")
//    {
//        msg.equ=8;
//        QByteArray m_data;
//        m_data.resize(sizeof(msg_t));
//        memcpy(m_data.data(),&msg,sizeof(msg_t));
//        socket->write(m_data);
//        ui->fengshan->setText("2");//按钮关
//    }
//    else if(ui->fengshan->text() == "2") //二档
//    {
//        msg.equ=12;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(msg_t));
//        memcpy(m_data1.data(),&msg,sizeof(msg_t));
//        socket->write(m_data1);
//        ui->fengshan->setText("3");//按钮开
//    }
//    else if(ui->fengshan->text() == "3") // 三档
//    {
//        msg.equ=13;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(msg_t));
//        memcpy(m_data1.data(),&msg,sizeof(msg_t));
//        socket->write(m_data1);
//        ui->fengshan->setText("0");//按钮开
//    }
//    else if(ui->fengshan->text() == "0") // 按第四下的时候关闭并将开关转为1
//    {
//        msg.equ=9;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(msg_t));
//        memcpy(m_data1.data(),&msg,sizeof(msg_t));
//        socket->write(m_data1);
//        ui->fengshan->setText("1");//按钮开
//    }
//}

//// 马达
//void ctrl::on_fengshan_2_clicked()
//{
//    //按钮开
//    if(ui->mada->text()=="1")
//    {
//        msg.equ=6;
//        QByteArray m_data;
//        m_data.resize(sizeof(msg_t));
//        memcpy(m_data.data(),&msg,sizeof(msg_t));
//        socket->write(m_data);
//        ui->mada->setText("2");//按钮关
//    }
//    else if(ui->mada->text() == "2") //二档
//    {
//        msg.equ=14;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(msg_t));
//        memcpy(m_data1.data(),&msg,sizeof(msg_t));
//        socket->write(m_data1);
//        ui->mada->setText("3");//按钮开
//    }
//    else if(ui->mada->text() == "3") // 三档
//    {
//        msg.equ=15;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(msg_t));
//        memcpy(m_data1.data(),&msg,sizeof(msg_t));
//        socket->write(m_data1);
//        ui->mada->setText("0");//按钮开
//    }
//    else if(ui->mada->text() == "0") // 按第四下的时候关闭并将开关转为1
//    {
//        msg.equ=7;
//        QByteArray m_data1;
//        m_data1.resize(sizeof(msg_t));
//        memcpy(m_data1.data(),&msg,sizeof(msg_t));
//        socket->write(m_data1);
//        ui->mada->setText("1");//按钮开
//    }
//}

// 风扇
void ctrl::on_fengshan_clicked()
{
    //按钮开
     qDebug("222");
      qDebug()<<ui->fengshan->text();
    if(ui->fengshan->text()=="1")
    {

        msg.cmdtype=6;
        msg.open_close=1;
        msg.speed_run=1;
        QByteArray m_data;
        m_data.resize(sizeof(msg_t));
        memcpy(m_data.data(),&msg,sizeof(msg_t));
        socket->write(m_data);
        ui->fengshan->setText("2");//按钮关
    }
    else if(ui->fengshan->text() == "2") //二档
    {
        msg.cmdtype=6;
        msg.open_close=1;
        msg.speed_run=2;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->fengshan->setText("3");//按钮开
    }
    else if(ui->fengshan->text() == "3") // 三档
    {
        msg.cmdtype=6;
        msg.open_close=1;
        msg.speed_run=3;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->fengshan->setText("0");//按钮开
    }
    else if(ui->fengshan->text() == "0") // 按第四下的时候关闭并将开关转为1
    {
        msg.cmdtype=6;
        msg.open_close=0;
        msg.speed_run=1;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->fengshan->setText("1");//按钮开
    }

}

// 马达
void ctrl::on_mada_clicked()
{
    //按钮开
    if(ui->mada->text()=="1")
    {
        msg.cmdtype=5;
        msg.open_close=1;
        msg.speed_run=1;
        QByteArray m_data;
        m_data.resize(sizeof(msg_t));
        memcpy(m_data.data(),&msg,sizeof(msg_t));
        socket->write(m_data);
        ui->mada->setText("2");//按钮关
    }
    else if(ui->mada->text() == "2") //二档
    {
        msg.cmdtype=5;
        msg.open_close=1;
        msg.speed_run=2;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->mada->setText("3");//按钮开
    }
    else if(ui->mada->text() == "3") // 三档
    {
        msg.cmdtype=5;
        msg.open_close=1;
        msg.speed_run=3;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->mada->setText("0");//按钮开
    }
    else if(ui->mada->text() == "0") // 按第四下的时候关闭并将开关转为1
    {
        msg.cmdtype=5;
        msg.open_close=0;
        msg.speed_run=1;
        QByteArray m_data1;
        m_data1.resize(sizeof(msg_t));
        memcpy(m_data1.data(),&msg,sizeof(msg_t));
        socket->write(m_data1);
        ui->mada->setText("1");//按钮开
    }
}

// 自动按钮
void ctrl::on_but_auto_clicked()
{
    // 客厅按钮关闭
    ui->livingBt_2->setEnabled(false);

    // 卧室按钮关闭
    ui->bedBt_2->setEnabled(false);

    // 监控按钮关闭
    ui->minBt_2->setEnabled(false);

    //msg.flags = 1;

}

// 手动模式
void ctrl::on_but_hand_clicked()
{
    // 客厅按钮启用
    ui->livingBt_2->setEnabled(true);

    // 卧室按钮启用
    ui->bedBt_2->setEnabled(true);

    // 监控按钮启用
    ui->minBt_2->setEnabled(true);

   // msg.flags = 0;
}


void ctrl::on_pushButton_2_clicked()//设置数码管显示温度
{
    msg.cmdtype=7;
    msg.open_close=1;
    msg.speed_run=3;
    QByteArray m_data1;
    m_data1.resize(sizeof(msg_t));
    memcpy(m_data1.data(),&msg,sizeof(msg_t));
    socket->write(m_data1);

}

void ctrl::on_pushButton_3_clicked()//设置数码管显示湿度=
{
    msg.cmdtype=7;
    msg.open_close=2;
    msg.speed_run=3;
    QByteArray m_data1;
    m_data1.resize(sizeof(msg_t));
    memcpy(m_data1.data(),&msg,sizeof(msg_t));
    socket->write(m_data1);
}

void ctrl::on_pushButton_clicked()
{
   QString sss(ui->wdtx->text());
   QString bbb(ui->sdtx->text());
   int ss =sss.toInt();
   int bb =bbb.toInt();
   msg.cmdtype=9;
   msg.open_close=ss;
   msg.speed_run=bb;
   QByteArray m_data1;
   m_data1.resize(sizeof(msg_t));
   memcpy(m_data1.data(),&msg,sizeof(msg_t));
   socket->write(m_data1);


}

void ctrl::on_pushButton_4_clicked()  //关闭报警
{
     msg.cmdtype=10;
     msg.open_close=2;
     msg.speed_run=3;
     QByteArray m_data1;
     m_data1.resize(sizeof(msg_t));
     memcpy(m_data1.data(),&msg,sizeof(msg_t));
     socket->write(m_data1);

}
