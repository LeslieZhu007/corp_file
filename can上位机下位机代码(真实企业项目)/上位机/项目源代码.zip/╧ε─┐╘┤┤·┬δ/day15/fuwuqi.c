#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/wait.h>
#include <pthread.h>
#include <fcntl.h>
#include <time.h>
#include "led.h"
#include <pthread.h>
#include <sys/ioctl.h>
#include "head.h"
#define ERR_MSG(msg)                          \
	do                                        \
	{                                         \
		fprintf(stderr, "line:%d", __LINE__); \
		perror(msg);                          \
	} while (0)
#define IP "192.168.0.100"			  // 本机ＩＰ ifconfig查看
#define PORT 8888					  // 1024~49151
int sfd, fd, fd3, fd4, fd5, fd6, fd7; // 文件描述符
int newfd;							  // 用来和客户端进行交互的文件描述符
int wen = 35;						  // 温度阈值
int shi = 30;						  // 湿度阈值
int flag = 0;
int flag1 = 0;
int flag2=0;
int a, b, c, d;
char buf[2];
char buf1[2];
char buf2[2];
char buf3[2];
char num[10] = {
	0x3F, // 0
	0x06, // 1
	0x5B, // 2
	0x4F, // 3
	0x66, // 4
	0x6D, // 5
	0x7D, // 6
	0x07, // 7
	0x7F, // 8
	0x6F, // 9
};
char which[] = {
	0x1,
	0x2,
	0x4,
	0x8,
};
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER; // 创建互斥锁并初始化
struct node										   // 服务器与客户端的通信结构体
{

	int cmdtpye;	// 通信指令类型  1为led1 2为led2 3为led3 4为蜂鸣器 5为马达 6为风扇 7为温湿度 9为传递值
	int open_close; // 通信的开关 1为开 2为关（温湿度方面：1为采集温度，2为采集湿度）
	int speed_run;	// 运行的速度  1为1挡 2为挡 3为3挡
};

// 分支线程用来跑采集温湿度
void *deal_cli_msg(void *arg)
{
	int b;

	fd6 = open("/dev/m74hc595", O_RDWR);
	if (fd6 < 0)
	{
		printf("打开spi总线设备文件失败\n");
		exit(-1);
	}
	fd7 = open("/dev/si7006", O_RDWR);
	if (fd7 < 0)
	{
		printf("打开iic总线设备文件失败\n");
		exit(-1);
	}
	struct node recv_msg;
	int hum, tem, hum1, tem1;
	struct DigitDisplay display;
	while (1)
	{
		//	pthread_mutex_lock(&mutex); // 上锁
			ioctl(fd7, GET_HUM, &hum);
			ioctl(fd7, GET_TEM, &tem); // 实现温湿度的采集
			// 大小端转换
			hum = ntohs(hum);
			tem = ntohs(tem);
			hum1 = (int)(125.0 * hum / 65536 - 6);
			tem1 = (int)(175.72 * tem / 65536 - 46.85);
			if (flag == 2)
				display.number = hum1; // 湿度
			else
				display.number = tem1; // 温度
			a = display.number % 10;
			b = (display.number % 100) / 10;
			c = (display.number % 1000) / 100;
			d = (display.number / 1000);
			buf[0] = 1<<3;
			buf[1] = num[a];
			buf1[0] = 1 << 2;
			buf1[1] = num[b];
			buf2[0] = 1 << 1;
			buf2[1] = num[c];
			buf3[0] = 1 << 0;
			buf3[1] = num[d];
			recv_msg.cmdtpye=tem1;
			recv_msg.open_close=hum1;
			// show_spi(display.number, fd6); // 实现数据到数码管
			send(newfd, &recv_msg, sizeof(recv_msg), 0);
		
		//	pthread_mutex_unlock(&mutex); // 解锁
			if (tem1 > wen && hum1 > shi&&flag2!=1)
			{

				ioctl(fd3, FMQ_ON, &recv_msg.cmdtpye); // 蜂鸣器
				ioctl(fd4, MD3_ON, &recv_msg.cmdtpye); // 马达
				ioctl(fd5, FS3_ON, &recv_msg.cmdtpye); // 风扇
				ioctl(fd, LED1_ON, &b);				   // 开灯
				sleep(1);
				ioctl(fd, LED2_ON, &b); // 开灯
				sleep(1);
				ioctl(fd, LED3_ON, &b); // 开灯
				sleep(1);
				ioctl(fd, LED1_OFF, &b); // 开灯
				sleep(1);
				ioctl(fd, LED2_OFF, &b); // 开灯
				sleep(1);
				ioctl(fd, LED3_OFF, &b); // 开灯
			}
		}
	
	close(fd6);
	close(fd7);
	pthread_exit(NULL);
}

// 分支线程用来跑温湿度显示到数码管
void *deal_cli_msg_a(void *arg)
{

	while (1)
	{
		//	pthread_mutex_lock(&mutex); // 上锁
		ioctl(fd6, OUTPUT_TEM, buf3);
		ioctl(fd6, OUTPUT_TEM, buf2);
		ioctl(fd6, OUTPUT_TEM, buf1);
		ioctl(fd6, OUTPUT_TEM, buf);
								//	pthread_mutex_unlock(&mutex); // 解锁
		}
	pthread_exit(NULL);
}

int TCPfuwuqi() // 服务器的搭建
{

	// 创建字节流套接字
	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sfd < 0)
	{
		ERR_MSG("socket");
		return -1;
	}
	//	printf("sfd=%d\n",sfd);//打印套接字的文件描述符

	// 允许端口快速重用

	int reuse = 1;
	if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) < 0)
	{
		ERR_MSG("setsockopt");
		return -1;
	}

	// 填充地址信息结构体
	// 真实的地址信息结构体根据地址族指定　AF_INET:man 7 ip查看
	struct sockaddr_in sin;
	sin.sin_family = AF_INET;			 // 必须填AF_INET
	sin.sin_port = htons(PORT);			 // 端口号：1024~49151
	sin.sin_addr.s_addr = inet_addr(IP); // 本机ＩＰ

	// 将ｉｐ和端口号绑定到套接字上
	if (bind(sfd, (struct sockaddr *)&sin, sizeof(sin)) < 0)
	{
		ERR_MSG("bind");
		return -1;
	}
	printf("bind success __%d__\n", __LINE__);

	// 将套接字设置为被动监听状态，监听是否有客户端连接成功
	if (listen(sfd, 64) < 0)
	{
		ERR_MSG("listen");
		return -1;
	}
	printf("listen success __%d__", __LINE__);

	struct sockaddr_in cin; // 存储连接成功的客户端地址信息
	socklen_t addrlen = sizeof(cin);
	newfd = -1;
	pthread_t tid;
	pthread_t tid1;
	while (1)
	{
		// 父进程负责连接
		newfd = accept(sfd, (struct sockaddr *)&cin, &addrlen);
		if (newfd < 0)
		{
			ERR_MSG("accept");
			return -1;
		}
		printf("newfd=%d,连接成功__%d__\n", newfd, __LINE__);

		// 一个分支线程用于循环采集温湿度
		if (pthread_create(&tid, NULL, deal_cli_msg, NULL) != 0)
		{
			fprintf(stderr, "line:%d pthread_create failed\n", __LINE__);
			return -1;
		}
		pthread_detach(tid); // 分离线程
		sleep(1);
		// 一个分支线程用于显示数码管数值
		if (pthread_create(&tid1, NULL, deal_cli_msg_a, NULL) != 0)
		{
			fprintf(stderr, "line:%d pthread_create failed\n", __LINE__);
			return -1;
		}
		pthread_detach(tid1); // 分离线程
							  // 主线程用于接收客户端信息并处理
		fd = open("/dev/myled", O_RDWR);
		if (fd < 0)
		{
			printf("打开led设备文件失败\n");
			exit(-1);
		}

		fd3 = open("/dev/fengmingqi", O_RDWR);
		if (fd3 < 0)
		{
			printf("打开fengmingqi设备文件失败\n");
			exit(-1);
		}
		fd4 = open("/dev/mada", O_RDWR);
		if (fd4 < 0)
		{
			printf("打开mada设备文件失败\n");
			exit(-1);
		}
		fd5 = open("/dev/fengshan", O_RDWR);
		if (fd5 < 0)
		{
			printf("打开fengshan设备文件失败\n");
			exit(-1);
		}
		struct node recv_msg; // 存放从客户端接收的信息
		while (1)
		{
			bzero(&recv_msg, sizeof(recv_msg));
			//  接收客户端信息
			ssize_t res = recv(newfd, &recv_msg, sizeof(recv_msg), 0);
			if (res < 0)
			{
				// ERR_MSG("recv");
				return -1;
			}
			printf("类型：%d\n", recv_msg.cmdtpye);
			printf("开关：%d\n", recv_msg.open_close);
			printf("速度：%d\n", recv_msg.speed_run);
			if (recv_msg.cmdtpye == 1) // led1
			{
				if (recv_msg.open_close)				   // 为1
					ioctl(fd, LED1_ON, &recv_msg.cmdtpye); // 开灯
				else
					ioctl(fd, LED1_OFF, &recv_msg.cmdtpye);	   // 关灯
			}
			else if (recv_msg.cmdtpye == 2) // led2
			{
				if (recv_msg.open_close)				   // 为1
					ioctl(fd, LED2_ON, &recv_msg.cmdtpye); // 开灯
				else
					ioctl(fd, LED2_OFF, &recv_msg.cmdtpye);	   // 关灯
			}
			else if (recv_msg.cmdtpye == 3) // led3
			{
				if (recv_msg.open_close)				   // 为1
					ioctl(fd, LED3_ON, &recv_msg.cmdtpye); // 开灯
				else
					ioctl(fd, LED3_OFF, &recv_msg.cmdtpye);	   // 关灯
			}
			else if (recv_msg.cmdtpye == 4) // 蜂鸣器
			{
				if (recv_msg.open_close)
					ioctl(fd3, FMQ_ON, &recv_msg.cmdtpye); // 开
				else
					ioctl(fd3, FMQ_OFF, &recv_msg.cmdtpye);	   // 关
			}
			else if (recv_msg.cmdtpye == 5) // mada
			{
				if (recv_msg.open_close) // 为1
				{
					if (recv_msg.speed_run == 1)			   // 速度为1
						ioctl(fd4, MD1_ON, &recv_msg.cmdtpye); // 开灯
					else if (recv_msg.speed_run == 2)		   // 速度为2
						ioctl(fd4, MD2_ON, &recv_msg.cmdtpye); // 开灯
					else if (recv_msg.speed_run == 3)		   // 速度为3
						ioctl(fd4, MD3_ON, &recv_msg.cmdtpye); // 开灯
				}
				else
					ioctl(fd4, MD_OFF, &recv_msg.cmdtpye); // 关灯
			}
			else if (recv_msg.cmdtpye == 6) // fengshan
			{
				if (recv_msg.open_close) // 为1
				{
					if (recv_msg.speed_run == 1)			   // 速度为1
						ioctl(fd5, FS1_ON, &recv_msg.cmdtpye); // 开灯
					else if (recv_msg.speed_run == 2)		   // 速度为2
						ioctl(fd5, FS2_ON, &recv_msg.cmdtpye); // 开灯
					else if (recv_msg.speed_run == 3)		   // 速度为3
						ioctl(fd5, FS3_ON, &recv_msg.cmdtpye); // 开灯
				}
				else
					ioctl(fd5, FS_OFF, &recv_msg.cmdtpye); // 关灯
			}
			else if (recv_msg.cmdtpye == 7) // 温湿度
			{
				pthread_mutex_lock(&mutex);	  // 上锁
				if (recv_msg.open_close == 1) // 采集温度
					flag = 1;
				else if (recv_msg.open_close == 2) // 采集湿度
					flag = 2;
				pthread_mutex_unlock(&mutex); // 解锁
			}
			else if (recv_msg.cmdtpye == 9) // 温湿度的值传递
			{
				wen = recv_msg.open_close;
				shi = recv_msg.speed_run;
			}
			else if(recv_msg.cmdtpye==10)//关闭警报
			{
			 	ioctl(fd, LED1_OFF, &recv_msg.cmdtpye);	   // 关灯
				ioctl(fd, LED2_OFF, &recv_msg.cmdtpye);	   // 关灯
				ioctl(fd, LED3_OFF, &recv_msg.cmdtpye);	   // 关灯
				ioctl(fd3, FMQ_OFF, &recv_msg.cmdtpye);	   // 关
				ioctl(fd5, FS_OFF, &recv_msg.cmdtpye); // 关灯
				ioctl(fd4, MD_OFF, &recv_msg.cmdtpye); // 关灯
				flag2=1;

			}
		}
		close(fd);
		close(fd3);
		close(fd4);
		close(fd5);
		close(newfd);
		close(sfd);
	}
}
int main(int argc, const char *argv[])
{

	TCPfuwuqi(); // 搭建服务器并用多进程去接收数据，多线程去实时接收温湿度数据
	return 0;
}
