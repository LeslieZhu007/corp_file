#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include "head.h"
char num[10] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F, // 9
};
char which[] = {
    0x1,
    0x2,
    0x4,
    0x8,
};
void show_spi(int tem, int fd)
{
    int tem1 = tem;
    int fd1 = fd;
    int i, j;
    for (i = 3; i >= 0; i--)
    {
        for (j = 0; j < 10; j++)
        {
            if ((tem1 % 10) == j)
            { // 最低位
                char buf[128] = {1 << i, num[j]};
                while (1)
                {
                    j++;
                    ioctl(fd1, OUTPUT_TEM, buf);
                    if (j > 40)
                    {
                        j = 0;
                        break;
                    }
                }
                break;
            }
        }
        tem1 /= 10;
    }
}

int main(int argc, const char *argv[])
{
    int tem, hum;
    int tem1, hum1;
    int fd = open("/dev/m74hc595", O_RDWR);
    if (fd < 0)
    {
        perror("open error");
        return -1;
    }
    int fd_i2c = open("/dev/si7006", O_RDWR);
    if (fd_i2c < 0)
    {
        printf("设备文件打开失败\n");
        return -1;
    }
    struct DigitDisplay display;
    display.number = 9876; // 设置要显示的四位数
    while (1)
    {
        // 获取数据
        ioctl(fd_i2c, GET_HUM, &hum);
        ioctl(fd_i2c, GET_TEM, &tem);
        // 大小端转换
        hum = ntohs(hum);
        tem = ntohs(tem);
        // 计算数据
        hum1 = (int)(125.0 * hum / 65536 - 6);
        tem1 = (int)(175.72 * tem / 65536 - 46.85);
        // display.number=tem1 * 100 + hum1;
        // display.number=tem1; //温度
        display.number = hum1; // 湿度
        printf("%d\n", display.number);
        show_spi(display.number, fd); // 显示
    }
    close(fd);
    return 0;
}