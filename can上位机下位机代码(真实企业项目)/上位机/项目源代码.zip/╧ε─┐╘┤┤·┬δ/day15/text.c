#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <time.h>
#include "led.h"
#include "head.h"
pthread_t tid;
char num[10] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F, // 9
};
void show_spi(int tem, int fd)
{
    int tem1 = tem;
    int fd1 = fd;
    int i, j;
    for (i = 3; i >= 0; i--)
    {
        for (j = 0; j < 10; j++)
        {
            if ((tem1 % 10) == j)
            { // 最低位
                char buf[128] = {1 << i, num[j]};
                while (1)
                {
                    j++;
                    ioctl(fd1, OUTPUT_TEM, buf);
                    if (j > 40)
                    {
                        j = 0;
                        break;
                    }
                }
                break;
            }
        }
        tem1 /= 10;
    }
}

char which[] = {
    0x1,
    0x2,
    0x4,
    0x8,
};

int main(int argc, char const *argv[])
{
    /* code */
    // 主线程用于接收客户端信息并处理
    int fd = open("/dev/myled", O_RDWR);
    if (fd < 0)
    {
        printf("打开led1设备文件失败\n");
        exit(-1);
    }

    int fd3 = open("/dev/fengmingqi", O_RDWR);
    if (fd3 < 0)
    {
        printf("打开fengmingqi设备文件失败\n");
        exit(-1);
    }
    int fd4 = open("/dev/mada", O_RDWR);
    if (fd4 < 0)
    {
        printf("打开mada设备文件失败\n");
        exit(-1);
    }
    int fd5 = open("/dev/fengshan", O_RDWR);
    if (fd5 < 0)
    {
        printf("打开fengshan设备文件失败\n");
        exit(-1);
    }
    int fd6 = open("/dev/m74hc595", O_RDWR);
    if (fd6 < 0)
    {
        printf("打开spi总线设备文件失败\n");
        exit(-1);
    }
    int fd7 = open("/dev/si7006", O_RDWR);
    if (fd7 < 0)
    {
        printf("打开iic总线设备文件失败\n");
        exit(-1);
    }
    int a;
    int b;
    int hum, tem, hum1, tem1;
    struct DigitDisplay display;

    while (1)
    {
        printf("请输入（1 -6）LED亮灭  (7 8)蜂鸣器 （9-12马达）（13-16风扇） （17温度）（18湿度）(19)");
        scanf("%d", &a);
        if (a == 1) // led1
        {
            // 为1
            ioctl(fd, LED1_ON, &b); // 开灯
        }
        else if (a == 2)
            ioctl(fd, LED1_OFF, &b); // 关灯
        else if (a == 3)             // led2
        {
            // 为1
            ioctl(fd, LED2_ON, &b); // 开灯
        }
        else if (a == 4)
            ioctl(fd, LED2_OFF, &b); // 关灯
        else if (a == 5)             // led3
        {
            // 为1
            ioctl(fd, LED3_ON, &b); // 开灯
        }
        else if (a == 6)
            ioctl(fd, LED3_OFF, &b); // 关灯
        else if (a == 7)             // 蜂鸣器
        {

            ioctl(fd3, FMQ_ON, &b); // 开
        }
        else if (a == 8)
            ioctl(fd3, FMQ_OFF, &b); // 关
        else if (a == 9)             // mada
        {

            // 速度为1
            ioctl(fd4, MD1_ON, &b); // 开灯
        }
        else if (a == 10)
            ioctl(fd4, MD2_ON, &b); // 开灯
        else if (a == 11)
            ioctl(fd4, MD3_ON, &b); // 开灯
        else if (a == 12)
            ioctl(fd4, MD_OFF, &b); // 关灯

        else if (a == 13) // fengshan
        {

            // 速度为1
            ioctl(fd5, FS1_ON, &b); // 开灯
        }
        else if (a == 14)
            ioctl(fd5, FS2_ON, &b); // 开灯
        else if (a == 15)
            ioctl(fd5, FS3_ON, &b); // 开灯
        else if (a == 16)
            ioctl(fd5, FS_OFF, &b); // 关灯
        else if (a == 17)           // 温湿度
        {
            while (1)
            {
                ioctl(fd7, GET_HUM, &hum);
                ioctl(fd7, GET_TEM, &tem); // 实现温湿度的采集
                // 大小端转换
                hum = ntohs(hum);
                tem = ntohs(tem);
                hum1 = (int)(125.0 * hum / 65536 - 6);
                tem1 = (int)(175.72 * tem / 65536 - 46.85);
                printf("%d,%d\n", tem1, hum1);
                display.number = tem1;         // 湿度
                show_spi(display.number, fd6); // 显示
            }
        }
        else if (a == 18) // 温湿度
        {
            while (1)
            {
                ioctl(fd7, GET_HUM, &hum);
                ioctl(fd7, GET_TEM, &tem); // 实现温湿度的采集
                // 大小端转换
                hum = ntohs(hum);
                tem = ntohs(tem);
                hum1 = (int)(125.0 * hum / 65536 - 6);
                tem1 = (int)(175.72 * tem / 65536 - 46.85);
                printf("%d,%d\n", tem1, hum1);
                display.number = hum1; // 湿度
                printf("%d\n", display.number);
                // show_spi(display.number, fd6); // 实现湿度到数码管
                ioctl(fd6, OUTPUT_TEM, &hum1);
                sleep(1);
            }
        }
        else if (a == 19)
        {
            ioctl(fd, LED1_ON, &b); // 开灯
            sleep(1);
            ioctl(fd, LED2_ON, &b); // 开灯
            sleep(1);
            ioctl(fd, LED3_ON, &b); // 开灯
            sleep(1);
            ioctl(fd, LED1_OFF, &b); // 开灯
            sleep(1);
            ioctl(fd, LED2_OFF, &b); // 开灯
            sleep(1);
            ioctl(fd, LED3_OFF, &b); // 开灯
        }
    }
    return 0;
}
