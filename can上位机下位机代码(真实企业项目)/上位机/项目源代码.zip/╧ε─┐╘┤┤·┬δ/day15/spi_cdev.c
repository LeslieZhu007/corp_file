#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/spi/spi.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include "head.h"
#define NAME "m74hc595"

int major = 0;
char buf[2] = "";
struct class *cls;
struct device *dev;
struct spi_device *spi1;

// 数码管显示的编码表（十六进制）

struct DigitDisplay display;
int m74hc595_open(struct inode *inode, struct file *file)
{
    return 0;
}

long m74hc595_ioctl(struct file *file, unsigned int cmd, unsigned long args)
{
    int ret;
    ret = copy_from_user(buf, (void *)args, 2);
    if (ret)
    {
        printk("copy_to_user filed\n");
        return ret;
    }
    spi_write(spi1, buf, sizeof(buf));

    return 0;
}

int m74hc595_close(struct inode *inode, struct file *file)
{
    return 0;
}

struct file_operations fops = {
    .open = m74hc595_open,
    .unlocked_ioctl = m74hc595_ioctl,
    .release = m74hc595_close,
};
int m74hc595_probe(struct spi_device *spi)
{
    spi1 = spi;
    major = register_chrdev(0, NAME, &fops);
    cls = class_create(THIS_MODULE, NAME);
    dev = device_create(cls, NULL, MKDEV(major, 0), NULL, NAME);
    printk("OK\n");

    return 0;
}
int m74hc595_remove(struct spi_device *spi)
{
    device_destroy(cls, MKDEV(major, 0));
    class_destroy(cls);
    unregister_chrdev(major, "m74hc595");

    return 0;
}

// 设备树匹配表
struct of_device_id of_table[] = {
    {.compatible = "hqyj,m74hc595"},
    {},
};
// 定义SPI对象并且初始化
struct spi_driver m74hc595 = {
    .probe = m74hc595_probe,
    .remove = m74hc595_remove,
    .driver = {
        .name = "m74hc595",
        .of_match_table = of_table,
    },
};
module_spi_driver(m74hc595);
MODULE_LICENSE("GPL");
