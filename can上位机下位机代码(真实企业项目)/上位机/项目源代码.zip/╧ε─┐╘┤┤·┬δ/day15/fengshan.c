#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/device.h>
#include "led.h"
unsigned int major;
char kbuf[128] = {0};
// 定义3个指针指向映射后的虚拟内存首地址

unsigned int *vir_moder1;
unsigned int *vir_odr1;
unsigned int *vir_rcc;
unsigned int *vir_rcc1;
unsigned int *vir_AFRH;
unsigned int *vir_PSC;
unsigned int *vir_CCMR1;
unsigned int *vir_CCER;
unsigned int *vir_ARR;
unsigned int *vir_CCR1;
unsigned int *vir_CR1;
unsigned int *vir_BDTR;

// 定义2个结构体
struct class *cls;
struct device *dev;
int mycdev_open(struct inode *inode, struct file *file)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}
long mycdev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{

    switch (cmd)
    {
    case FS1_ON: // 启动风扇1
                 // 设置捕获比较寄存器里面的值为300 [15:0]=300

        (*vir_CCR1) = 300;

        break;

    case FS2_ON: // 启动风扇2

        // 设置捕获比较寄存器里面的值为300 [15:0]=300

        (*vir_CCR1) = 600;
        break;
    case FS3_ON: // 启动风扇3

        // 设置捕获比较寄存器里面的值为300 [15:0]=300

        (*vir_CCR1) = 900;

        break;
    case FS_OFF:         // 关闭风扇
        (*vir_CCR1) = 0; // 关闭风扇
        break;
    default:
        break;
    }
    return 0;
}
ssize_t mycdev_read(struct file *file, char *ubuf, size_t size, loff_t *lof)
{

    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}
ssize_t mycdev_write(struct file *file, const char *ubuf, size_t size, loff_t *iof)
{

    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}
int mycdev_close(struct inode *inode, struct file *file)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}

// 定义一个操作方法结构体变量并且初始化
struct file_operations fops = {
    .open = mycdev_open,
    .read = mycdev_read,
    .write = mycdev_write,
    .unlocked_ioctl = mycdev_ioctl,
    .release = mycdev_close,
};

static int __init mycdev_init(void)
{
    major = register_chrdev(0, "fengshan", &fops);
    if (major < 0)
    {
        printk("字符设备驱动注册失败\n");
        return major;
    }
    printk("字符设备驱动注册成功major=%d\n", major);
    // 向上提交目录
    cls = class_create(THIS_MODULE, "fengshan");
    if (IS_ERR(cls))
    {
        printk("向上提交目录失败\n");
        return -PTR_ERR(cls);
    }
    printk("向上提交目录成功\n");
    // 向上提交设备节点信息
    dev = device_create(cls, NULL, MKDEV(major, 0), NULL, "fengshan");
    if (IS_ERR(dev))
    {
        printk("向上提交设备节点失败\n");
        return -PTR_ERR(dev);
    }
    printk("向上提交设备节点成功\n");

    // 进行风扇相关寄存器地址映射
    vir_rcc = ioremap((resource_size_t) & (RCC->MP_AHB4ENSETR), 4);
    if (vir_rcc == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_rcc1 = ioremap((resource_size_t) & (RCC->MP_APB2ENSETR), 4);
    if (vir_rcc == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    // 进行风扇相关寄存器地址映射
    vir_moder1 = ioremap((resource_size_t) & (GPIOE->MODER), 4);
    if (vir_moder1 == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_odr1 = ioremap(PHY_ODR1, 4);
    if (vir_odr1 == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_AFRH = ioremap((resource_size_t) & (GPIOE->AFRH), 4);
    if (vir_AFRH == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_PSC = ioremap((resource_size_t) & (TIM1->PSC), 4);
    if (vir_PSC == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_CCMR1 = ioremap((resource_size_t) & (TIM1->CCMR1), 4);
    if (vir_CCMR1 == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_CCER = ioremap((resource_size_t) & (TIM1->CCER), 4);
    if (vir_CCER == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_ARR = ioremap((resource_size_t) & (TIM1->ARR), 4);
    if (vir_ARR == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_CCR1 = ioremap((resource_size_t) & (TIM1->CCR1), 4);
    if (vir_CCR1 == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_CR1 = ioremap((resource_size_t) & (TIM1->CR1), 4);
    if (vir_CR1 == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_BDTR = ioremap((resource_size_t) & (TIM1->BDTR), 4);
    if (vir_BDTR == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    // 相关寄存器初始化
    // TIM1_CH1-->PE9
    // RCC章节初始化
    // GPIOe组使能  MP_AHB4ENSETR [4]:1
    (*vir_rcc) |= (1 << 4);
    // time1组使能  MP_APB2ENSETR [0]:1
    (*vir_rcc1) |= 1;
    // GPIO章节初始化   MODER [19:18]:10
    (*vir_moder1) &= (~(0x3 << 18));
    (*vir_moder1) |= (1 << 19);
    // 设置为对应复用功能　AFRH [7:4]:0001
    (*vir_AFRH) &= (~(0xf << 4));
    (*vir_AFRH) |= (1 << 4);
    // TIM1章节初始化，方波频率为１０００hz
    // 设置分频寄存器为２０８ PSC [15:0]=208
    (*vir_PSC) = 208;
    // 设置自动重载计数器里面的值为1000 [15:0]=1000
    (*vir_ARR) &= (~(65535));
    (*vir_ARR) |= 1000;
    // 设置捕获比较寄存器里面的值为300 [15:0]=300
    (*vir_CCR1) &= (~(65535));
    (*vir_CCR1) |= 0;
    // 初始化捕获比较寄存器 TIM4_CCMR1 [16][6:4]:0110 设置ｐｗｍ模式
    (*vir_CCMR1) &= (~(1 << 16));
    (*vir_CCMR1) &= (~(0x7 << 4));
    (*vir_CCMR1) |= (0x3 << 5);
    // 设置捕获比较寄存器使能 CCMR1 [3]:1
    (*vir_CCMR1) |= (0x1 << 3);
    // 配置通道１为输出模式　CCMR1 [1:0]:00
    (*vir_CCMR1) &= (~(0x3));
    // 设置捕获比较寄存器使能以及起始状态为高电平
    // 设置捕获比较寄存器为输出模式　CCER [3]:0
    (*vir_CCER) &= (~(1 << 3));
    // 设置捕获比较寄存器起始状态为高电平　CCER [１]:0
    (*vir_CCER) &= (~(1 << 1));
    // 设置捕获比较寄存器使能  CCER [0]:1
    (*vir_CCER) |= 1;

    // 设置初始化/使能相关内容
    // 设置自动重载预加载使能　　CR1 [7]:1
    (*vir_CR1) |= (1 << 7);
    // 设置边沿对齐方式  CR1 [6:5]:00
    (*vir_CR1) &= (~(0x3 << 5));
    // 设置计数方式为递减计数方式 CR1 [4]:1
    (*vir_CR1) |= (1 << 4);
    // 设置计数使能 CR1 [0]:1
    (*vir_CR1) |= (1);
    // 使能风扇 BDTR [15] 1
    (*vir_BDTR) |= (1 << 15);
    printk("相关寄存器初始化成功\n");
    return 0;
}
static void __exit mycdev_exit(void)
{
    // 设置捕获比较寄存器里面的值为300 [15:0]=300
    (*vir_CCR1) = 0;
    // 内存取消映射
    iounmap(vir_rcc);
    iounmap(vir_rcc1);
    iounmap(vir_odr1);
    iounmap(vir_moder1);
    iounmap(vir_AFRH);
    iounmap(vir_PSC);
    iounmap(vir_CCMR1);
    iounmap(vir_CCER);
    iounmap(vir_ARR);
    iounmap(vir_CCR1);
    iounmap(vir_CR1);
    iounmap(vir_BDTR);
    // 销毁设备节点信息
    device_destroy(cls, MKDEV(major, 0));
    // 销毁目录空间
    class_destroy(cls);
    // 字符设备驱动注销
    unregister_chrdev(major, "fengshan");
}
module_init(mycdev_init);
module_exit(mycdev_exit);
MODULE_LICENSE("GPL");
