#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/device.h>
#include "led.h"
unsigned int major;
char kbuf[128] = {0};
// 定义3个指针指向映射后的虚拟内存首地址

unsigned int *vir_moder3;
unsigned int *vir_odr3;
unsigned int *vir_rcc;
// 定义2个结构体
struct class *cls;
struct device *dev;
int mycdev_open(struct inode *inode, struct file *file)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}
long mycdev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{

    switch (cmd)
    {
    case FMQ_ON: // 启动蜂鸣器

        (*vir_odr3) |= (0x1 << 6); // 启动蜂鸣器
        break;

    case FMQ_OFF: // 关闭蜂鸣器

        (*vir_odr3) &= (~(0x1 << 6)); // 关闭蜂鸣器
        break;
    }
    return 0;
}
ssize_t mycdev_read(struct file *file, char *ubuf, size_t size, loff_t *lof)
{

    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}
ssize_t mycdev_write(struct file *file, const char *ubuf, size_t size, loff_t *iof)
{

    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}
int mycdev_close(struct inode *inode, struct file *file)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}

// 定义一个操作方法结构体变量并且初始化
struct file_operations fops = {
    .open = mycdev_open,
    .read = mycdev_read,
    .write = mycdev_write,
    .unlocked_ioctl = mycdev_ioctl,
    .release = mycdev_close,
};

static int __init mycdev_init(void)
{
    major = register_chrdev(0, "fengmingqi", &fops);
    if (major < 0)
    {
        printk("字符设备驱动注册失败\n");
        return major;
    }
    printk("字符设备驱动注册成功major=%d\n", major);
    // 向上提交目录
    cls = class_create(THIS_MODULE, "fengmingqi");
    if (IS_ERR(cls))
    {
        printk("向上提交目录失败\n");
        return -PTR_ERR(cls);
    }
    printk("向上提交目录成功\n");
    // 向上提交设备节点信息
    dev = device_create(cls, NULL, MKDEV(major, 0), NULL, "fengmingqi");
    if (IS_ERR(dev))
    {
        printk("向上提交设备节点失败\n");
        return -PTR_ERR(dev);
    }
    printk("向上提交设备节点成功\n");

    // 进行fengmingqi相关寄存器地址映射
    vir_rcc = ioremap(PHY_RCC, 4);
    if (vir_rcc == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    // 进行蜂鸣器相关寄存器地址映射
    vir_moder3 = ioremap(PHY_MODER3, 4);
    if (vir_moder3 == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    vir_odr3 = ioremap(PHY_ODR3, 4);
    if (vir_odr3 == NULL)
    {
        printk("物理内存映射失败\n");
        return -1;
    }
    // 相关寄存器初始化
    (*vir_rcc) |= (0x1 << 1); // gpio使能
    (*vir_moder3) &= (~(0x3 << 12));
    (*vir_moder3) |= (0x1 << 12); // fmq为输出模式
    (*vir_odr3) &= (~(0x1 << 6)); // 关闭蜂鸣器状态
    printk("相关寄存器初始化成功\n");

    return 0;
}
static void __exit mycdev_exit(void)
{
    // 内存取消映射
    iounmap(vir_rcc);
    iounmap(vir_odr3);
    iounmap(vir_moder3);
    // 销毁设备节点信息
    device_destroy(cls, MKDEV(major, 0));
    // 销毁目录空间
    class_destroy(cls);
    // 字符设备驱动注销
    unregister_chrdev(major, "fengmingqi");
}
module_init(mycdev_init);
module_exit(mycdev_exit);
MODULE_LICENSE("GPL");
