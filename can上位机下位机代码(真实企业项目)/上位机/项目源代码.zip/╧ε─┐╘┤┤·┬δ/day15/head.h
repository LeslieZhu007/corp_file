#ifndef __HEAD_H__
#define __HEAD_H__

#define GET_HUM _IOR('m',1,int)
#define GET_TEM _IOR('m',0,int)

#define OUTPUT_TEM _IOR('m',2,int)

struct DigitDisplay{
    int number;
};

#endif