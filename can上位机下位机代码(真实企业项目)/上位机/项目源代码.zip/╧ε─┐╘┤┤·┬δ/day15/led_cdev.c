
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/wait.h>
#include <linux/device.h>
#include <linux/poll.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/gpio.h>
#include "led.h"
unsigned int major;
char kbuf[128] = {0};
struct class *cls;
struct device *dev;
// 定义等待队列头
wait_queue_head_t wq_head;
unsigned int condition = 0;
struct device_node *dnode;
struct property *pr;
unsigned int length;
unsigned int ret;
struct gpio_desc *gpiono;
struct gpio_desc *gpiono1;
struct gpio_desc *gpiono2;

int myled_open(struct inode *inode, struct file *file)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}

long myled_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    int ke;
    switch (cmd)
    {
    case LED1_ON: // 开灯

        gpiod_set_value(gpiono, 1);
        break;
    case LED1_OFF:
        gpiod_set_value(gpiono, 0);
        break;
    case LED2_ON:
        gpiod_set_value(gpiono1, 1);
        break;

    case LED2_OFF: // 关灯
        gpiod_set_value(gpiono1, 0);
        break;
    case LED3_OFF:
        gpiod_set_value(gpiono2, 0);
        break;
    case LED3_ON:
        gpiod_set_value(gpiono2, 1);
        break;
    case 1:
        gpiod_set_value(gpiono, 1);
        for (ke = 0; ke < 3000; ke++)
            ;
        gpiod_set_value(gpiono, 0);
        for (ke = 0; ke < 3000; ke++)
            ;
        gpiod_set_value(gpiono1, 1);
        for (ke = 0; ke < 3000; ke++)
            ;
        gpiod_set_value(gpiono1, 0);
        for (ke = 0; ke < 3000; ke++)
            ;
        gpiod_set_value(gpiono2, 1);
        for (ke = 0; ke < 3000; ke++)
            ;
        gpiod_set_value(gpiono2, 0);
        break;
    }

    return 0;
}
int myled_close(struct inode *inode, struct file *file)
{
    printk("%s:%s:%d\n", __FILE__, __func__, __LINE__);
    return 0;
}

// 定义操作方法结构体变量并赋值
struct file_operations fops = {

    .open = myled_open,
    .unlocked_ioctl = myled_ioctl,
    .release = myled_close,
};
static int __init mycdev_init(void)
{
    // 初始化等待队列头
    init_waitqueue_head(&wq_head);

    major = register_chrdev(0, "myled", &fops);
    if (major < 0)
    {
        printk("字符设备驱动注册失败\n");
        return major;
    }
    printk("字符设备驱动注册成功:major=%d\n", major);
    // 向上提交目录
    cls = class_create(THIS_MODULE, "myled");
    if (IS_ERR(cls))
    {
        printk("向上提交目录失败\n");
        return -PTR_ERR(cls);
    }
    printk("向上提交目录成功\n");
    // 向上提交设备节点信息
    dev = device_create(cls, NULL, MKDEV(major, 0), NULL, "myled");
    if (IS_ERR(dev))
    {
        printk("向上提交设备节点失败\n");
        return -PTR_ERR(dev);
    }
    printk("向上提交设备节点成功\n");

    dnode = of_find_node_by_name(NULL, "myleds");
    if (dnode == NULL)
    {
        printk("解析设备树节点失败\n");
        return -ENOMEM;
    }
    printk("解析设备树节点成功\n");

    gpiono = gpiod_get_from_of_node(dnode, "led1", 0, GPIOD_OUT_LOW, NULL);
    if (IS_ERR(gpiono))
    {
        printk("解析设备号失败\n");
        return -PTR_ERR(gpiono);
    }
    printk("申请gpio0编号成功\n");

    gpiono1 = gpiod_get_from_of_node(dnode, "led2", 0, GPIOD_OUT_LOW, NULL);
    if (IS_ERR(gpiono1))
    {
        printk("解析设备号失败\n");
        return -PTR_ERR(gpiono1);
    }
    printk("申请gpio1编号成功\n");

    gpiono2 = gpiod_get_from_of_node(dnode, "led3", 0, GPIOD_OUT_LOW, NULL);
    if (IS_ERR(gpiono2))
    {
        printk("解析设备号失败\n");
        return -PTR_ERR(gpiono2);
    }
    printk("申请gpio2编号成功\n");

    return 0;
}
static void __exit mycdev_exit(void)
{

    gpiod_set_value(gpiono, 0);
    gpiod_set_value(gpiono1, 0);
    gpiod_set_value(gpiono2, 0);
    gpiod_put(gpiono);
    gpiod_put(gpiono1);
    gpiod_put(gpiono2);

    // 销毁设备节点信息
    device_destroy(cls, MKDEV(major, 0));
    // 销毁目录空间
    class_destroy(cls);
    // 字符设备驱动的注销
    unregister_chrdev(major, "mycdev");
}
module_init(mycdev_init);
module_exit(mycdev_exit);
MODULE_LICENSE("GPL");
